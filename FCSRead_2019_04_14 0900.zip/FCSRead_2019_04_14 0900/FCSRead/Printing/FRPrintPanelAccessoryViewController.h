//
//  FRPrintPanelAccessoryViewController.h
//  FCSRd
//
//  Created by Mr. Salzman on 12/14/13.
//  Copyright (c) 2013 Gary Salzman. All rights reserved.
//

#import <Cocoa/Cocoa.h>

#define NumberPagesWhenPrinting @"NumberPagesWhenPrinting"

@interface FRPrintPanelAccessoryViewController : NSViewController <NSPrintPanelAccessorizing>
{
}

@property (nonatomic, assign) BOOL pageNumbering;

- (IBAction)changePageNumbering:(id)sender;

@end
