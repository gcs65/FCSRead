//
//  HistogramSelectionTableViewController.swift - This is one of the controllers in the Model-View-Controller scheme. It controls the selection of histograms to be displayed.
//  FCSRead
//
//  Created by Mr. Salzman on 12/12/17.
//  Copyright © 2019 Gary Salzman. All rights reserved.
//

import Cocoa

class HistogramSelectionTableViewController: NSViewController {

    @IBOutlet weak var tableView0: NSTableView! // Available univariate
    @IBOutlet weak var tableView1: NSTableView! // Selected univariate
    @IBOutlet weak var tableView2: NSTableView! // Select X Variate
    @IBOutlet weak var tableView3: NSTableView! // Select Y Variate
    @IBOutlet weak var tableView4: NSTableView! // XY Bivariate selected
    @IBOutlet var OnePArrayController: NSArrayController!
    @IBOutlet var xPnNArrayController: NSArrayController!
    @IBOutlet var yPnNArrayController: NSArrayController!
    @IBOutlet var xyPnNArrayController: NSArrayController!
    
    @objc dynamic var selectedArrayX2P = [Int]() // output [Int] (indexes)
    @objc dynamic var selectedArrayY2P = [Int]() // output [Int] (indexes)
    @objc dynamic var selectedArrayXY2P = [Int]() // output [Int] (indexes)
    @objc dynamic var selectedBivariates = [String]() // "...X2P[1] string vs ...Y2P[1] string"
    var xVariateSelected = false // For 2P variate selections
    var yVariateSelected = false
    var xyVariateSelected = false
    var xIndexSelected = 0
    var yIndexSelected = 0
    var xyIndexSelected = 0
    
    weak var mainViewController : MainViewController? // Set by MainViewController prepare(for segue:...
    let defaults = UserDefaults.standard
    
    @objc dynamic var theDataArray: [String] { // Array of all the FCS variate numbers. This will be [Int]
        get {
            return defaults.array(forKey: Controllers.DataArrayKey) as! [String]
        }
        set {}
    }
    
    @objc dynamic var selectedArray: [Int] { // Selected univariate histogram variate numbers.
        get {
            return defaults.array(forKey: Controllers.SelectedArrayKey) as! [Int]
        }
        set {
            defaults.set(newValue, forKey: Controllers.SelectedArrayKey)
        }
    }
    
    var selections2PX = NSIndexSet() // Needed because selectionsX is readOnly
    @objc dynamic var selectionsX: NSIndexSet {
        get { return selections2PX }
        set {
            if !(selections2PX == newValue) { // newValue not entered earlier
                selections2PX = newValue
                xIndexSelected = selections2PX.firstIndex
            } // End of if
            selectedArrayX2P.append(xIndexSelected)
            xVariateSelected = true
            updateSelectedBivariates() // Update [String] for display in tableViewXY
        } // End of set selectionsX
    } // End of dynamic var selectionsX
    
    var selections2PY = NSIndexSet() // Needed because selectionsY is readOnly
    @objc dynamic var selectionsY: NSIndexSet {
        get { return selections2PY }
        set {
            if !(selections2PY == newValue) { // newValue not entered earlier
                selections2PY = newValue
                yIndexSelected = selections2PY.firstIndex
            } // End of if
            
            selectedArrayY2P.append(yIndexSelected)
            yVariateSelected = true
            updateSelectedBivariates() // Update [String] for display in tableViewXY
        } // End of set selectionsY
    } // End of dynamic var selectionsY
    
    var selections2PXY = NSIndexSet() // Needed because selectionsXY is readOnly
    @objc dynamic var selectionsXY: NSIndexSet {
        get { return selections2PXY }
        set {
            if !(selections2PXY == newValue) { // newValue not entered earlier
                selections2PXY = newValue
                xyIndexSelected = selections2PXY.firstIndex
            }
            var index = selectionsXY.firstIndex // Add index to selectedArrayX2P
            while index != NSNotFound {
                selectedArrayXY2P.append(index)
                index = selectionsX.indexGreaterThanIndex(index)
            }
            xyVariateSelected = true
        } // End of set selectionsXY
    } // End of dynamic var selectionsXY
    
    
    /// updateSelectedBivariates creates xy String for selected bivariate. Update [String] for tableViewXY
    func updateSelectedBivariates() {
        if xVariateSelected == true && yVariateSelected == true {
            removeDuplicates()
            var xyString = ""
            if xIndexSelected == 0 || yIndexSelected == 0 { // "none" selected in x or y
                selectedArrayX2P.removeLast()
                selectedArrayY2P.removeLast()
            }
            if xIndexSelected > 0 && yIndexSelected > 0 {
                xyString = theDataArray[xIndexSelected] + " vs " + theDataArray[yIndexSelected]
            }
            if !selectedBivariates.contains(xyString) {
                selectedBivariates.append(xyString) // Updates tableViewXY
            }
            xVariateSelected = false // reset for next selection
            yVariateSelected = false
        }
    } // End of updateSelectedBivariates
    
    
    /// removeDuplicates removes corresponding elements from selectedArrayX2P and selectedArrayY2P that are duplicates of pairs at lower indexes. If the test tuple (selectedArrayX2P.last, selectedArrayY2P.last) duplicates any of the earlier tuples, then the test tuple is removed.
    func removeDuplicates() {
        let testTuple = (selectedArrayX2P.last!, selectedArrayY2P.last!)
        for index in 0..<selectedArrayX2P.count - 1 {
            let currentTuple = (selectedArrayX2P[index], selectedArrayY2P[index])
            if testTuple == currentTuple {
                selectedArrayX2P.removeLast()
                selectedArrayY2P.removeLast()
            }
        } // End of loop over index
        
    } // End of removeDuplicates
    
    override func viewDidLoad() {
        super.viewDidLoad() // mainViewController is still nil here.
    }
    
    
    /// keyDown deletes selection or Display button equivalent (return key)
    ///
    /// - Parameter theEvent: keyDown event.
    override func keyDown(with theEvent: NSEvent) {
//        print("keyDown.theEvent.keyCode \(theEvent.keyCode)")
        if theEvent.keyCode == 0x33 { // Delete key (51 base 10)
            let xyIndexSelected1 = xyPnNArrayController.selectionIndexes.first!
            selectedBivariates.remove(at: xyIndexSelected1)
            selectedArrayX2P.remove(at: xyIndexSelected1 - 1)
            selectedArrayY2P.remove(at: xyIndexSelected1 - 1)
        } // End of delete key action
        else if theEvent.keyCode == 36 { // return key
            displayGraphics()
        }
        else {}
    } // End of keyDown
    
    @IBAction func select(_ sender: NSButton) { // Display button pressed
        displayGraphics()
    }
    
    
    /// displayGraphics sets of axis selections and calls MainViewController.displaysSelectedHistograms.
    func displayGraphics() {
        var selectedArrayTemp = [Int]()
        var selections = NSIndexSet()
        selections = OnePArrayController.selectionIndexes as NSIndexSet
        var index = selections.firstIndex
        while index != NSNotFound {
            if index != 0 { // Skip "none"
                selectedArrayTemp.append(index)
            }
            index = selections.indexGreaterThanIndex(index)
        }
        selectedArray = selectedArrayTemp
        if let mainVC = mainViewController {
            mainVC.selectedArrayX2P = selectedArrayX2P
            mainVC.selectedArrayY2P = selectedArrayY2P
            mainVC.displaySelectedHistograms()
        } else {
            print("HistogramSelectionTableViewController.mainVC is nil here - exiting")
            exit(-1)
        }
        dismiss(self)
    }
    
} // End of HistogramSelectionTableViewController
