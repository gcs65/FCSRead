//
//  MainViewControllerExtGating.swift
//  FCSRead
//
//  Created by Mr. Salzman on 12/31/17.
//  Copyright © 2017 Aventuras Publishers LLC. All rights reserved.
//

import Foundation

extension MainViewController { // For gating fData using realBounds
    
    func retrieveHistLimitsForVariate(_ myVariate: Int) -> HistLimits {
        if let myHistLimits: HistLimits = histLimitsDict[myVariate] {
            return myHistLimits
        } else {
            print("MainViewControllerExtGating.retrieveHistLimits failed on if let myHistLimits...")
            return HistLimits(variate: 0)
        }
    } // End of retrieveHistLimitsForVariate
    
    func gateTheData() {
        // Called by rightClick:"Gate The Data" in GraphicSubview:rightMouseDown. Applies gates to the data, recomputes gated histograms and refreshes displays.
        if gateDict.count == 0 {
            isDataGated = false
        } else {
            isDataGated = true
            totalGatedEvents = createGatedEventArray()
            graphicView!.generateGatedHistograms()
        }
    } // End of gateTheData
    
    func createGatedEventArray() -> Int { // MainViewController
        // Create array of integers: [value] is 1 for gated event. Called from gateTheData. A good event is AND among the members of the set of gates.
        var xVar = 0
        var yVar = 0
        var x = 0.0
        var y = 0.0
        var xPrime: CGFloat = 0.0
        var yPrime: CGFloat = 0.0
        var aPoint = NSZeroPoint
        totalGatedEvents = 0
        let totalGates = gateDict.count
        
        gatedEvent = [Int](repeating: 0, count: (readAndParse!.totalEvents + 1))
        insideGate = [Int](repeating: 0, count: (readAndParse!.totalEvents + 1) * totalGates)
        
        var gateIndex = -1
        for key in gateDict.keys { // Loops over all the gates.
            gateIndex += 1 // 0 is first aGate index
            if let aGate = gateDict[key] {
                xVar = aGate.xVariate
                yVar = aGate.yVariate
                histLimitsX2g = retrieveHistLimitsForVariate(xVar)
                flx2P = FastLogicle(myVar: xVar, myAxisType: BivariateTag)
                hyx2P = Hyperlog(myVar: xVar, myAxisType: BivariateTag)
                if yVar != 0 { // Applies only to bivariate
                    histLimitsY2g = retrieveHistLimitsForVariate(yVar)
                    fly2P = FastLogicle(myVar: yVar, myAxisType: BivariateTag)
                    hyy2P = Hyperlog(myVar: yVar, myAxisType: BivariateTag)
                }
                
                // agate.gatetype: RectangleGateTag, EllipseGateTag, PolygonGateTag, QuadrantGateTag. RectangleGates can be either univariate or bivariate. The other gates are bivariate.
                
                if aGate.gateType == RectangleGateTag {
                    
                    if aGate.rectGate!.gateSubType == UnivariateTag { // Univariate RectangleGate
                        flx1P = FastLogicle(myVar: xVar, myAxisType: UnivariateTag)
                        hyx1P = Hyperlog(myVar: xVar, myAxisType: UnivariateTag)
                        histLimitsXg = retrieveHistLimitsForVariate(xVar)
                        
                        let leftGate = aGate.rectGate!.bounds.origin.x
                        let rightGate = leftGate + aGate.rectGate!.bounds.size.width
                        
                        for event in 1...readAndParse!.totalEvents {
                            x = readAndParse!.fData[event][xVar]
                            xPrime = fDataToUniGraphic(x)
                            if xPrime >= leftGate && xPrime < rightGate { // inside gate.
                                let gIndex = event * totalGates + gateIndex
                                insideGate[gIndex] = 1 // Point is inside univariate rectangle gate.
                            }
                        } // end of loop over total events for UnivariateTag
                        
                    } // End of aGate.gateSubType == UnivariateTag
                        
                    else if aGate.rectGate!.gateSubType == BivariateTag { // Bivariate RectangleGate
                        
                        for event in 1...readAndParse!.totalEvents {
                            x = readAndParse!.fData[event][xVar]
                            xPrime = fDataToBivGraphicX(x)
                            y = readAndParse!.fData[event][yVar]
                            yPrime = fDataToBivGraphicY(y)
                            aPoint = NSMakePoint(xPrime, yPrime)
                            if NSPointInRect(aPoint, aGate.rectGate!.bounds) {
                                if aGate.rectGate!.gatePath.contains(aPoint) {
                                    let gIndex = event * totalGates + gateIndex
                                    insideGate[gIndex] = 1 // Point is inside bivariate rectangle gate.
                                }
                            } // End of NSPointInRect
                            
                        } // end of loop over total events for BivariateTage
                        
                    } // End of if aGate.rectGate?.gateSubType == BivariateTag
                        
                    else {}
                    
                } // End of RectangleGateTag (UnivariateTag or BivariateTag)
                    
                else if aGate.gateType == EllipseGateTag {
                    for event in 1...readAndParse!.totalEvents {
                        x = readAndParse!.fData[event][xVar]
                        xPrime = fDataToBivGraphicX(x)
                        y = readAndParse!.fData[event][yVar]
                        yPrime = fDataToBivGraphicY(y)
                        aPoint = NSMakePoint(xPrime, yPrime)
                        if aGate.rectGate!.rotationAngle != 0.0 {
                            let bPoint = aGate.rectGate!.rotatedPointFromGraphicPoint(aPoint)
                            // Is bPoint inside gate on rotated ellipse path?
                            if aGate.rectGate!.gatePath.contains(bPoint) {
                                let gIndex = event * totalGates + gateIndex
                                insideGate[gIndex] = 1 // Point is inside nonrotated ellipse gate.
                            }
                        } // End of nonzero rotation angle
                            
                        else if NSPointInRect(aPoint, aGate.rectGate!.bounds) {
                            if aGate.rectGate!.gatePath.contains(aPoint) {
                                let gIndex = event * totalGates + gateIndex
                                insideGate[gIndex] = 1 // Point is inside rotated ellipse gate.
                            }
                        } // End of zero rotation angle
                    }
                    
                } // End of if aGate.gateType == EllipseGateTag
                    
                else if aGate.gateType == PolygonGateTag {
                    for event in 1...readAndParse!.totalEvents {
                        x = readAndParse!.fData[event][xVar]
                        xPrime = fDataToBivGraphicX(x)
                        y = readAndParse!.fData[event][yVar]
                        yPrime = fDataToBivGraphicY(y)
                        aPoint = NSMakePoint(xPrime, yPrime)
                        if NSPointInRect(aPoint, aGate.polygonGate!.enclosingRect()) {
                            if aGate.polygonGate!.gatePath.contains(aPoint) {
                                let gIndex = event * totalGates + gateIndex
                                insideGate[gIndex] = 1
                            }
                        }
                        
                    } // end of loop over total events
                    
                } // End of if aGate.gateType == PolygonGateTag
                    
                else if aGate.gateType == QuadrantGateTag {
                    for event in 1...readAndParse!.totalEvents {
                        x = readAndParse!.fData[event][xVar]
                        xPrime = fDataToBivGraphicX(x)
                        y = readAndParse!.fData[event][yVar]
                        yPrime = fDataToBivGraphicY(y)
                        aPoint = NSMakePoint(xPrime, yPrime)
                        // pointInQuadGate will always return YES because the space occupied by all the quadRects in the quadGate span the entire space. The real action is that the gatedCount in each quadRect is incremented if aPoint is inside.
                        if aGate.quadGate!.pointInQuadGate(aPoint) {
                            let gIndex = event * totalGates + gateIndex
                            insideGate[gIndex] = 1
                        }
                        
                    } // end of loop over total events
                    
                } // End of if aGate.gateType == QuadrantGateTag
                    
                else {}
                
            } // End of if let aGate = gateDict[key] (end for one of the gates)
            
        } // End of for key in gateDict.keys (Loops over all the gates)
        
        for event in 1...readAndParse!.totalEvents {
            var gateSum = 0
            for index in 0..<totalGates {
                let gIndex = event * totalGates + index
                if insideGate[gIndex] == 1 {
                    gateSum += 1
                }
            } // End of loop over index
            
            if gateSum == gateDict.count {
                gatedEvent[event] = 1
                totalGatedEvents += 1
            }
            
        } // End of loop over totalEvents
        
        return totalGatedEvents
        
    } // End of createGatedEventArray
    
    func fDataToUniGraphic(_ x: Double) -> CGFloat {
        // Called from createGatedEventArray to convert an fData value into a univariate graphic value.
        var graphicValue: CGFloat = 0.0
        
        if histLimitsXg.xAxisType == LinearTag {
            let range = CGFloat(histLimitsXg.xMaxLin - histLimitsXg.xMinLin)
            if range > 0.0 {
                graphicValue = graphicView!.xOffset + CGFloat(x - histLimitsXg.xMinLin) * graphicView!.innerBoxWidth / range
            }
            
        } // End of "Linear"
            
        else if histLimitsXg.xAxisType == LogTag {
            let beginLogDecX = log10(histLimitsXg.xMinLog)
            let endLogDecX = log10(histLimitsXg.xMaxLog)
            let totalLogDecX = CGFloat(endLogDecX - beginLogDecX)
            if totalLogDecX > 0.0 {
                graphicValue = graphicView!.xOffset + CGFloat(log10(x) - beginLogDecX) * graphicView!.innerBoxWidth / totalLogDecX
            }
            
        } // End of "Log"
            
        else if histLimitsXg.xAxisType == LogicleTag || histLimitsXg.xAxisType == AsinhTag {
            let xLowerLimit = flx1P!.inverseWithScale(0.0)
            var xValue = x
            if x < xLowerLimit {
                xValue = xLowerLimit
            }
            else if x > histLimitsXg.T {
                xValue = histLimitsXg.T - 1.0
            }
            
            graphicValue = graphicView!.xOffset + graphicView!.innerBoxWidth * CGFloat(flx1P!.scaleWithValue(xValue))
            
        } // End of "Logicle" or "Asinh"
            
        else if histLimitsXg.xAxisType == HyperlogTag {
            var myScale = 0.0
            let xLowerLimit = hyx1P!.inverseWithScale(&myScale)
            var xValue = x
            if x < xLowerLimit {
                xValue = xLowerLimit
            }
            else if x > histLimitsXg.T {
                xValue = histLimitsXg.T - 1.0
            }
            
            graphicValue = graphicView!.xOffset + graphicView!.innerBoxWidth * CGFloat(hyx1P!.scaleWithValue(xValue))
            
        } // End of "Hyperlog"
            
        else {}
        
        return graphicValue
        
    } // End of fDataToUniGraphic
    
    func fDataToBivGraphicX(_ x: Double) -> CGFloat {
        // Called from createGatedEventArray to convert an fData value into a bivariate graphic value.
        var graphicValue: CGFloat = 0.0
        
        if histLimitsX2g.xAxisType == LinearTag {
            let range = CGFloat(histLimitsX2g.xMaxLin - histLimitsX2g.xMinLin)
            if range > 0.0 {
                graphicValue = graphicView!.xOffset + CGFloat(x - histLimitsX2g.xMinLin) * graphicView!.innerBoxWidth / range
            }
            
        } // End of "Linear"
            
        else if histLimitsX2g.xAxisType == LogTag {
            let beginLogDecX = log10(histLimitsX2g.xMinLog)
            let endLogDecX = log10(histLimitsX2g.xMaxLog)
            let totalLogDecX = CGFloat(endLogDecX - beginLogDecX)
            if totalLogDecX > 0.0 {
                graphicValue = graphicView!.xOffset + CGFloat(log10(x) - beginLogDecX) * graphicView!.innerBoxWidth / totalLogDecX
            }
            
        } // End of "Log"
            
        else if histLimitsX2g.xAxisType == LogicleTag || histLimitsX2g.xAxisType == AsinhTag {
            let xLowerLimit = flx2P!.inverseWithScale(0.0)
            var xValue = x
            if x < xLowerLimit {
                xValue = xLowerLimit
            }
            else if x > histLimitsX2g.T {
                xValue = histLimitsX2g.T - 1.0
            }
            
            graphicValue = graphicView!.xOffset + graphicView!.innerBoxWidth * CGFloat(flx2P!.scaleWithValue(xValue))
            
        } // End of "Logicle" or "Asinh"
            
        else if histLimitsX2g.xAxisType == HyperlogTag {
            var myScale = 0.0
            let xLowerLimit = hyx2P!.inverseWithScale(&myScale)
            var xValue = x
            if x < xLowerLimit {
                xValue = xLowerLimit
            }
            else if x > histLimitsX2g.T {
                xValue = histLimitsX2g.T - 1.0
            }
            
            graphicValue = graphicView!.xOffset + graphicView!.innerBoxWidth * CGFloat(hyx2P!.scaleWithValue(xValue))
            
        } // End of "Hyperlog"
            
        else {}
        
        return graphicValue
        
    } // End of fDataToBivGraphicX
    
    func fDataToBivGraphicY(_ y: Double) -> CGFloat {
        // Called from createGatedEventArray to convert an fData value into a bivariate graphic value.
        var graphicValue: CGFloat = 0.0
        
        if histLimitsY2g.xAxisType == LinearTag {
            let range = CGFloat(histLimitsY2g.xMaxLin - histLimitsY2g.xMinLin)
            if range > 0.0 {
                graphicValue = graphicView!.yOffset + CGFloat(y - histLimitsY2g.xMinLin) * graphicView!.innerBoxHeight / range
            }
            
        } // End of "Linear"
            
        else if histLimitsY2g.xAxisType == LogTag {
            let beginLogDecY = log10(histLimitsY2g.xMinLog)
            let endLogDecY = log10(histLimitsY2g.xMaxLog)
            let totalLogDecY = CGFloat(endLogDecY - beginLogDecY)
            if totalLogDecY > 0.0 {
                graphicValue = graphicView!.yOffset + CGFloat(log10(y) - beginLogDecY) * graphicView!.innerBoxHeight / totalLogDecY
            }
            
        } // End of "Log"
            
        else if histLimitsY2g.xAxisType == LogicleTag || histLimitsY2g.xAxisType == AsinhTag {
            let yLowerLimit = fly2P!.inverseWithScale(0.0)
            var yValue = y
            if y < yLowerLimit {
                yValue = yLowerLimit
            }
            else if y > histLimitsY2g.T {
                yValue = histLimitsY2g.T - 1.0
            }
            
            graphicValue = graphicView!.yOffset + graphicView!.innerBoxHeight * CGFloat(fly2P!.scaleWithValue(yValue))
            
        } // End of "Logicle" or "Asinh"
            
        else if histLimitsY2g.xAxisType == HyperlogTag {
            var myScale = 0.0
            let yLowerLimit = hyy2P!.inverseWithScale(&myScale)
            var yValue = y
            if y < yLowerLimit {
                yValue = yLowerLimit
            }
            else if y > histLimitsY2g.T {
                yValue = histLimitsY2g.T - 1.0
            }
            
            graphicValue = graphicView!.yOffset + graphicView!.innerBoxHeight * CGFloat(hyy2P!.scaleWithValue(yValue))
            
        } // End of "Hyperlog"
            
        else {}
        
        return graphicValue
        
    } // End of fDataToBivGraphicY
    
} // End of extension MainViewController (MainViewControllerExtGating)
