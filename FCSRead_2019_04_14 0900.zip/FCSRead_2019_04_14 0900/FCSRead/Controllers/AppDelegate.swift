//
//  AppDelegate.swift
//  FCSRead_2019_04_14 0900. Checked version for Github release (0.9)

//
//  Created by Mr. Salzman on 12/5/17.
//  Copyright © 2019 Gary Salzman. All rights reserved.
//
/* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 SOFTWARE. NOT TO BE USED FOR CLINICAL FLOW CYTOMETRY DATA. */

import Cocoa
// AppDelegate.swift
// Shared User Default Controller (instantiated in Main.storyboard) is used by the MainViewController to pass data from ReadAndParse.swift to HistogramSelectionTableViewController. It also contains the struct Controllers used by the Shared User Default Controller and the struct Preferences, which is used by the PreferencesViewController.

struct Controllers { // Keys used by Shared User Default Controller
    static let DataArrayKey = "DataArrayKey" // Key for theDataArray in MainViewController and HistogramSelectionTableViewController
    static let SelectedArrayKey = "SelectedArrayKey" // Key for 1P selectedArray [Int] in MainViewController and HistogramSelectionTableViewController
    static let SelectedArrayX2PKey = "SelectedArrayX2PKey" // Key for selectedArrayX2P // for bivariates
    static let SelectedArrayY2PKey = "SelectedArrayY2PKey" // Key for selectedArrayY2P
}

struct Preferences { // in AppDelegate.swift
    static let CountThresholdKey = "CountThresholdKey"
    static let DoCompensationKey = "DoCompensationKey"
    static let HistRange1PKey = "HistRange1PKey"
    static let HistRange2PKey = "HistRange2PKey"
    static let LogLikeScaleTransformKey = "LogLikeScaleTransformKey"
    static let LogicleTKey = "LogicleTKey"
    static let LogicleWKey = "LogicleWKey"
    static let LogicleMKey = "LogicleMKey"
    static let LogicleAKey = "LogicleAKey"
    static let AsinhTKey = "AsinhTKey"
    static let AsinhWKey = "AsinhWKey"
    static let AsinhMKey = "AsinhMKey"
    static let AsinhAKey = "AsinhAKey"
    static let HyperlogTKey = "HyperlogTKey"
    static let HyperlogWKey = "HyperlogWKey"
    static let HyperlogMKey = "HyperlogMKey"
    static let HyperlogAKey = "HyperlogAKey"
    static let XTKey = "XTKey"
    static let XWKey = "XWKey"
    static let XMKey = "XMKey"
    static let XAKey = "XAKey"
    static let YTKey = "YTKey"
    static let YWKey = "YWKey"
    static let YMKey = "YMKey"
    static let YAKey = "YAKey"
    static let LinearXMajorDivisionsKey = "LinearXMajorDivisionsKey"
    static let LinearXMinorDivisionsKey = "LinearXMinorDivisionsKey"
    static let LinearYMajorDivisionsKey = "LinearYMajorDivisionsKey"
    static let LinearYMinorDivisionsKey = "LinearYMinorDivisionsKey"
    static let PreferencesChangedKey = "PreferencesChangedKey"
    
    static let NumberPagesWhenPrintingKey = "NumberPagesWhenPrintingKey"
    static let ShowHeaderAndFooterKey = "ShowHeaderAndFooterKey"
    static let SpilloverPresentKey = "SpilloverPresentKey"
    
    static let OuterBoxWidthKey = "OuterBoxWidthKey"
    static let OuterBoxHeightKey = "OuterBoxHeightKey"
    static let InnerBoxWidthKey = "InnerBoxWidthKey"
    static let InnerBoxHeightKey = "InnerBoxHeightKey"
    static let XOffsetKey = "XOffsetKey"
    static let YOffsetKey = "YOffsetKey"
    static let FontNameKey = "FontNameKey"
    static let FontSizeKey = "FontSizeKey"
}

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {

    func applicationDidFinishLaunching(_ aNotification: Notification) {
        let defaults = UserDefaults.standard // class func
        let registrationDictionary : [String:Any] =
            [Preferences.HistRange1PKey:1024 as Int, // as AnyObject
             Preferences.HistRange2PKey:256 as Int, // as AnyObject
             Preferences.CountThresholdKey:10 as Int,
             Preferences.DoCompensationKey:true as Bool,
             Preferences.LogLikeScaleTransformKey:0 as Int,
             Preferences.LogicleTKey:300000.0 as Double,
             Preferences.LogicleWKey:1.0 as Double,
             Preferences.LogicleMKey:4.5 as Double,
             Preferences.LogicleAKey:0.0 as Double,
             Preferences.AsinhTKey:300000.0 as Double,
             Preferences.AsinhWKey:0.0 as Double,
             Preferences.AsinhMKey:4.5 as Double,
             Preferences.AsinhAKey:0.0 as Double,
             Preferences.HyperlogTKey:300000.0 as Double,
             Preferences.HyperlogWKey:1.0 as Double,
             Preferences.HyperlogMKey:4.5 as Double,
             Preferences.HyperlogAKey:0.0 as Double,
             Preferences.LinearXMajorDivisionsKey:4 as Int,
             Preferences.LinearXMinorDivisionsKey:4 as Int,
             Preferences.LinearYMajorDivisionsKey:4 as Int,
             Preferences.LinearYMinorDivisionsKey:4 as Int,
             Preferences.NumberPagesWhenPrintingKey:true as Bool,
             Preferences.ShowHeaderAndFooterKey:true as Bool,
             Preferences.SpilloverPresentKey:false as Bool,
             Preferences.OuterBoxHeightKey:510.0 as CGFloat,
             Preferences.OuterBoxWidthKey:560.0 as CGFloat,
             Preferences.InnerBoxWidthKey:400.0 as CGFloat,
             Preferences.InnerBoxHeightKey:400.0 as CGFloat,
             Preferences.XOffsetKey:120.0 as CGFloat,
             Preferences.YOffsetKey:70.0 as CGFloat,
             Preferences.FontNameKey:"Helvetica" as String,
             Preferences.FontSizeKey:12.0 as CGFloat
        ]
        defaults.register(defaults: registrationDictionary)
    }
    
    func applicationShouldOpenUntitledFile(_ sender: NSApplication) -> Bool {
        return false
    }

    func applicationWillTerminate(_ aNotification: Notification) {
    }
}

