//
//  MainViewController.swift - Controller for Model-View-Controller scheme
//  FCSRead
//
//  Created by Mr. Salzman on 12/5/17.
//  Copyright © 2019 Gary Salzman. All rights reserved.
//

/// MainViewController is the primary controller for the app.

import Cocoa

let BivariateTag = "Bivariate"
let UnivariateTag = "Univariate"

let RectangleGateTag = "RectangleGate"
let EllipseGateTag = "EllipseGate"
let PolygonGateTag = "PolygonGate"
let QuadrantGateTag = "QuadrantGate"
let NoGateTag = "NoGateTag"

let LinearTag = "Linear"
let LogTag = "Log"
let LogicleTag = "Logicle"
let AsinhTag = "Asinh"
let HyperlogTag = "Hyperlog"
let UnknownTag = "Unknown"

let PI_180 = Double.pi / 180.0

let GateNoHandle = 0
let GateHandleWidth: CGFloat = 6.0
let GateHandleHalfWidth: CGFloat = 3.0
let GateUpperLeftHandle = 1
let GateUpperMiddleHandle = 2
let GateUpperRightHandle = 3
let GateMiddleLeftHandle = 4
let GateMiddleRightHandle = 5
let GateLowerLeftHandle = 6
let GateLowerMiddleHandle = 7
let GateLowerRightHandle = 8

public var histLimitsDict: [Int:HistLimits] = [:] // [variate:HistLimits] (Global)

class MainViewController: NSViewController, GraphicSubviewDelegate {
    
    @IBOutlet weak var graphicView: GraphicView!
    @IBOutlet weak var selectHistograms: NSButton!
    weak var mainWindowController: MainWindowController?
    var graphicViewBounds = NSZeroRect // Set in showSelectedHistograms
    var theData: Data? // Raw data read from file.
    var readAndParse: ReadAndParse?
    let defaults = UserDefaults.standard // Shared User Defaults Controller instantiated in Main.storyboard
    var totalHistogramCount = 0 // Number of histograms selected for display. Set in displaySelectedHistograms below.
    var univariateHistogramCount = 0
    var bivariateHistogramCount = 0
    var quadrant = 0    // [0,3] corresponding to LL, LR, UL, UR quadrants.
    var quadrantCount = [Int]() // count in each quadrant
    var statisticsPanel: StatisticsPanel?
    var currentGateType = NoGateTag
    
    public var gateDict: [String:Gates] = [:] // Dictionary for gates; loaded from GraphicSubview and used by createGatedEventArray.
    public var insideGate: [Int] = [] // Event is inside one of the gates.
    public var isDataGated = false // Set by MainViewController
    public var totalGatedEvents = 0
    public var gatedEvent: [Int] = [] // [-10] if true, [0] if false.
    public var gateSequentially = false // sequential gating enabled. If it remains false, gating is in overlay mode.
    
    var flx1P: FastLogicle? // Used in MainViewControllerExtGating.swift
    var flx2P: FastLogicle?
    var fly2P: FastLogicle?
    var hyx1P: Hyperlog?
    var hyx2P: Hyperlog?
    var hyy2P: Hyperlog?
    var histLimitsXg = HistLimits() // g for gating
    var histLimitsYg = HistLimits()
    var histLimitsX2g = HistLimits()
    var histLimitsY2g = HistLimits()
    var histLimits: HistLimits?
    var colors: [NSColor] = [NSColor.red, NSColor.green, NSColor.blue, NSColor.cyan, NSColor.magenta, NSColor.orange, NSColor.purple, NSColor.yellow, NSColor.black, NSColor.lightGray]
    
    @IBOutlet weak var Filename: NSTextField!
    @IBOutlet weak var filenameValue: NSTextField!
    @IBOutlet weak var Variates: NSTextField!
    @IBOutlet weak var variatesValue: NSTextField!
    @IBOutlet weak var TotalEvents: NSTextField!
    @IBOutlet weak var totalEventsValue: NSTextField!
    
    weak var document: Document? { // Set by MainWindowController.(override var document).
        didSet {
            theData = document?.theData // link to document.theData read from file.
            if let mainWC = document?.windowControllers[0] {
                mainWindowController = mainWC as? MainWindowController
                graphicView.mainWindowController = mainWindowController
            }
            readAndParse = ReadAndParse(withData: theData!, mainViewController: self) // readAndParse instantiated here. This is the model component in Model-View-Controller. theData is parsed and interpreted here and ready for processing.
            if let myDataArray = readAndParse?.PnNS {
                theDataArray = myDataArray // Set links theDataArray to SharedUserDefaults controller key.
                Filename.stringValue = "Filename:" // Next few lines displayed after file is opened and before Select Histograms.
                filenameValue.stringValue = readAndParse!.filename
                Variates.stringValue = "Variates:"
                variatesValue.stringValue = String(readAndParse!.variates)
                TotalEvents.stringValue = "Total Events:"
                totalEventsValue.stringValue = String(readAndParse!.totalEvents)
            } else {
                print("MVC.document.didSet: theDataArray not set - exiting")
                exit(-1)
            }
        }
    }
    
    /// prepare(for segue: runs prior to segue and enables copying of mainViewController to HistogramSelectionTableViewController.
    ///   - segue: NSStoryboardSegue
    ///   - sender: Select Histograms button after File|Open dialog
    override func prepare(for segue: NSStoryboardSegue, sender: Any?) {
        variatesValue.stringValue = "" // So that these don't show up at top of histogram display
        totalEventsValue.stringValue = ""
        filenameValue.stringValue = ""
        if let histogramSelectionTVC = segue.destinationController as? HistogramSelectionTableViewController {
            histogramSelectionTVC.mainViewController = self
        }
    } // End of prepare(for segue:
    
    
    /// getMainViewController returns ManViewController. Called from GraphicSubview via delegate.
    /// - Returns: getMainViewController
    func getMainViewController() -> MainViewController {
        return self
    }
    
    var theDataArray: [String] { // Array of PnNS values: ["None", "FSC_H/FSC_Height", ...]
        get { return defaults.array(forKey: Controllers.DataArrayKey) as! [String] }
        set { defaults.set(newValue, forKey: Controllers.DataArrayKey) } // struct Controllers is in AppDelegate
    }
    @objc dynamic var selectedArray: [Int] { // Indexes of univariate histograms selected in HistogramSelectionTableViewController. "dynamic" required so system can intercept value changes.
        get { return defaults.array(forKey: Controllers.SelectedArrayKey) as! [Int] }
        set { defaults.set(newValue, forKey: Controllers.SelectedArrayKey) }
    }
    @objc dynamic var selectedArrayX2P: [Int] {// Indexes of the x-values of bivariate histograms selected in HistogramSelectionTableViewController.
        get { return defaults.array(forKey: Controllers.SelectedArrayX2PKey) as! [Int] }
        set { defaults.set(newValue, forKey: Controllers.SelectedArrayX2PKey) }
    }
    @objc dynamic var selectedArrayY2P: [Int] {// Indexes of the y-values of bivariate histograms selected in HistogramSelectionTableViewController.
        get { return defaults.array(forKey: Controllers.SelectedArrayY2PKey) as! [Int] }
        set { defaults.set(newValue, forKey: Controllers.SelectedArrayY2PKey) }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    /// displaySelectedHistograms. Called by HistogramSelectionTableViewController."Select" button.displayGraphics().
    func displaySelectedHistograms() {
        initializeHistLimitsDict()
        displaySelectedHistogramsWithoutInitialization()
    } // End of displaySelectedHistograms
    
    
    /// displaySelectedHistogramsWithoutInitialization. Calls graphicView to create the subviews (histogram displays).
    func displaySelectedHistogramsWithoutInitialization() { // MainVC
        univariateHistogramCount = selectedArray.count
        bivariateHistogramCount = selectedArrayX2P.count
        totalHistogramCount = univariateHistogramCount + bivariateHistogramCount
        graphicView.createSubviews(self) // creates instances of GraphicSubview and passes a link to MainViewController into graphicView.
        let windowFrame = windowFrameForGraphicView() // Sets the size of the expanded window frame.
        graphicView.setFrameSize(windowFrame.size)
        graphicViewBounds = graphicView.bounds
    } // End of displaySelectedHistogramsWithoutInitialization
    
    
    /// windowFrameForGraphicView sets mainWindowController's window frame to accommodate an enlarged GraphicView.
    /// - Returns: rect for the enlarged graphicView
    func windowFrameForGraphicView() -> NSRect {
        let screenFrame = NSScreen.main!.visibleFrame
        var windowFrame = NSZeroRect
        windowFrame.size.width  = GraphicView.maxCurrentPt.x
        windowFrame.size.height = GraphicView.maxCurrentPt.y + CGFloat(100.0)
        let newY: CGFloat = (screenFrame.size.height) - (windowFrame.size.height) // offset to bottom of enlarged GraphicView.
        windowFrame.origin.y = newY
        if newY < 0.0 {
            windowFrame.origin.y = 0.0
        }
        mainWindowController!.window!.setFrame(windowFrame, display: true, animate: false)
        // window should sit in upper left corner of screen.
        return windowFrame
    } // End of windowFrameForGraphicView
    
    
    /// generateBivariateHistogramWithXVariate generates a bivariate histogram. Called by GraphicSubview.delegate.convenience init for bivariate.
    /// - Parameters:
    ///   - xVariate: x axis variate for histogram
    ///   - yVariate: y axis variate for histogram
    /// - Returns: a bivariate histogram
    func generateBivariateHistogramWithXVariate(_ xVariate: Int, yVariate: Int) -> BivariateHistogram {
        let bivHist = BivariateHistogram(xVar: xVariate, yVar: yVariate, mViewController: self)
        return bivHist
    } // End of generateBivariateHistogramWithXVariate
    
    
    /// generateUnivariateHistogramWithVariate. Called by GraphicSubview.delegate.convenience init for univariate.
    /// - Parameter varNum: x axis variate for histogram
    /// - Returns: a univariate histogram
    func generateUnivariateHistogramWithVariate(_ varNum: Int) -> UnivariateHistogram { // MainViewController
        let uniHist = UnivariateHistogram(myVariate: varNum, mViewController: self, univariate: true)
        return uniHist
    } // End of generateUnivariateHistogramWithVariate
    
    
    /// initializeHistLimitsDict creates a histogram limits dictionary. Called from displaySelectedHistograms in MainViewController.
    func initializeHistLimitsDict() {
        for myVariate in 1...readAndParse!.variates {
            let histLimits = HistLimits(variate: myVariate)
            histLimits.xAxisLabel = readAndParse!.PnNS[myVariate]
            histLimitsDict[myVariate] = histLimits
        } // End of loop over myVariate
    } // End of initializeHistLimitsDict
    
    
    /// gateDictCount retrieves the number of elements in the gate dictionary. Called from GraphicSubview via delegate.
    /// - Returns: number of elements in the gate dictionary.
    func gateDictCount() -> Int {
        return gateDict.count
    }
    
    // MARK: *** Gating ***
    
    
    /// retrieveGateDictEntryForKey. Called from GRSVExtEditGates.editGateDictionaryEntry via protocol.
    ///
    /// - Parameter key: String identifying the dictionary key.
    /// - Returns: an instantiation of the Gates class.
    func retrieveGateDictEntryForKey(_ key: String) -> Gates {
        
        if let gate: Gates = gateDict[key] {
            return gate // Valid gate.
        } else {
            if gateDictCount() == 0 {
                print("There are no gate dictionary entries.")
            }
            let gate = Gates()
            return gate // Empty gate.
        }
    } // End of retrieveGateDictEntryForKey
    
    
    /// setGateDictEntryForKey adds an element to the gate dictionary within the Gates class. Called from GRSV (GraphicSubview) protocol.
    ///
    /// - Parameters:
    ///   - key: String
    ///   - gate: instantiation of the Gate class.
    func setGateDictEntryForKey(_ key: String, gate: Gates) {
        gateDict[key] = gate
        isDataGated = true
        showGateDictionaryEntries()
    } // End of func setGateDictEntryForKeyString
    
    
    /// showGateDictionaryEntries displays the gate dictionary entries.
    func showGateDictionaryEntries() {
        print("\nmVC.showGateDictionaryEntries.")
        if gateDictCount() == 0 {
            print(" There are no gate dictionary entries.")
            return
        }
        for key in gateDict.keys {
            if let aGate = gateDict[key] {
                print(" Gate: xVar \(aGate.xVariate) yVar \(aGate.yVariate) gateType \(aGate.gateType) gateActive \(aGate.gateActive)")
                // gateTypes: RectangleGateTag, EllipseGateTag, PolygonGateTag, QuadrantGateTag
                if aGate.gateType == RectangleGateTag {
                    print("  gateType \(aGate.gateType) \(String(describing: aGate.rectGate))")
                }
                else if aGate.gateType == EllipseGateTag {
                    print("  gateType \(aGate.gateType) \(String(describing: aGate.rectGate))")
                }
                else if aGate.gateType == PolygonGateTag {
                    print("  gateType \(aGate.gateType) \(String(describing: aGate.polygonGate))")
                }
                else if aGate.gateType == QuadrantGateTag {
                    print("  gateType \(aGate.gateType) \(String(describing: aGate.quadGate))")
                    print("aGate.quadGate!.quadRectArray: \(aGate.quadGate!.quadRectArray)")
                }
                else {}
            }
            else {
                print("aGate for key \(key) does not exist.")
            }
        }
    } // End of showGateDictionaryEntries
    
    
    /// updateGateDictEntries calls graphicView to update the gate dictionary entries. Called from GRSVExtRightMouse.gateTheDataSetup via protocol.
    func updateGateDictEntries() {
        print("mVC.updateGateDictEntries")
        graphicView.updateGateDictionaryEntries()
        showGateDictionaryEntries()
    } // End of updateGateDictEntries
    
    
    /// deleteGateDictEntryForKey removes an entry from the gate dictionary.
    ///
    /// - Parameter key: String which is the key.
    func deleteGateDictEntryForKey(_ key: String) {
        gateDict[key] = nil
        showGateDictionaryEntries()
    } // End of deleteGateDictEntryForKey
    
    
    /// deleteAllGateDictEntries empties the gate dictionary.
    func deleteAllGateDictEntries() {
        graphicView!.deleteAllGates()
        gateDict.removeAll()
        showGateDictionaryEntries()
    } // End of deleteAllGateDictEntries
    
    
    /// ungateTheData removes the effect of gating on the histograms. Called from GRSVExtRightMouse.ungateTheDataSetup via protocol.
    ///
    /// - Returns: boolean false for isDataGated.
    func ungateTheData() -> Bool { //
        isDataGated = false
        gateSequentially = false
        graphicView!.removeGatedHistograms()
        return isDataGated
    } // End of ungateTheData
    
    func statistics() {
        if statisticsPanel == nil {
            statisticsPanel = StatisticsPanel(windowNibName: "StatisticsPanel")
        }
        let totalEvents = Double(readAndParse!.totalEvents)
        statisticsPanel!.showWindow(nil)
        if currentGateType == QuadrantGateTag {
            statisticsPanel!.gateCountValueTextField.integerValue = 0
            statisticsPanel!.gateCountPercentTF.doubleValue = 0.0
            statisticsPanel!.q0ValueTextField.integerValue = quadrantCount[0] // Lower left quadrant
            statisticsPanel!.q1ValueTextField.integerValue = quadrantCount[1] // Lower right quadrant
            statisticsPanel!.q2ValueTextField.integerValue = quadrantCount[2] // Upper left quadrant
            statisticsPanel!.q3ValueTextField.integerValue = quadrantCount[3] // Upper right quadrant
            statisticsPanel!.q0PercentTF.doubleValue = 100.0 * Double(quadrantCount[0]) / totalEvents
            statisticsPanel!.q1PercentTF.doubleValue = 100.0 * Double(quadrantCount[1]) / totalEvents
            statisticsPanel!.q2PercentTF.doubleValue = 100.0 * Double(quadrantCount[2]) / totalEvents
            statisticsPanel!.q3PercentTF.doubleValue = 100.0 * Double(quadrantCount[3]) / totalEvents
        } else {
            statisticsPanel!.gateCountValueTextField.integerValue = totalGatedEvents
            statisticsPanel!.gateCountPercentTF.doubleValue = 100.0 * Double(totalGatedEvents) / totalEvents
            statisticsPanel!.q0ValueTextField.integerValue = 0 // Lower left quadrant
            statisticsPanel!.q1ValueTextField.integerValue = 0 // Lower right quadrant
            statisticsPanel!.q2ValueTextField.integerValue = 0 // Upper left quadrant
            statisticsPanel!.q3ValueTextField.integerValue = 0 // Upper right quadrant
            statisticsPanel!.q0PercentTF.doubleValue = 0.0
            statisticsPanel!.q1PercentTF.doubleValue = 0.0
            statisticsPanel!.q2PercentTF.doubleValue = 0.0
            statisticsPanel!.q3PercentTF.doubleValue = 0.0
        }
    } // End of statistics
    
    /// isTheDataGated?
    ///
    /// - Returns: boolean isTheDataGated
    func isTheDataGated() -> Bool { // ReturnsisDataGated
        return isDataGated
    } // End of isTheDataGated
    
    
    /// gateTheData applies gates to the data, recomputes gated histograms and refreshes displays. Called by rightClick:"Gate The Data With Overlay" in GraphicSubview:rightMouseDown. Gated histograms are overlaid on ungated histograms.
    ///
    /// - Returns: value of boolean isDataGated.
    func gateTheData() -> Bool { // MainViewController.swift
        if gateDict.count == 0 {
            isDataGated = false
        } else {
            isDataGated = true
            gateSequentially = false
            totalGatedEvents = createGatedEventArray()
            graphicView!.generateGatedHistograms()
        }
        print("MVC.gateTheData.isDataGated: \(isDataGated) gateDict.Count: \(gateDict.count) totalGatedEvents: \(totalGatedEvents)")
        return isDataGated
    } // End of gateTheData
    
    func gateTheQuadrantData() -> Bool { // Called from GRSVExtQuadMouseEvents.createQuadGateEvent
        if gateDict.count == 0 {
            isDataGated = false
        } else {
            isDataGated = true
            gateSequentially = false
            totalGatedEvents = createGatedEventArrayForQuadrants()
            graphicView!.generateGatedHistograms()
        }
        print("MVC.gateTheData.isDataGated: \(isDataGated) gateDict.Count: \(gateDict.count) totalGatedEvents: \(totalGatedEvents)")
        return isDataGated
    }
    
    
    /// gateTheDataSequentially removes unselected events from display. Can be repeated.
    ///
    /// - Returns: true of gateDict.count > 0; false if gateDict.count == 0
    func gateTheDataSequentially() -> Bool {
        if gateDict.count == 0 {
            isDataGated = false
        } else {
            isDataGated = true
            gateSequentially = true
            totalGatedEvents = createGatedEventArray()
            graphicView!.generateGatedHistograms()
        }
        print("MVC.gateTheData.isDataGated: \(isDataGated) gateDict.Count: \(gateDict.count) totalGatedEvents: \(totalGatedEvents)")
        return isDataGated
    } // End of gateTheDataSequentially
    
    
    /// createGatedEventArray creates an array of integers the length of fData[][] showing each event as gated or not gated. Called from gateTheData. A good event is AND among the members of the set of gates.
    ///
    /// - Returns: Int (1 for gated event and 0 for ungated event) totalGatedEvents
    func createGatedEventArray() -> Int { // MainViewController
        // Create array of integers: [value] is 1 for gated event. Called from gateTheData and gateTheDataSequentially. A good event is AND among the members of the set of gates.
        var xVar = 0
        var yVar = 0
        var x = 0.0
        var y = 0.0
        var xPrime: CGFloat = 0.0
        var yPrime: CGFloat = 0.0
        var aPoint = NSZeroPoint
        totalGatedEvents = 0
        let totalGates = gateDict.count
        
        gatedEvent = [Int](repeating: 0, count: (readAndParse!.totalEvents + 1)) // public vars
        insideGate = [Int](repeating: 0, count: (readAndParse!.totalEvents + 1) * totalGates)
        
        var gateIndex = -1
        for key in gateDict.keys { // Loops over all the gates.
            gateIndex += 1 // 0 is first aGate index
            if let aGate = gateDict[key] {
                xVar = aGate.xVariate
                yVar = aGate.yVariate
                histLimitsX2g = histLimitsDict[xVar]!
                flx2P = FastLogicle(myVar: xVar, myAxisType: BivariateTag)
                hyx2P = Hyperlog(myVar: xVar, myAxisType: BivariateTag)
                if yVar != 0 { // Applies only to bivariate
                    histLimitsY2g = histLimitsDict[yVar]!
                    fly2P = FastLogicle(myVar: yVar, myAxisType: BivariateTag)
                    hyy2P = Hyperlog(myVar: yVar, myAxisType: BivariateTag)
                }
                
                // agate.gatetype: RectangleGateTag, EllipseGateTag, PolygonGateTag, QuadrantGateTag. RectangleGates can be either univariate or bivariate. The other gates are bivariate.
                if aGate.gateType == RectangleGateTag {
                    currentGateType = RectangleGateTag
                    if aGate.rectGate!.gateSubType == UnivariateTag { // Univariate RectangleGate
                        flx1P = FastLogicle(myVar: xVar, myAxisType: UnivariateTag)
                        hyx1P = Hyperlog(myVar: xVar, myAxisType: UnivariateTag)
                        histLimitsXg = histLimitsDict[xVar]!
                        
                        let leftGate = aGate.rectGate!.bounds.origin.x
                        let rightGate = leftGate + aGate.rectGate!.bounds.size.width
                        
                        for event in 1...readAndParse!.totalEvents {
                            x = readAndParse!.fData[event][xVar]
                            xPrime = fDataToUniGraphic(x)
                            if xPrime >= leftGate && xPrime < rightGate { // inside gate.
                                let gIndex = event * totalGates + gateIndex
                                insideGate[gIndex] = 1 // Point is inside univariate rectangle gate.
                            }
                        } // end of loop over total events for UnivariateTag
                        
                    } // End of aGate.gateSubType == UnivariateTag
                        
                    else if aGate.rectGate!.gateSubType == BivariateTag { // Bivariate RectangleGate
                        
                        for event in 1...readAndParse!.totalEvents {
                            x = readAndParse!.fData[event][xVar]
                            xPrime = fDataToBivGraphicX(x)
                            y = readAndParse!.fData[event][yVar]
                            yPrime = fDataToBivGraphicY(y)
                            aPoint = NSMakePoint(xPrime, yPrime)
                            if NSPointInRect(aPoint, aGate.rectGate!.bounds) {
                                if aGate.rectGate!.gatePath.contains(aPoint) {
                                    let gIndex = event * totalGates + gateIndex
                                    insideGate[gIndex] = 1 // Point is inside bivariate rectangle gate.
                                }
                            } // End of NSPointInRect
                            
                        } // end of loop over total events for BivariateTage
                        
                    } // End of if aGate.rectGate?.gateSubType == BivariateTag
                        
                    else {}
                    
                } // End of RectangleGateTag (UnivariateTag or BivariateTag)
                    
                else if aGate.gateType == EllipseGateTag {
                    currentGateType = EllipseGateTag
                    for event in 1...readAndParse!.totalEvents {
                        x = readAndParse!.fData[event][xVar]
                        xPrime = fDataToBivGraphicX(x)
                        y = readAndParse!.fData[event][yVar]
                        yPrime = fDataToBivGraphicY(y)
                        aPoint = NSMakePoint(xPrime, yPrime)
                        if aGate.rectGate!.rotationAngle != 0.0 {
                            let bPoint = aGate.rectGate!.rotatedPointFromGraphicPoint(aPoint)
                            // Is bPoint inside gate on rotated ellipse path?
                            if aGate.rectGate!.gatePath.contains(bPoint) {
                                let gIndex = event * totalGates + gateIndex
                                insideGate[gIndex] = 1 // Point is inside nonrotated ellipse gate.
                            }
                        } // End of nonzero rotation angle
                            
                        else if NSPointInRect(aPoint, aGate.rectGate!.bounds) {
                            if aGate.rectGate!.gatePath.contains(aPoint) {
                                let gIndex = event * totalGates + gateIndex
                                insideGate[gIndex] = 1 // Point is inside rotated ellipse gate.
                            }
                        } // End of zero rotation angle
                    }
                    
                } // End of if aGate.gateType == EllipseGateTag
                    
                else if aGate.gateType == PolygonGateTag {
                    currentGateType = PolygonGateTag
                    for event in 1...readAndParse!.totalEvents {
                        x = readAndParse!.fData[event][xVar]
                        xPrime = fDataToBivGraphicX(x)
                        y = readAndParse!.fData[event][yVar]
                        yPrime = fDataToBivGraphicY(y)
                        aPoint = NSMakePoint(xPrime, yPrime)
                        if NSPointInRect(aPoint, aGate.polygonGate!.enclosingRect()) {
                            if aGate.polygonGate!.gatePath.contains(aPoint) {
                                let gIndex = event * totalGates + gateIndex
                                insideGate[gIndex] = 1
                            }
                        }
                        
                    } // end of loop over total events
                    
                } // End of if aGate.gateType == PolygonGateTag
                                        
                else {}
                
            } // End of if let aGate = gateDict[key] (end for one of the gates)
            
        } // End of for key in gateDict.keys (Loops over all the gates)
        
        for event in 1...readAndParse!.totalEvents {
            var gateSum = 0
            for index in 0..<totalGates {
                let gIndex = event * totalGates + index
                if insideGate[gIndex] == 1 {
                    gateSum += 1
                }
            } // End of loop over index
            
            if gateSum == gateDict.count {
                gatedEvent[event] = -10 // ***** temp was 1
                totalGatedEvents += 1
            }
            
        } // End of loop over totalEvents
        
        return totalGatedEvents
    } // End of createGatedEventArray
    
    /// createGatedEventArrayForQuadrants creates an array of integers the length of fData[][] showing each event as belonging to a quadrant or not gated. Called from gateTheData.
    ///
    /// - Returns: Int (quadrant gate integer [1...) for gated event and 0 for ungated event) totalGatedEvents
    func createGatedEventArrayForQuadrants() -> Int { // MainViewController
        // Create array of integers: [value] is 1 for gated event. Called from gateTheData and gateTheDataSequentially. A good event is AND among the members of the set of gates.
        var xVar = 0
        var yVar = 0
        var x = 0.0
        var y = 0.0
        var xPrime: CGFloat = 0.0
        var yPrime: CGFloat = 0.0
        var aPoint = NSZeroPoint
        totalGatedEvents = 0
        let totalGates = gateDict.count
        
        gatedEvent = [Int](repeating: -1, count: (readAndParse!.totalEvents + 1))  // public vars **** temp was 0
        insideGate = [Int](repeating: 0, count: (readAndParse!.totalEvents + 1) * totalGates)
        quadrantCount = [Int](repeating: 0, count: 4) // four quadrants starting at index 0
        var gateIndex = -1
        for key in gateDict.keys { // Loops over all the gates.
            gateIndex += 1 // 0 is first aGate index
            if let aGate = gateDict[key] {
                xVar = aGate.xVariate
                yVar = aGate.yVariate
                histLimitsX2g = histLimitsDict[xVar]!
                flx2P = FastLogicle(myVar: xVar, myAxisType: BivariateTag)
                hyx2P = Hyperlog(myVar: xVar, myAxisType: BivariateTag)
                if yVar != 0 { // Applies only to bivariate
                    histLimitsY2g = histLimitsDict[yVar]!
                    fly2P = FastLogicle(myVar: yVar, myAxisType: BivariateTag)
                    hyy2P = Hyperlog(myVar: yVar, myAxisType: BivariateTag)
                }
                
                if aGate.gateType == QuadrantGateTag {
                    currentGateType = QuadrantGateTag
                    for index in 0...3 {
                        for event in 1...readAndParse!.totalEvents {
                            x = readAndParse!.fData[event][xVar]
                            xPrime = fDataToBivGraphicX(x)
                            y = readAndParse!.fData[event][yVar]
                            yPrime = fDataToBivGraphicY(y)
                            aPoint = NSMakePoint(xPrime, yPrime)
                            quadrant = aGate.quadGate!.myPointInQuadGateRect(aPoint, index: index) // [0...3]
                            if quadrant >= 0 {
                                quadrantCount[quadrant] += 1
                                let gIndex = event * totalGates + gateIndex
                                insideGate[gIndex] = quadrant
                                gatedEvent[gIndex] = quadrant + 1 // [1...4] Note: gatedEvent[gIndex] = 0 reserved for non quadrant gates.
                            }
                        } // End of loop over totalEvents
                    } // End of loop over index

                    print("******* quadrantCount: \(quadrantCount)")
                    for event in 1...readAndParse!.totalEvents {
                        var gateSum = 0
                        for index in 0..<totalGates {
                            let gIndex = event * totalGates + index
                            if insideGate[gIndex] >= 0 {
                                gateSum += 1
                            }
                        } // End of loop over index
                    } // End of loop over totalEvents
                        
                    print("totalGatedEvents: \(totalGatedEvents)")
                    
                    return totalGatedEvents
                    
                } // End of if aGate.gateType == QuadrantGateTag
                else {}
            } // End of if let aGate = gateDict[key] (end for one of the gates)
        } // End of for key in gateDict.keys (Loops over all the gates)
        
        for event in 1...readAndParse!.totalEvents {
            var gateSum = 0
            for index in 0..<totalGates {
                let gIndex = event * totalGates + index
                if insideGate[gIndex] == 1 {
                    gateSum += 1
                }
            } // End of loop over index
            
            if gateSum == gateDict.count {
                totalGatedEvents += 1
            }            
        } // End of loop over totalEvents
        
        print("MainViewController.createGatedEventArrayForQuadrants.totalGatedEvents: \(totalGatedEvents)")
        
        return totalGatedEvents
    } // End of createGatedEventArrayForQuadrants
    
    
    /// fDataToUniGraphic converts an fData value into a univariate graphic value. Called from createGatedEventArray.
    ///
    /// - Parameter x: fData[][] value
    /// - Returns: CGFloat univariate graphic value.
    func fDataToUniGraphic(_ x: Double) -> CGFloat {
        var graphicValue: CGFloat = 0.0
        
        if histLimitsXg.xAxisType == LinearTag {
            let range = CGFloat(histLimitsXg.xMaxLin - histLimitsXg.xMinLin)
            if range > 0.0 {
                graphicValue = graphicView!.xOffset + CGFloat(x - histLimitsXg.xMinLin) * graphicView!.innerBoxWidth / range
            }
            
        } // End of "Linear"
            
        else if histLimitsXg.xAxisType == LogTag {
            let beginLogDecX = log10(histLimitsXg.xMinLog)
            let endLogDecX = log10(histLimitsXg.xMaxLog)
            let totalLogDecX = CGFloat(endLogDecX - beginLogDecX)
            if totalLogDecX > 0.0 {
                graphicValue = graphicView!.xOffset + CGFloat(log10(x) - beginLogDecX) * graphicView!.innerBoxWidth / totalLogDecX
            }
            
        } // End of "Log"
            
        else if histLimitsXg.xAxisType == LogicleTag || histLimitsXg.xAxisType == AsinhTag {
            let xLowerLimit = flx1P!.inverseWithScale(0.0)
            var xValue = x
            if x < xLowerLimit {
                xValue = xLowerLimit
            }
            else if x > histLimitsXg.T {
                xValue = histLimitsXg.T - 1.0
            }
            
            graphicValue = graphicView!.xOffset + graphicView!.innerBoxWidth * CGFloat(flx1P!.scaleWithValue(xValue))
            
        } // End of "Logicle" or "Asinh"
            
        else if histLimitsXg.xAxisType == HyperlogTag {
            var myScale = 0.0
            let xLowerLimit = hyx1P!.inverseWithScale(&myScale)
            var xValue = x
            if x < xLowerLimit {
                xValue = xLowerLimit
            }
            else if x > histLimitsXg.T {
                xValue = histLimitsXg.T - 1.0
            }
            
            graphicValue = graphicView!.xOffset + graphicView!.innerBoxWidth * CGFloat(hyx1P!.scaleWithValue(xValue))
            
        } // End of "Hyperlog"
            
        else {}
        
        return graphicValue
        
    } // End of fDataToUniGraphic
    
    /// fDataToBivGraphicX converts an fData value into a bivariate graphic value (x-axis). Called from createGatedEventArray.
    ///
    /// - Parameter x: fData[][] value
    /// - Returns: CGFloat bivariate graphic value for the x axis.
    func fDataToBivGraphicX(_ x: Double) -> CGFloat {
        var graphicValue: CGFloat = 0.0
        
        if histLimitsX2g.xAxisType == LinearTag {
            let range = CGFloat(histLimitsX2g.xMaxLin - histLimitsX2g.xMinLin)
            if range > 0.0 {
                graphicValue = graphicView!.xOffset + CGFloat(x - histLimitsX2g.xMinLin) * graphicView!.innerBoxWidth / range
            }
            
        } // End of "Linear"
            
        else if histLimitsX2g.xAxisType == LogTag {
            let beginLogDecX = log10(histLimitsX2g.xMinLog)
            let endLogDecX = log10(histLimitsX2g.xMaxLog)
            let totalLogDecX = CGFloat(endLogDecX - beginLogDecX)
            if totalLogDecX > 0.0 {
                graphicValue = graphicView!.xOffset + CGFloat(log10(x) - beginLogDecX) * graphicView!.innerBoxWidth / totalLogDecX
            }
            
        } // End of "Log"
            
        else if histLimitsX2g.xAxisType == LogicleTag || histLimitsX2g.xAxisType == AsinhTag {
            let xLowerLimit = flx2P!.inverseWithScale(0.0)
            var xValue = x
            if x < xLowerLimit {
                xValue = xLowerLimit
            }
            else if x > histLimitsX2g.T {
                xValue = histLimitsX2g.T - 1.0
            }
            
            graphicValue = graphicView!.xOffset + graphicView!.innerBoxWidth * CGFloat(flx2P!.scaleWithValue(xValue))
            
        } // End of "Logicle" or "Asinh"
            
        else if histLimitsX2g.xAxisType == HyperlogTag {
            var myScale = 0.0
            let xLowerLimit = hyx2P!.inverseWithScale(&myScale)
            var xValue = x
            if x < xLowerLimit {
                xValue = xLowerLimit
            }
            else if x > histLimitsX2g.T {
                xValue = histLimitsX2g.T - 1.0
            }
            
            graphicValue = graphicView!.xOffset + graphicView!.innerBoxWidth * CGFloat(hyx2P!.scaleWithValue(xValue))
            
        } // End of "Hyperlog"
            
        else {}
        
        return graphicValue
        
    } // End of fDataToBivGraphicX
    
    /// fDataToBivGraphicY converts an fData value into a bivariate graphic value for Y axis. Called from createGatedEventArray.
    ///
    /// - Parameter y: y axis fData[][] value
    /// - Returns: y axis bivariate graphic value.
    func fDataToBivGraphicY(_ y: Double) -> CGFloat {
        var graphicValue: CGFloat = 0.0
        
        if histLimitsY2g.xAxisType == LinearTag {
            let range = CGFloat(histLimitsY2g.xMaxLin - histLimitsY2g.xMinLin)
            if range > 0.0 {
                graphicValue = graphicView!.yOffset + CGFloat(y - histLimitsY2g.xMinLin) * graphicView!.innerBoxHeight / range
            }
            
        } // End of "Linear"
            
        else if histLimitsY2g.xAxisType == LogTag {
            let beginLogDecY = log10(histLimitsY2g.xMinLog)
            let endLogDecY = log10(histLimitsY2g.xMaxLog)
            let totalLogDecY = CGFloat(endLogDecY - beginLogDecY)
            if totalLogDecY > 0.0 {
                graphicValue = graphicView!.yOffset + CGFloat(log10(y) - beginLogDecY) * graphicView!.innerBoxHeight / totalLogDecY
            }
            
        } // End of "Log"
            
        else if histLimitsY2g.xAxisType == LogicleTag || histLimitsY2g.xAxisType == AsinhTag {
            let yLowerLimit = fly2P!.inverseWithScale(0.0)
            var yValue = y
            if y < yLowerLimit {
                yValue = yLowerLimit
            }
            else if y > histLimitsY2g.T {
                yValue = histLimitsY2g.T - 1.0
            }
            
            graphicValue = graphicView!.yOffset + graphicView!.innerBoxHeight * CGFloat(fly2P!.scaleWithValue(yValue))
            
        } // End of "Logicle" or "Asinh"
            
        else if histLimitsY2g.xAxisType == HyperlogTag {
            var myScale = 0.0
            let yLowerLimit = hyy2P!.inverseWithScale(&myScale)
            var yValue = y
            if y < yLowerLimit {
                yValue = yLowerLimit
            }
            else if y > histLimitsY2g.T {
                yValue = histLimitsY2g.T - 1.0
            }
            
            graphicValue = graphicView!.yOffset + graphicView!.innerBoxHeight * CGFloat(hyy2P!.scaleWithValue(yValue))
            
        } // End of "Hyperlog"
            
        else {}
        
        return graphicValue
        
    } // End of fDataToBivGraphicY

} // End of class MainViewController

