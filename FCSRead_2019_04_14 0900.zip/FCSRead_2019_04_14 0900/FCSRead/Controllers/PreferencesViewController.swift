//
//  PreferencesViewController.swift
//  FCSRead
//
//  Created by Mr. Salzman on 6/29/15.
//  Copyright © 2019 Gary Salzman. All rights reserved.
//
// PreferencesViewController is instantiated in Main.storyboard and enables the user to set and change a number of defaults.

import Cocoa

class PreferencesViewController: NSViewController {
    
    @IBOutlet weak var histRange1PTextField: NSTextField!
    @IBOutlet weak var histRange2PTextField: NSTextField!
    @IBOutlet weak var countThresholdTextField: NSTextField!
    @IBOutlet weak var doCompensationCheckBox: NSButton!
    @IBOutlet weak var logicleRadio: NSButton!
    @IBOutlet weak var asinhRadio: NSButton!
    @IBOutlet weak var hyperlogRadio: NSButton!
    @IBOutlet weak var TTextField: NSTextField!
    @IBOutlet weak var WTextField: NSTextField!
    @IBOutlet weak var MTextField: NSTextField!
    @IBOutlet weak var ATextField: NSTextField!
    @IBOutlet weak var numberOfLinearXMajorDivisionsTextField: NSTextField!
    @IBOutlet weak var numberOfLinearXMinorDivisionsTextField: NSTextField!
    @IBOutlet weak var numberofLinearYMajorDivisionsTextField: NSTextField!    
    @IBOutlet weak var numberofLinearYMinorDivisionsTextField: NSTextField!
    
    let defaults = UserDefaults.standard // class func
    
    var histRange1P: Int {
        get { return defaults.integer(forKey: Preferences.HistRange1PKey) }
        set { defaults.set(newValue, forKey: Preferences.HistRange1PKey) }
    }
    
    var histRange2P: Int {
        get { return defaults.integer(forKey: Preferences.HistRange2PKey) }
        set { defaults.set(newValue, forKey: Preferences.HistRange2PKey) }
    }
    
    var countThreshold: Int {
        get { return defaults.integer(forKey: Preferences.CountThresholdKey) }
        set { defaults.set(newValue, forKey: Preferences.CountThresholdKey) }
    }
    
    var doCompensation: Bool {
        get { return defaults.bool(forKey: Preferences.DoCompensationKey) }
        set { defaults.set(newValue, forKey: Preferences.DoCompensationKey) }
    }
    
    var logLikeScaleTransform: Int {
        get { return defaults.integer(forKey: Preferences.LogLikeScaleTransformKey) }
        set { defaults.set(newValue, forKey: Preferences.LogLikeScaleTransformKey) }
    }
    
    var logicleT: Double {
        get { return defaults.double(forKey: Preferences.LogicleTKey) }
        set { defaults.set(newValue, forKey: Preferences.LogicleTKey) }
    }
    
    var logicleW: Double {
        get { return defaults.double(forKey: Preferences.LogicleWKey) }
        set { defaults.set(newValue, forKey: Preferences.LogicleWKey) }
    }
    
    var logicleM: Double {
        get { return defaults.double(forKey: Preferences.LogicleMKey) }
        set { defaults.set(newValue, forKey: Preferences.LogicleMKey) }
    }
    
    var logicleA: Double {
        get { return defaults.double(forKey: Preferences.LogicleAKey) }
        set { defaults.set(newValue, forKey: Preferences.LogicleAKey) }
    }
    
    var asinhT: Double {
        get { return defaults.double(forKey: Preferences.AsinhTKey) }
        set { defaults.set(newValue, forKey: Preferences.AsinhTKey) }
    }
    
    var asinhW: Double {
        get { return defaults.double(forKey: Preferences.AsinhWKey) }
        set { defaults.set(newValue, forKey: Preferences.AsinhWKey) }
    }
    
    var asinhM: Double {
        get { return defaults.double(forKey: Preferences.AsinhMKey) }
        set { defaults.set(newValue, forKey: Preferences.AsinhMKey) }
    }
    
    var asinhA: Double {
        get { return defaults.double(forKey: Preferences.AsinhAKey) }
        set { defaults.set(newValue, forKey: Preferences.AsinhAKey) }
    }
    
    var hyperlogT: Double {
        get { return defaults.double(forKey: Preferences.HyperlogTKey) }
        set { defaults.set(newValue, forKey: Preferences.HyperlogTKey) }
    }
    
    var hyperlogW: Double {
        get { return defaults.double(forKey: Preferences.HyperlogWKey) }
        set { defaults.set(newValue, forKey: Preferences.HyperlogWKey) }
    }
    
    var hyperlogM: Double {
        get { return defaults.double(forKey: Preferences.HyperlogMKey) }
        set { defaults.set(newValue, forKey: Preferences.HyperlogMKey) }
    }
    
    var hyperlogA: Double {
        get { return defaults.double(forKey: Preferences.HyperlogAKey) }
        set { defaults.set(newValue, forKey: Preferences.HyperlogAKey) }
    }
    
    var numberOfLinearXMajorDivisions: Int {
        get { return defaults.integer(forKey: Preferences.LinearXMajorDivisionsKey) }
        set { defaults.set(newValue, forKey: Preferences.LinearXMajorDivisionsKey) }
    }
    
    var numberOfLinearXMinorDivisions: Int {
        get { return defaults.integer(forKey: Preferences.LinearXMinorDivisionsKey) }
        set { defaults.set(newValue, forKey: Preferences.LinearXMinorDivisionsKey) }
    }
    
    var numberOfLinearYMajorDivisions: Int {
        get { return defaults.integer(forKey: Preferences.LinearYMajorDivisionsKey) }
        set { defaults.set(newValue, forKey: Preferences.LinearYMajorDivisionsKey) }
    }
    
    var numberOfLinearYMinorDivisions: Int {
        get { return defaults.integer(forKey: Preferences.LinearYMinorDivisionsKey) }
        set { defaults.set(newValue, forKey: Preferences.LinearYMinorDivisionsKey) }
    }
    
    var numberPagesWhenPrinting: Bool {
        get { return defaults.bool(forKey: Preferences.NumberPagesWhenPrintingKey) }
        set { defaults.set(newValue, forKey: Preferences.NumberPagesWhenPrintingKey) }
    }
    
    var showHeaderAndFooter: Bool {
        get { return defaults.bool(forKey: Preferences.ShowHeaderAndFooterKey) }
        set { defaults.set(newValue, forKey: Preferences.ShowHeaderAndFooterKey) }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear() {
        super.viewWillAppear()
        initialValues()
    }
    
    /// initialValues set the initial values of the preferences.
    func initialValues() {
        numberOfLinearXMajorDivisionsTextField.integerValue = numberOfLinearXMajorDivisions
        numberOfLinearXMinorDivisionsTextField.integerValue = numberOfLinearXMinorDivisions
        numberofLinearYMajorDivisionsTextField.integerValue = numberOfLinearYMajorDivisions
        numberofLinearYMinorDivisionsTextField.integerValue = numberOfLinearYMinorDivisions
        
        switch logLikeScaleTransform {
        case 0:
            logicleRadio.state = NSControl.StateValue.on
            TTextField.doubleValue = logicleT
            WTextField.doubleValue = logicleW
            MTextField.doubleValue = logicleM
            ATextField.doubleValue = logicleA
        case 1:
            asinhRadio.state = NSControl.StateValue.on
            TTextField.doubleValue = asinhT
            WTextField.doubleValue = asinhW
            MTextField.doubleValue = asinhM
            ATextField.doubleValue = asinhA
        case 2:
            hyperlogRadio.state = NSControl.StateValue.on
            TTextField.doubleValue = hyperlogT
            WTextField.doubleValue = hyperlogW
            MTextField.doubleValue = hyperlogM
            ATextField.doubleValue = hyperlogA
        default:
            break
        }
    }
    
    /// logLikeScaleRadioButtonList has no parameters and returns an array of radio buttons. It is called by logLikeButtonPressed.
    /// - returns: an array of three radio buttons
    func logLikeScaleRadioButtonList() -> Array<NSButton> {
        return [logicleRadio, asinhRadio, hyperlogRadio]
    } // End of logLikeScaleRadioButtonList
    
    /// logLikeButtonPressed turns a radio button on or off
    /// - parameter sender: accepts a radio button press
    @IBAction func logLikeButtonPressed(_ sender: NSButton) { // buttons: logicleRadio, asinhRadio, or hyperlogRadio
        for aButton in logLikeScaleRadioButtonList() {
            if aButton == sender {
                aButton.state = NSControl.StateValue.on
                logLikeScaleTypeFromRadioState(button: aButton)
            } else {
                aButton.state = NSControl.StateValue.off
            }
        }
    } // End of logLikeButtonPressed
    
    /// logLikeScaleTypeFromRadioState sets the transform text fields for a given radio button. It is called from logLikeButtonPressed.
    /// - parameter button: one of the radio buttons
    func logLikeScaleTypeFromRadioState(button: NSButton) {
        for button in logLikeScaleRadioButtonList() {
            if button.state == NSControl.StateValue.on {
                switch button {
                case logicleRadio:
                    logLikeScaleTransform = 0
                    TTextField.doubleValue = logicleT
                    WTextField.doubleValue = logicleW
                    MTextField.doubleValue = logicleM
                    ATextField.doubleValue = logicleA
                case asinhRadio:
                    logLikeScaleTransform = 1
                    TTextField.doubleValue = asinhT
                    WTextField.doubleValue = asinhW
                    MTextField.doubleValue = asinhM
                    ATextField.doubleValue = asinhA
                case hyperlogRadio:
                    logLikeScaleTransform = 2
                    TTextField.doubleValue = hyperlogT
                    WTextField.doubleValue = hyperlogW
                    MTextField.doubleValue = hyperlogM
                    ATextField.doubleValue = hyperlogA
                default:
                    print("Preferences.logLikeScaleTypeFromRadioState failed -> exiting")
                    exit(-1)
                }
            }
        }
    } // End of logLikeScaleTypeFromRadioState
    
    /// prefsDone is the Done button on the preferences panel. It dismisses the panel.
    /// - parameter sender: any
    @IBAction func prefsDone(_ sender: AnyObject) { // Apply Preferences Button
        dismiss(self)
    }
    
    /// tValueAction updates the transform value depending on the type of transform. logLikeScaleTransform is set in Preferences.logLikeScaleTransformKey.
    @IBAction func tValueAction(_ sender: AnyObject) {
        // triggered by change in T.
        // We need to update the value of one of _logicleT,
        // _asinhT, or _hyperlogT determined by value of
        // _logLikeScaleTransform.
        switch logLikeScaleTransform {
        case 0:
            logicleT = TTextField.doubleValue
        case 1:
             asinhT = TTextField.doubleValue
        case 2:
            hyperlogT = TTextField.doubleValue
        default:
            break
        }
    }
    
    @IBAction func wValueAction(_ sender: AnyObject) {
        switch logLikeScaleTransform {
        case 0:
            logicleW = WTextField.doubleValue
        case 1:
            asinhW = WTextField.doubleValue
        case 2:
            hyperlogW = WTextField.doubleValue
        default:
            break
        }
    }
    
    @IBAction func mValueAction(_ sender: AnyObject) {
        switch logLikeScaleTransform {
        case 0:
            logicleM = MTextField.doubleValue
        case 1:
            asinhM = MTextField.doubleValue
        case 2:
            hyperlogM = MTextField.doubleValue
        default:
            break
        }
    }
    
    @IBAction func aValueAction(_ sender: AnyObject) {
        switch logLikeScaleTransform {
        case 0:
            logicleA = ATextField.doubleValue
        case 1:
            asinhA = ATextField.doubleValue
        case 2:
            hyperlogA = ATextField.doubleValue
        default:
            break
        }
    }
    
    /// prefsReset resets responds to the Reset button and resets preferences to initial values.
    @IBAction func prefsReset(_ sender: AnyObject) {
        defaults.removeObject(forKey: Preferences.HistRange1PKey)
        defaults.removeObject(forKey: Preferences.HistRange2PKey)
        defaults.removeObject(forKey: Preferences.CountThresholdKey)
        defaults.removeObject(forKey: Preferences.DoCompensationKey)
        defaults.removeObject(forKey: Preferences.LogLikeScaleTransformKey)
        defaults.removeObject(forKey: Preferences.LogicleTKey)
        defaults.removeObject(forKey: Preferences.LogicleWKey)
        defaults.removeObject(forKey: Preferences.LogicleMKey)
        defaults.removeObject(forKey: Preferences.LogicleAKey)
        defaults.removeObject(forKey: Preferences.AsinhTKey)
        defaults.removeObject(forKey: Preferences.AsinhWKey)
        defaults.removeObject(forKey: Preferences.AsinhMKey)
        defaults.removeObject(forKey: Preferences.AsinhAKey)
        defaults.removeObject(forKey: Preferences.HyperlogTKey)
        defaults.removeObject(forKey: Preferences.HyperlogWKey)
        defaults.removeObject(forKey: Preferences.HyperlogMKey)
        defaults.removeObject(forKey: Preferences.HyperlogAKey)
        defaults.removeObject(forKey: Preferences.LinearXMajorDivisionsKey)
        defaults.removeObject(forKey: Preferences.LinearXMinorDivisionsKey)
        defaults.removeObject(forKey: Preferences.LinearYMajorDivisionsKey)
        defaults.removeObject(forKey: Preferences.LinearYMinorDivisionsKey)
        initialValues() // For logLikeScaleTransform
    }
    
} // End of PreferencesViewController
