//
//  RectGate.swift enables creation and manipulation of rectangle and ellipse gates.
//  FCSRead
//  Uses RectGateExtSupport for support functions.
//
//  Created by Mr. Salzman on 1/7/16.
//  Copyright © 2019 Gary Salzman. All rights reserved.
//
//  Creation and drawing of rectangular gates

import Cocoa

//let GateNoHandle = 0 // These are defined as global in Document.swift
//let GateHandleWidth: CGFloat = 6.0
//let GateHandleHalfWidth: CGFloat = 3.0
//
//let GateUpperLeftHandle = 1
//let GateUpperMiddleHandle = 2
//let GateUpperRightHandle = 3
//let GateMiddleLeftHandle = 4
//let GateMiddleRightHandle = 5
//let GateLowerLeftHandle = 6
//let GateLowerMiddleHandle = 7
//let GateLowerRightHandle = 8

// PI and PI_180 (PI/180.0) are global constants defined in Document.

class RectGate: NSObject {
    
    weak var myView: GraphicSubview?
    weak var histGraphic: HistogramGraphic?
    var gateRotationWindowController: GateRotationWindowController?
    var flippings = Array(repeating: 0, count: 9)
    // realBounds is the equivalent of bounds but in real units (fData[][]). bounds will be transformed to the equivalent realBounds every time the changeAxes is called. realBounds will be updated every time the bounds are changed by editing or dragging. originalRealBounds are set when rectGate created and restored when FRAxesChangedPanel:Reset is called.
    var realBounds = NSZeroRect // bounds in fData units
    var bounds = NSZeroRect // rect gate bounds in graphic units
    var originalRealBounds = NSZeroRect
    var rotatedEllipseBounds = NSZeroRect
    var x2p = [Float]() // x double prime
    var y2p = [Float]() // y double prime
    var x = [Float]() // graphical units (coordinates of the handle points)
    var y = [Float]() // graphical units
    var drawingStroke = false
    // These next three are probably not needed but are referenced in FRGraphicView: fDataToUniGraphic: or fDataToBivGraphicX: or Y:. They are referenced as aGate.rectGate.scaleX, etc.
    var scaleX: CGFloat = 0.0 // innerBoxWidth/histRange1P
    var scaleX2P: CGFloat = 0.0 // innerBoxWidth/histRange2P
    var scaleY2P: CGFloat = 0.0 // innerBoxHeight/histRange2P
    
    var xOffset: CGFloat = 0.0
    var yOffset: CGFloat = 0.0
    var strokeColor: NSColor = NSColor.red
    var strokeWidth: CGFloat = 0.0
    
    var gateType = "" // one of RectangleGateTag or EllipseGateTag
    var gateSubType = "" // UnivariateTag (only for RectangleGate) or BivariateTag
    var gatePath = NSBezierPath()
    var gateCenter = NSZeroPoint
    var oldRotationAngle: CGFloat = 0.0 // degrees
    var rotationAngle: CGFloat = 0.0 // degrees
    
    var leftEdgeInnerBox: CGFloat = 0.0 // Edges of the histogramBox (inner box)
    var rightEdgeInnerBox: CGFloat = 0.0
    var bottomEdgeInnerBox: CGFloat = 0.0
    var topEdgeInnerBox: CGFloat = 0.0
    
    var left: CGFloat = 0.0 // handle point locations
    var right: CGFloat = 0.0
    var bottom: CGFloat = 0.0
    var top: CGFloat = 0.0
    
    
    override init() {
        super.init()
    }
    
    
    /// convenience init is initialized by GraphicSubview.mouseDown. frameRect is initially NSZeroRect. bounds of the gate are set within GraphicSubview.createRectGateEvent.
    ///
    /// - Parameters:
    ///   - frameRect: initially NSZeroRect
    ///   - view: GraphicSubview
    convenience init(frameRect: NSRect, view:GraphicSubview) {
        self.init()
        bounds = frameRect
        myView = view
        histGraphic = myView?.histogramGraphic
        drawingStroke = true
        strokeColor = NSColor.red
        strokeWidth = 1.0
        gateType = "RectangleGate" // Default
        x2p = Array(repeating: 0.0, count: 9)
        y2p = Array(repeating: 0.0, count: 9)
        x = Array(repeating: 0.0, count: 9)
        y = Array(repeating: 0.0, count: 9)
        
        leftEdgeInnerBox = histGraphic!.xOffset
        rightEdgeInnerBox = leftEdgeInnerBox + histGraphic!.innerBoxWidth
        bottomEdgeInnerBox = histGraphic!.yOffset
        topEdgeInnerBox = bottomEdgeInnerBox + histGraphic!.innerBoxHeight
        
    } // End of convenience init
    
    
    /// bezierPathForDrawing. Called from drawContentsInView to create an NSBezierPath for a RectangleGate or EllipseGate
    ///
    /// - Returns: NSBezierPath
    func bezierPathForDrawing() -> NSBezierPath {
        // Called from drawContentsInView
        if gateType == "RectangleGate" {
            gatePath = NSBezierPath(rect: bounds)
        }
        else if gateType == "EllipseGate" {
            if rotationAngle == 0.0 {
                gatePath = NSBezierPath(ovalIn: bounds)
            }
            else { // Rotation is [-90.0, 90.0] degrees.
                let xForm = NSAffineTransform()
                rotatedEllipseBounds = NSMakeRect(-0.5 * bounds.size.width, -0.5 * bounds.size.height, bounds.size.width, bounds.size.height)
                gatePath = NSBezierPath(ovalIn: rotatedEllipseBounds)
                xForm.translateX(by: gateCenter.x, yBy: gateCenter.y)
                xForm.rotate(byDegrees: rotationAngle)
                xForm.concat()
            }
        } // End of else if gateType == "EllipseGate"
            
        else {}
        
        gatePath.lineWidth = strokeWidth
        strokeColor = NSColor.red

        return gatePath
        
    } // End of bezierPathForDrawing
    
    
    /// drawContentsInView is called from GraphicSubview.drawRect to draw to RectangleGate or EllipseGate
    ///
    /// - Parameter view: GraphicSubview
    func drawContentsInView(_ view: GraphicSubview) {
        // Called from GraphicSubview.drawRect
        if view != myView {
            return
        }
        // bezierPathForDrawing draws either a rectangular gate or an ellipse gate or rotated ellipse gate.
        gatePath = bezierPathForDrawing() // method above
        if !gatePath.isEmpty { // not empty
            if drawingStroke {
                NSColor.red.setStroke()
                gatePath.stroke()
            }
        }
        myView!.setNeedsDisplay(myView!.bounds)
        
    } // End of drawContentsInView
    
    
    /// myDrawingBounds is called by GraphicSubview.createRectGateEvent to calculate the drawingBounds
    ///
    /// - Returns: NSRect drawingBounds
    func myDrawingBounds() -> NSRect {
        // Called by GraphicSubview.createRectGateEvent
        var outset = GateHandleHalfWidth
        if drawingStroke {
            let strokeOutset = 0.5 * strokeWidth
            if strokeOutset > outset {
                outset = strokeOutset
            }
        }
        
        let inset = -outset
        var drawingBounds = NSInsetRect(bounds, inset, inset)
        drawingBounds.size.width += 1.0
        drawingBounds.size.height += 1.0
        
        return drawingBounds
        
    } // End of myDrawingBounds
    
    // MARK: - *** Rectangle Resize & Translate ***
    
    
    /// resizeByMovingHandle enables resizing rectangular gate or nonrotated ellipse gate. Chain of events: GrSV.mouseDown->GrSV.gateUnderPoint<-> gate.handleUnderPoint GrSV.gateUnderPoint->GrSV.resizeRectGate-> gate.resizeByMovingHandle.
    ///
    /// - Parameters:
    ///   - handle: the handle on the gate
    ///   - point: mouse location point
    func resizeByMovingHandle(_ handle: inout Int, point: inout NSPoint) {
        // Start with current bounds, which is the rect for the rectangle gate.
        
        if myView?.histogramType == UnivariateTag {
            // pin the y-origin to the bottom of the innerBox
            bounds.origin.y = histGraphic!.yOffset
        }
        
        // Is the user changing the width of the rectangle from the left side?
        if handle == GateUpperLeftHandle || handle == GateMiddleLeftHandle || handle == GateLowerLeftHandle {
            // Change the left edge of the gate to keep it inside the innerBox.
            if point.x < histGraphic!.xOffset {
                point.x = histGraphic!.xOffset
            }
            bounds.size.width = NSMaxX(bounds) - point.x
            // NSMaxX returns bounds.origin.x + bounds.size.width
            bounds.origin.x = point.x
        } // End of changing width from left side
        
        // Is the user changing the width of the rectangle from the right side?
        else if handle == GateUpperRightHandle || handle == GateMiddleRightHandle || handle == GateLowerRightHandle {
            // Change the right edge of the gate to keep it inside the innerBox.
            if point.x > histGraphic!.xOffset + histGraphic!.innerBoxWidth {
                point.x = histGraphic!.xOffset + histGraphic!.innerBoxWidth
            }
            bounds.size.width = point.x - bounds.origin.x
        } // End of changing width from right side
        
        // Was the rectangle flipped left to right?
        if bounds.size.width < 0.0 {
            flipLeftRight()
            handle = flippings[handle]
            // Make the rectangle's width positive again.
            bounds.size.width = -bounds.size.width
            bounds.origin.x -= bounds.size.width
            
        } // End of was the rectangle flipped left to rigth?
        
        // Is the user changing the height of the rectangle from the top?
        if handle == GateUpperLeftHandle || handle == GateUpperMiddleHandle || handle == GateUpperRightHandle {
            // Change the top edge of the rectangle gate to keep it inside the histogram box
            if point.y > histGraphic!.yOffset + histGraphic!.innerBoxHeight {
                point.y = histGraphic!.yOffset + histGraphic!.innerBoxHeight
            }
            bounds.size.height = point.y - bounds.origin.y
            
        } // End of changing height from the top.
        
        // Is the user changing the height of the rectangle from the bottom?
        else if handle == GateLowerLeftHandle || handle == GateLowerMiddleHandle || handle == GateLowerRightHandle {
            // Change the bottom edge of the gate to keep it inside the histogram box.
            if point.y < histGraphic!.yOffset {
                point.y = histGraphic!.yOffset
            }
            bounds.size.height = NSMaxY(bounds) - point.y
            bounds.origin.y = point.y
        } // End of changing height from the bottom.
            
        else {}
        
        // Was the rectangle gate flipped upside down?
        if bounds.size.height < 0.0 {
            flipTopBottom()
            handle = flippings[handle]
            // Make the rectangle gate's height positive again.
            bounds.size.height = -bounds.size.height
            bounds.origin.y -= bounds.size.height
        }
        
    } // End of resizeByMovingHandle
    
    
    /// translateRect enables translation of the rect on the histogram. Called from GraphicSubview.moveRectGateWithEvent. histGraphic is myView?.histogramGraphic.
    ///
    /// - Parameters:
    ///   - deltaX: amount to translate in x-direction
    ///   - deltaY: amount to translate in y-direction
    func translateRect(_ deltaX: inout CGFloat, deltaY:inout CGFloat) {
        if myView?.histogramType == UnivariateTag {
            // pin the y origin to the bottom of the histogram box.
            bounds.origin.y = histGraphic!.yOffset
            deltaY = 0.0
        }
        
        // Rectangle gate edges after translation
        let leftEdge = bounds.origin.x + deltaX
        let rightEdge = leftEdge + bounds.size.width
        let bottomEdge = bounds.origin.y + deltaY
        let topEdge = bottomEdge + bounds.size.height
        
        // Keep rectGate inside histogramBox
        if leftEdge < histGraphic!.xOffset || rightEdge > histGraphic!.xOffset + histGraphic!.innerBoxWidth {
            deltaX = 0.0
        }
        if bottomEdge < histGraphic!.yOffset || topEdge > histGraphic!.yOffset + histGraphic!.innerBoxHeight {
            deltaY = 0.0
        }
        
        // Offset the bounds rect and the gateCenter.
        bounds = NSOffsetRect(bounds, deltaX, deltaY)
        gateCenter.x += deltaX
        gateCenter.y += deltaY
        
    } // End of translateRect
    
    // MARK: - *** Ellipse Rotation ***
    
    /// rotateEllipseGateSetup sets up ellipseGate for rotation.
    ///
    /// - Parameter sender: left mouseDown on popup menu.
    func rotateEllipseGateSetup(_ sender: AnyObject) {
        print("RectGate.rotateEllipseGateSetup")
        myView!.gateActionMode = 1 // start editing
        myView!.currentGateTypeSetting = Int(sender.tag!)
        showEllipseGateRotationWindow()
        
    } // End of rotateEllipseGateSetup
    
    
    /// showEllipseGateRotationWindow initializes the gate rotation window and displays it.
    func showEllipseGateRotationWindow() {
        if (gateRotationWindowController == nil) {
            gateRotationWindowController = GateRotationWindowController(windowNibName: "GateRotationWindowController")
        }
        gateRotationWindowController!.passTheGate(self, subview: myView!)
        gateRotationWindowController!.showWindow(nil)
        rotationAngle = gateRotationWindowController!.angle
        
    } // End of showEllipseGateRotationWindow
    
    // MARK: - *** Ellipse Resize & Translation ***
    
    
    /// resizeByMovingRotatedEllipseHandle enables resizing of rotated ellipse. Chain of events: [GraphicSubview.mouseDown]->[selectAndTrackEllipseMouse...] ->[GraphicSubview.rotatedEllipseGateUnderPoint]<->[gate.whichHandleOnRotatedEllipse] [GrSubview. rotatedEllipseGateUnderPoint]->[GrSubview.resizeRectGate]-> [gate.resizeByMovingRotatedEllipseHandle].
    ///
    /// - Parameters:
    ///   - handle: handle being grabbed by left mouse
    ///   - point: mouseDown point
    func resizeByMovingRotatedEllipseHandle(_ handle: inout Int, point: inout NSPoint) {
        // The four corner handles are hidden as soon as ellipse rotation starts.
        point = constrainPointToHistogramBox(point)
        // Create rotatedPoint in the rotated coordinate system.
        let rotatedPoint = rotatedPointFromGraphicPoint(point)
        
        var deltaX: CGFloat = 0.0 // In rotated coordinate system.
        var deltaY: CGFloat = 0.0
        
        coordinatesOfRotatedEllipseGateHandlesFromGraphicBounds(bounds)
        
        // Is the user changing the width of the rectangle from the left side?
        if handle == GateMiddleLeftHandle {
            deltaX = rotatedPoint.x - CGFloat(x2p[4]) // Make changes.
            deltaY = rotatedPoint.y - CGFloat(y2p[4])
        
            let newDelta: NSPoint = constrainRotatedEllipseToHistogramBoxGivenDeltaPoint(NSMakePoint(deltaX, deltaY))
            if newDelta.x != 0.0 && newDelta.y != 0.0 {
                x2p[1] += Float(newDelta.x)
                y2p[1] += Float(newDelta.y)
                x2p[4] += Float(newDelta.x)
                y2p[4] += Float(newDelta.y)
                x2p[6] += Float(newDelta.x)
                y2p[6] += Float(newDelta.y)
                x2p[2] = 0.5*Float(newDelta.x)
                x2p[7] = x2p[2]
                
                gateCenter.x += 0.5 * newDelta.x * CGFloat(cosf(Float(PI_180) * Float(rotationAngle)))
                gateCenter.y += 0.5 * newDelta.x * CGFloat(sinf(Float(PI_180) * Float(rotationAngle)))
            }
            
            rotatedEllipseBounds = NSMakeRect(CGFloat(x2p[6]), CGFloat(y2p[6]), CGFloat(x2p[5] - x2p[4]), CGFloat(y2p[2] - y2p[7]))
            bounds = graphicBoundsFromRotatedEllipseBounds()
            
        } // End of if handle==GateMiddleLeftHandle
        
        // Is the user changing the width of the rectangle from the right side?
        else if handle == GateMiddleRightHandle {
            deltaX = rotatedPoint.x - CGFloat(x2p[5]) // Make changes.
            deltaY = rotatedPoint.y - CGFloat(y2p[5])
            
            let newDelta: NSPoint = constrainRotatedEllipseToHistogramBoxGivenDeltaPoint(NSMakePoint(deltaX, deltaY))
            if newDelta.x != 0.0 && newDelta.y != 0.0 {
                x2p[3] += Float(newDelta.x)
                y2p[3] += Float(newDelta.y)
                x2p[5] += Float(newDelta.x)
                y2p[5] += Float(newDelta.y)
                x2p[8] += Float(newDelta.x)
                y2p[8] += Float(newDelta.y)
                x2p[2] = 0.5*Float(newDelta.x)
                x2p[7] = x2p[2]
                
                gateCenter.x += 0.5 * newDelta.x * CGFloat(cosf(Float(PI_180) * Float(rotationAngle)))
                gateCenter.y += 0.5 * newDelta.x * CGFloat(sinf(Float(PI_180) * Float(rotationAngle)))
            }
            
            rotatedEllipseBounds = NSMakeRect(CGFloat(x2p[6]), CGFloat(y2p[6]), CGFloat(x2p[5] - x2p[4]), CGFloat(y2p[2] - y2p[7]))
            bounds = graphicBoundsFromRotatedEllipseBounds()
            
        } // End of else if handle == GateMiddleRightHandle
        
        // Was the rectangle flipped left to right?
        if rotatedEllipseBounds.size.width <= 0.0 {
            flipLeftRight() // Relabel the handles.
            handle = flippings[handle]
        }
        
        // Is the user changing the height of the graphic from the top?
        if handle == GateUpperMiddleHandle {
            deltaX = rotatedPoint.x - CGFloat(x2p[2]) // Make changes.
            deltaY = rotatedPoint.y - CGFloat(y2p[2])
            
            let newDelta: NSPoint = constrainRotatedEllipseToHistogramBoxGivenDeltaPoint(NSMakePoint(deltaX, deltaY))
            
            // Move the top wall of rectangle bounding the rotated ellipse.
            if newDelta.x != 0.0 && newDelta.y != 0.0 {
                x2p[1] += Float(newDelta.x)
                y2p[1] += Float(newDelta.y)
                x2p[2] += Float(newDelta.x)
                y2p[2] += Float(newDelta.y)
                x2p[3] += Float(newDelta.x)
                y2p[3] += Float(newDelta.y)
                y2p[4] = 0.5*Float(newDelta.y)
                y2p[5] = y2p[4]
                
                gateCenter.x -= 0.5 * newDelta.y * CGFloat(sinf(Float(PI_180) * Float(rotationAngle)))
                gateCenter.y += 0.5 * newDelta.x * CGFloat(cosf(Float(PI_180) * Float(rotationAngle)))
            }
            
            rotatedEllipseBounds = NSMakeRect(CGFloat(x2p[6]), CGFloat(y2p[6]), CGFloat(x2p[5] - x2p[4]), CGFloat(y2p[2] - y2p[7]))
            bounds = graphicBoundsFromRotatedEllipseBounds()
            
        } // End of if handle == GateUpperMiddleHandle
        
        // Is the user changing the height of the graphic from the bottom?
        else if handle == GateLowerMiddleHandle {
            deltaX = rotatedPoint.x - CGFloat(x2p[7]) // Make changes.
            deltaY = rotatedPoint.y - CGFloat(y2p[7])
            
            let newDelta: NSPoint = constrainRotatedEllipseToHistogramBoxGivenDeltaPoint(NSMakePoint(deltaX, deltaY))
            
            // Move the bottom wall of the rectangle bounding the rotated ellipse.
            if newDelta.x != 0.0 && newDelta.y != 0.0 {
                x2p[6] += Float(newDelta.x)
                y2p[6] += Float(newDelta.y)
                x2p[7] += Float(newDelta.x)
                y2p[7] += Float(newDelta.y)
                x2p[8] += Float(newDelta.x)
                y2p[8] += Float(newDelta.y)
                y2p[4] = 0.5*Float(newDelta.y)
                y2p[5] = y2p[4]
                
                gateCenter.x -= 0.5 * newDelta.y * CGFloat(sinf(Float(PI_180) * Float(rotationAngle)))
                gateCenter.y += 0.5 * newDelta.y * CGFloat(cosf(Float(PI_180) * Float(rotationAngle)))
            }
            
            rotatedEllipseBounds = NSMakeRect(CGFloat(x2p[6]), CGFloat(y2p[6]), CGFloat(x2p[5] - x2p[4]), CGFloat(y2p[2] - y2p[7]))
            bounds = graphicBoundsFromRotatedEllipseBounds()
            
        } // End of else if handle == GateLowerMiddleHandle
        
        // Was the rectangle flipped upside down?
        if rotatedEllipseBounds.size.height <= 0.0 {
            flipTopBottom() // Relabel the handles.
            handle = flippings[handle]
        }
        
    } // End of resizeByMovingRotatedEllipseHandle
    
    
    /// translateRotatedEllipseGivenDeltaPoint enables translation of rotated ellipse. Called from GraphicSubview.moveRotatedEllipseWithEvent
    ///
    /// - Parameter delta: amount of offset for translation
    func translateRotatedEllipseGivenDeltaPoint(_ delta: NSPoint) {
        let newDelta: NSPoint = constrainRotatedEllipseToHistogramBoxGivenDeltaPoint(delta)
        bounds = NSOffsetRect(bounds, newDelta.x, newDelta.y)
        gateCenter.x += newDelta.x
        gateCenter.y += newDelta.y
        
    } // End of translateRotatedEllipseGivenDeltaPoint
    
    // MARK: - *** Handles ***
    
    
    /// drawingBounds calculates the bounds for drawing the rectangle or ellipse. Called by GraphicSubview.createRectGateEvent
    ///
    /// - Returns: drawingBounds rect
    func drawingBounds() -> NSRect {
        var outset = GateHandleHalfWidth
        if drawingStroke {
            let strokeOutset: CGFloat = 0.5 * strokeWidth
            if strokeOutset > outset {
                outset = strokeOutset
            }
        } // End of drawingStroke
        
        let inset: CGFloat = -outset
        var drawingBounds = NSInsetRect(bounds, inset, inset)
        
        // -drawHandleInView:atPoint: draws a one-unit drop shadow too..bounds, inset, inset)
        drawingBounds.size.width += 1.0
        drawingBounds.size.height += 1.0
        
        return drawingBounds
        
    } // End of drawingBounds()
    
    
    /// handleUnderPoint. For rectangle gate or nonrotated ellipse gate. Called by GraphicSubview:gateUnderPoint:. Check to see if left mouse down is over a handle. point is left mouse down point and is in full graphic units:[xOffset, xOffset+innerBoxWidth; yOffset, yOffset+innerBoxHeight]
    ///
    /// - Parameter point: location of left mouseDown
    /// - Returns: handle associated with the point
    func handleUnderPoint(_ point:NSPoint) -> Int {
        var handle = GateNoHandle
        // Rectangle or nonrotated ellipse.
        x[1] = Float(bounds.origin.x)
        x[4] = x[1]
        x[6] = x[1]
        x[2] = x[1] + 0.5 * Float(bounds.size.width)
        x[7] = x[2]
        x[3] = x[1] + Float(bounds.size.width)
        x[5] = x[3]
        x[8] = x[3]
        
        y[6] = Float(bounds.origin.y)
        y[7] = y[6]
        y[8] = y[6]
        y[4] = y[6] + 0.5 * Float(bounds.size.height)
        y[5] = y[4]
        y[1] = y[6] + Float(bounds.size.height)
        y[2] = y[1]
        y[3] = y[1]
        
        for i in 1...8 {
            let handlePoint = NSMakePoint(CGFloat(x[i]), CGFloat(y[i]))
            if isHandleAtPoint(handlePoint, point:point) {
                handle = i
                break   // finished ************
            }
        } // End of for loop
        
        return handle
        
    } // End of handleUnderPoint
    
    
    /// whichHandleOnRotatedEllipseIsUnderPoint identifies the handle that the mouse is over. Called from GraphicSubview.rotatedEllipseGateUnderPoint.
    ///
    /// - Parameter point: mouse point
    /// - Returns: handle
    func whichHandleOnRotatedEllipseIsUnderPoint(_ point: NSPoint) -> Int {
        // Called from GraphicSubview.rotatedEllipseGateUnderPoint
        var handle = GateNoHandle
        graphicCoordinatesFromRotatedCoordinates()
        for i in 1...8 {
            let handlePoint = NSMakePoint(CGFloat(x[i]), CGFloat(y[i]))
            if isHandleAtPoint(handlePoint, point: point) {
                handle = i
                break   // finished ************
            }
        } // End of for loop
        
        return handle
        
    } // End of whichHandleOnRotatedEllipseIsUnderPoint
    
    
    /// drawHandleInView draws the handle.
    ///
    /// - Parameters:
    ///   - view: GraphicSubview
    ///   - atPoint: Figure out a rectangle that's centered on the point but lined up with device pixels.
    func drawHandleInView(_ view: GraphicSubview, atPoint: NSPoint) {
        var handleBounds = NSZeroRect
        handleBounds.origin.x = atPoint.x - GateHandleHalfWidth
        handleBounds.origin.y = atPoint.y - GateHandleHalfWidth
        handleBounds.size.width = GateHandleWidth
        handleBounds.size.height = GateHandleWidth
        handleBounds = view.centerScanRect(handleBounds)
        
        // Draw the shadow of the handle.
        let handleShadowBounds = NSOffsetRect(handleBounds, 1.0, 1.0)
        NSColor.controlDarkShadowColor.set()
        handleShadowBounds.fill()
        
        // Draw the handle itself.
        NSColor.knobColor.set()
        handleBounds.fill()
        
    } // End of drawHandleInView
    
    
    /// isHandleAtPoint determines whether a mouse point is over a handle. Called from whichHandleOnRotatedEllipseIsUnderPoint and from handleUnderPoint. point is the left mouseDown point. Check the handle rectangle that's centered on the handle point.
    ///
    /// - Parameters:
    ///   - handlePoint: center of handle rectangle
    ///   - point: mouse point
    /// - Returns: boolean indicating success or failure
    func isHandleAtPoint(_ handlePoint: NSPoint, point: NSPoint) -> Bool {
        //
        var handleBounds = NSZeroRect
        handleBounds.origin.x = handlePoint.x - GateHandleHalfWidth
        handleBounds.origin.y = handlePoint.y - GateHandleHalfWidth
        handleBounds.size.width = GateHandleWidth
        handleBounds.size.height = GateHandleWidth
        
        return NSPointInRect(point, handleBounds)
        
    } // End of isHandleAtPoint
    
    
    /// drawHandlesInView draws the handle. Called from GraphicSubView:drawRect
    ///
    /// - Parameter view: GraphicSubview
    func drawHandlesInView(_ view: GraphicSubview) {
        // Called from GraphicSubView:drawRect
        if view != myView {
            return
        }
        
        // Draw handles at the corners and on the sides.
        
        if gateType == "RectangleGate" || rotationAngle == 0.0 {
            // rotationAngle is zero.
            if myView?.histogramType == BivariateTag {
                // Draw bottom handles for bivariate histogram RectGate.
                drawHandleInView(view, atPoint: NSMakePoint(NSMinX(bounds), NSMinY(bounds)))
                drawHandleInView(view, atPoint: NSMakePoint(NSMidX(bounds), NSMinY(bounds)))
                drawHandleInView(view, atPoint: NSMakePoint(NSMaxX(bounds), NSMinY(bounds)))
            
            } // End of myView?.histogramType == "Bivariate"
            
            // Rest are for both univariate and bivariate histograms
            drawHandleInView(view, atPoint: NSMakePoint(NSMinX(bounds), NSMidY(bounds)))
            drawHandleInView(view, atPoint: NSMakePoint(NSMaxX(bounds), NSMidY(bounds)))
            drawHandleInView(view, atPoint: NSMakePoint(NSMinX(bounds), NSMaxY(bounds)))
            drawHandleInView(view, atPoint: NSMakePoint(NSMidX(bounds), NSMaxY(bounds)))
            drawHandleInView(view, atPoint: NSMakePoint(NSMaxX(bounds), NSMaxY(bounds)))
            
        } // End of gateType == "RectangleGate" || rotationAngle == 0.0
        
        else { // drawHandlesInView: for rotated ellipse (rotationAngle nonZero)
            coordinatesOfRotatedEllipseGateHandlesFromGraphicBounds(bounds)
            // Corner handles are hidden for rotated ellipse.
            drawHandleInView(view, atPoint: NSMakePoint(CGFloat(x2p[7]), CGFloat(y2p[7])))
            drawHandleInView(view, atPoint: NSMakePoint(CGFloat(x2p[4]), CGFloat(y2p[4])))
            drawHandleInView(view, atPoint: NSMakePoint(CGFloat(x2p[5]), CGFloat(y2p[5])))
            drawHandleInView(view, atPoint: NSMakePoint(CGFloat(x2p[2]), CGFloat(y2p[2])))
        } // End of else
        
        myView!.setNeedsDisplay(myView!.innerBoxDrawingBounds())
        
    } // End of drawHandlesInView
    
    
    /// isContentUnderPoint determines whether the content of the gate is under the mouse point. Called from GraphicSubview:gateUnderPoint when the interior of a gate is clicked on rather than one of the handles.
    ///
    /// - Parameter point: mouse point
    /// - Returns: boolean indicating success or failure.
    func isContentUnderPoint(_ point: NSPoint) -> Bool {

        var ptInRect = false
        
        if rotationAngle == 0.0 {
            ptInRect = NSPointInRect(point, bounds)
        }
        
        else if rotationAngle != 0.0 {
            // Here we must convert the point into the rotated frame and then check that the elliptical gate path contains the rotated point (aPoint).
            let aPoint = rotatedPointFromGraphicPoint(point)
            if gatePath.contains(aPoint) {
                ptInRect = true
            }
        } // End of rotationAngle != 0.0
        
        return ptInRect
        
    } // End of isContentUnderPoint
    
} // End of class RectGate
