//
//  QuadPoint.swift is used by QuadGate and by GRSVExtQuadMouseEvents
//  FCSRead
//
//  Created by Mr. Salzman on 1/28/16.
//  Copyright © 2019 Gary Salzman. All rights reserved.
//

import Foundation

class QuadPoint: NSObject {
    
    var qPt = NSZeroPoint
    var quadPtHandle = 0
    var quadPtKey = ""
    var showQuadPt = false
    
    override init() {
        super.init()
    }

    /// convenience init instantiates a quadPoint
    ///
    /// - Parameters:
    ///   - aPoint: the point
    ///   - handle: handle for the point
    ///   - key: key used in quadPtDict
    convenience init(aPoint: NSPoint, handle: Int, key: String) {
        self.init()
        qPt = aPoint
        quadPtHandle = handle
        quadPtKey = key
        showQuadPt = true
        
    } // End of convenience init
    
} // End of class QuadPoint
