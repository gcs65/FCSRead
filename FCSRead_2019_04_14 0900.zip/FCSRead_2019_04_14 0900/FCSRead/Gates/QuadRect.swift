//
//  QuadRect.swift Class for quadrant rectangles used by QuadGate
//  FCSRead
//
//  Created by Mr. Salzman on 1/30/16.
//  Copyright © 2019 Gary Salzman. All rights reserved.
//

import Cocoa

class QuadRect: NSObject {
    
    var myRect = NSZeroRect
    var myRectKey = ""
    var rectPath = NSBezierPath()
    var highlighted = false
    var gatedCount = 0
    var showQuadRect = false
    var strokeColor = NSColor.red
    
    override init() {
        super.init()
    }
    
    
    /// convenience init instantiates a quadrant rectangle
    ///
    /// - Parameters:
    ///   - r: the rectangle
    ///   - key: key for quadRectDict (dictionary of quadrant rectangles). Created in QuadGate
    convenience init(r: NSRect, key: String) {
        self.init()
        myRect = r
        myRectKey = key
        showQuadRect = true
    } // End of convenience init
    
    
    /// myRectDrawingBounds. Used just for highlighting a quadRect on the bivariate display. Called from bezierPathForDrawing (below).
    ///
    /// - Returns: a slightly inset rectangle
    func myRectDrawingBounds() -> NSRect {
        let inset: CGFloat = 2.0
        
        return NSInsetRect(myRect, inset, inset)
        
    } // End of myRectDrawingBounds
    
    
    /// bezierPathForDrawing. Used in highlighting a quadRect on the bivariate display
    ///
    /// - Returns: the rectangle path
    func bezierPathForDrawing() -> NSBezierPath {
        //
        rectPath = NSBezierPath()
        rectPath.lineWidth = 2.0
        rectPath = NSBezierPath(rect: myRect)
        
        return rectPath
        
    } // End of bezierPathForDrawing
    
    
    /// drawContentsInView. Called from QuadGate.drawContentsInView to draws the quadRect
    ///
    /// - Parameter view: GraphicSubview
    func drawContentsInView(_ view: GraphicSubview) {
        //
        rectPath = bezierPathForDrawing()
        if highlighted {
            // shift-left click in a quadRect to select it for merging.
            NSColor.blue.setStroke()
        }
        else {
            // no selection for merging - initial state of quadRect.
            NSColor.red.setStroke()
        }
        
        if !rectPath.isEmpty {
            rectPath.stroke()
        }
    } // End of drawContentsInView
    
    
    /// pointInQuadRect. Called from MainViewController.createGatedEventArray
    ///   In QuadRect.swift
    /// - Parameter aPoint: the point
    /// - Returns: returns true if the point is inside the quadRect
    func pointInQuadRect(_ aPoint: NSPoint) -> Bool {
        if NSPointInRect(aPoint, myRect) {
            gatedCount += 1
            return true
        }
        else {
            return false
        }
        
    } // End of pointInQuadRect
    

    /// description
    override var description: String {
        get {
            let result = "\nmyRectKey: \(myRectKey) x: \(myRect.origin.x) y: \(myRect.origin.y) width: \(myRect.width) height: \(myRect.height)"
            return result
        }
        
    } // End of description

} // End of QuadRect
