//
//  QuadGate.swift Class for setting up quadrant gates.
//  FCSRead
//
//  Created by Mr. Salzman on 1/23/16.
//  Copyright © 2019 Gary Salzman. All rights reserved.
//  FCSRead

import Cocoa

class QuadGate: NSObject {
    
    weak var myView: GraphicSubview?
    var gateType = "QuadGate"
    var gateSubtype = ""
    var gatePath = NSBezierPath()
    var quadGateExists = false
    var xLocation: CGFloat = 0.0
    var yLocation: CGFloat = 0.0
    var quadPoint = QuadPoint()
    var numQuadPts = 0 // Number of quadRant Points
    var quadPtDict = [String:QuadPoint]()
    var quadPtArray = [QuadPoint]()
    var quadPtIndex = 0
    var quadPtHandle = 100
    var quadRect = QuadRect()
    var quadRectDict = [String:QuadRect]()
    var quadRectArray = [QuadRect]()
    var quadRectKeyArray = [String]()
    var quadRectsExist = false
    var numRects = 0 // Number of rectangles
    var numRows = 0 // Number of rows of rectangles
    var numCols = 0 // Number of columns of rectangles
    
    var bounds = NSZeroRect
    var drawingStroke = false
    var strokeColor = NSColor.red
    var strokeWidth: CGFloat = 0.0
    
    var xOffset: CGFloat = 0.0
    var yOffset: CGFloat = 0.0
    var innerBoxWidth: CGFloat = 0.0
    var innerBoxHeight: CGFloat = 0.0
    
    // MARK: - *** inits/deinit ***
    
    override init() {
        super.init()
    }
    
    /// convenience init instantiates a quadrant gate. Instantiated in GRSVExtQuadMouseEvents.swift
    ///
    /// - Parameters:
    ///   - frameRect: initially NSZeroRect, but expanded to entire histogram (innerbox)
    ///   - view: GraphicSubview
    convenience init(frameRect: NSRect, view: GraphicSubview) {
        self.init()
        bounds = frameRect
        myView = view
        drawingStroke = true
        strokeWidth =  2.0
        xOffset = (myView?.histogramGraphic?.xOffset)! // x offset from outer box to left side of innerBox (histogram box)
        yOffset = (myView?.histogramGraphic?.yOffset)! // y offset from outer box to bottom of innerBox
        innerBoxWidth = (myView?.histogramGraphic?.innerBoxWidth)! // width of innerBox
        innerBoxHeight = (myView?.histogramGraphic?.innerBoxHeight)! // height of innerBox
        
    } // End of convenience init
    
    // MARK: - *** Drawing ***
    
    /// bezierPathForDrawing. Called by drawContentsInView
    ///
    /// - Returns: NSBezierPath for the quadGate
    func bezierPathForDrawing() -> NSBezierPath {

        NSColor.red.setStroke() // For horizontal and vertical lines extending from a QuadPoint.
        
        gatePath = NSBezierPath()
        gatePath.move(to: NSMakePoint(xOffset, yLocation))
        gatePath.line(to: NSMakePoint(xOffset + innerBoxWidth, yLocation))
        gatePath.move(to: NSMakePoint(xLocation, yOffset))
        gatePath.line(to: NSMakePoint(xLocation, yOffset + innerBoxHeight))
        gatePath.lineWidth = strokeWidth
        
        return gatePath
        
    } // End of bezierPathForDrawing
    
    /// drawContentsInView. Called byt GraphicSubview.draw. Draw the quadPoints, the large cross cursors and the quadRects, if they exist.
    ///
    /// - Parameter view: GraphicSubview
    func drawContentsInView(_ view: GraphicSubview) {
        if !quadRectsExist { // No quadRects. Draw the quadPoint(s) if no quadRects exist.
            quadPtArray = [QuadPoint](quadPtDict.values)
            for i in 0..<quadPtArray.count {
                quadPoint = quadPtArray[i] 
                xLocation = quadPoint.qPt.x
                yLocation = quadPoint.qPt.y
                gatePath = bezierPathForDrawing()
                if drawingStroke {
                    gatePath.stroke()
                }
                drawHandleInView(myView!, point: NSMakePoint(xLocation, yLocation))
            } // End of loop over quadPtArray
        } // End of no quadRects
        
        else { // quadRects exist, draw only the quadRects
            for i in 0..<quadRectArray.count {
                quadRect = quadRectArray[i] 
                quadRectLabel(quadRect.myRectKey, theRect: quadRect.myRect)
                quadRect.drawContentsInView(myView!)
            } // End of loop over quadRectArray
        } // End of quadRects exist
        
    } // End of drawContentsInView for QuadGate
    
    /// quadRectLabel creates the labels for the quadRects formed from the quadPoints. Called from drawContentsInView
    ///
    /// - Parameters:
    ///   - label: myRectKey passed in from drawContentsInView
    ///   - theRect: rectangle
    func quadRectLabel(_ label: String, theRect: NSRect) {
        var textRect = NSZeroRect
        let myFont = NSFont(name: myView!.histogramGraphic!.fontName, size: myView!.histogramGraphic!.fontSize)
        let textColor = NSColor.black
        let textStyle = NSMutableParagraphStyle.default
        let textFontAttributes: Dictionary = [NSAttributedString.Key.font : myFont! as NSFont, NSAttributedString.Key.foregroundColor : textColor, NSAttributedString.Key.paragraphStyle : textStyle]
        let yPos: CGFloat = theRect.origin.y + theRect.size.height - 30.0
        textRect = NSMakeRect(theRect.origin.x + 5.0, yPos, 40.0, 30.0)
        label.draw(in: textRect, withAttributes: textFontAttributes)
        
    } // End of quadRectLabel
    
    
    /// keyForQuadRectContainingPoint. Finds the quadRect myRect containing the point aPt and return the quadRect myRectKey
    ///
    /// - Parameter aPt: mouse point
    /// - Returns: the quadRect myRectKey
    func keyForQuadRectContainingPoint(_ aPt: NSPoint) -> String {
        var key = ""
        quadRectArray = [QuadRect](quadRectDict.values)
        for i in 0..<quadRectArray.count {
            quadRect = quadRectArray[i]
            if NSPointInRect(aPt, quadRect.myRect) {
                key = quadRect.myRectKey
                // Save the keys for the quadRects to be merged.
                quadRectKeyArray.append(key)
                return key
            }
            else {}
            
        } // End of loop over quadRecArray
        
        return key
        
    } // End of keyForQuadRectContainingPoint

    
    /// sortForwardByX. Called by sortAscendingByX.
    ///
    /// - Parameters:
    ///   - qPt1: first quadPoint
    ///   - qPt2: second quadPoint
    /// - Returns: true if x value of qPt1 is less than that of qPt2
    func sortForwardByX(_ qPt1: QuadPoint, qPt2: QuadPoint) -> Bool {
        if qPt1.qPt.x < qPt2.qPt.x {
            return true
        }
        else {
            return false
        }
        
    } // End of sortForwardByX
    
    /// sortAscendingByX sorts the quadPoint array in ascending order. Called by QuadGate.CreateQuadGateRectangles
    ///
    /// - Parameter inputArray: input QuadPoint array
    /// - Returns: QuadPoint array sorted ascending by X
    func sortAscendingByX(_ inputArray: Array<QuadPoint>) -> Array<QuadPoint> {
        let sortedAscendingByX: Array<QuadPoint> = inputArray.sorted(by: sortForwardByX)
        
        return sortedAscendingByX
        
    } // End of sortAscendingByX
    
    
    /// sortForwardByY. Called by sortAscendingByY.
    ///
    /// - Parameters:
    ///   - qPt1: first quadPoint
    ///   - qPt2: second quadPoint
    /// - Returns: true if y value of qPt1 is less than that of qPt2
    func sortForwardByY(_ qPt1: QuadPoint, qPt2: QuadPoint) -> Bool {
        if qPt1.qPt.y < qPt2.qPt.y {
            return true
        }
        else {
            return false
        }
        
    } // End of sortForwardByY
    
    
    /// sortAscendingByY sorts the quadPoint array in ascending order. Called by QuadGate.CreateQuadGateRectangles
    ///
    /// - Parameter inputArray: input QuadPoint array
    /// - Returns: QuadPoint array sorted ascending by Y
    func sortAscendingByY(_ inputArray: Array<QuadPoint>) -> Array<QuadPoint> {
        let sortedAscendingByY: Array<QuadPoint> = inputArray.sorted(by: sortForwardByY)
        
        return sortedAscendingByY
        
    } // End of sortAscendingByY
    
    
    /// createQuadGateRectangles. Called from right click createAndShowQuadrantRects. quadPtDict and quadPtArray exist and contain quadPts P0, P1, ... Also called from QuadGate:createAndShowQuadrantRects:, which is called from the right click menu.
    func createQuadGateRectangles() {
        print("createQuadGateRectangles")
        let qPLL = QuadPoint(aPoint: NSMakePoint(xOffset, yOffset), handle: 0, key: "LL")
        quadPtDict["LL"] = qPLL // Lower Left corner of histogram box
        let qPUR = QuadPoint(aPoint: NSMakePoint(xOffset + innerBoxWidth, yOffset + innerBoxHeight), handle: 0, key: "UR")
        quadPtDict["UR"] = qPUR // Upper right corner of histogram box
        
        quadPtArray = [QuadPoint](quadPtDict.values) // Load quadPtArray
        numQuadPts = quadPtArray.count // 3 if there is only P0 (includes qPLL and  qPUR)
        
        let test = (numQuadPts - 1)%2
        if test == 0 {
            numRects = Int(pow(2.0, Double(numQuadPts - 1)))
        } else {
            numRects = Int(pow(2.0, Double(numQuadPts - 1))) + 1
        }
        numRows = Int(sqrt(Double(numRects)))
        numCols = numRows
        print("numRows: \(numRows)")
        
        // Sort the quadPtArray ascending by x and by y. quadPtArray contains qPLL and qPUR quadPts.
        var sortedAscByX = sortAscendingByX(quadPtArray)
        var sortedAscByY = sortAscendingByY(quadPtArray)
        var quadRectKey = ""
        quadRectDict.removeAll()
        var colWidth = Array(repeating: CGFloat(0.0), count: numCols)
        var rowHeight = Array(repeating: CGFloat(0.0), count: numRows)
        var xOrig = Array(repeating: CGFloat(0.0), count: numCols)
        var yOrig = Array(repeating: CGFloat(0.0), count: numRows)
        for col in 0..<numCols {
            xOrig[col] = roundCGFloat(sortedAscByX[col].qPt.x)
        }
        for col in 0..<numCols - 1 {
            colWidth[col] = roundCGFloat(sortedAscByX[col + 1].qPt.x - sortedAscByX[col].qPt.x)
        }
        colWidth[numCols - 1] = roundCGFloat(qPUR.qPt.x - sortedAscByX[numCols - 1].qPt.x)
        print("xOrig: \(xOrig)")
        print("colWidth: \(colWidth)")
        for row in 0..<numRows {
            yOrig[row] = roundCGFloat(sortedAscByY[row].qPt.y)
        }
        for row in 0..<numRows - 1 {
            rowHeight[row] = roundCGFloat(sortedAscByY[row + 1].qPt.y - sortedAscByY[row].qPt.y)
        }
        rowHeight[numRows - 1] = roundCGFloat(qPUR.qPt.y - sortedAscByY[numRows - 1].qPt.y)
        print("yOrig: \(yOrig)")
        print("rowHeight: \(rowHeight)")
        
        var rectIndex = 0
        for row in 0..<numRows {
            for col in 0..<numCols {
                quadRectKey = NSString.localizedStringWithFormat("Q%i", rectIndex) as String
                let rect = NSMakeRect(xOrig[col], yOrig[row], colWidth[col], rowHeight[row])
                quadRect = QuadRect(r: rect, key: quadRectKey)
                quadRectDict[quadRectKey] = quadRect
                print("quadRect: \(quadRect)")
                rectIndex += 1
            }
        }
        
        // Copy quadRectDict values to quadRectArray
        quadRectArray = [QuadRect](quadRectDict.values)
        
        // Clear the quadRectKeyArray to prepare for merging quadRects, if this is to be done.
        quadRectKeyArray.removeAll()
        // Remove points no longer needed.
        quadPtDict.removeValue(forKey: "LL")
        quadPtDict.removeValue(forKey: "UR")
        
        quadPtArray = [QuadPoint](quadPtDict.values)
        quadRectsExist = true
        
        myView!.createBivariateGateDictionaryEntry()
        
    } // End of createQuadGateRectangles
    
    
    /// removeQuadGateRectangles removes all of the quadGate rectangles.
    func removeQuadGateRectangles () {
        quadRectsExist = false
        quadRectDict.removeAll()
        myView?.displayIfNeeded()
        
    } // End of removeQuadGateRectangles
    
    /// pointInQuadGate. Called from MainViewController.createGatedEventArray
    ///   In QuadGate.swift
    /// - Parameter aPoint: point to be checked
    /// - Returns: true if goodGate is true
    func pointInQuadGate(_ aPoint: NSPoint) -> Bool {
        var goodGate = false
        var sumOfGoodGates = 0
        for qR: QuadRect in quadRectArray {
            goodGate = qR.pointInQuadRect(aPoint) // In QuadRect.swift
            if goodGate == true {
                sumOfGoodGates += 1 // true if pointInQuadRect
            }
        } // End of loop over quadRectArray
        
        if sumOfGoodGates > 0 {
            return true
        }
        else {
            return false
        }
        
    } // End of pointInQuadGate
    
    func myPointInQuadGateRect(_ aPoint: NSPoint, index: Int) -> Int {
        var quadrant = -1
        if NSPointInRect(aPoint, quadRectArray[index].myRect) {
            quadrant = index
        }
        return quadrant
    } // End of pointInQuadGateRect
    
    /// reportQuadRectEvents. Not called.
    func reportQuadRectEvents() {
        for qR: QuadRect in quadRectArray {
            print("quadRectEvents \(qR.myRectKey) \(qR.gatedCount)")
        }
    } // End of reportQuadRectEvents
    
    
    /// createAndShowQuadrantRects. Called from GraphicSubview.right click popup. Creates quadrant gate rectangles and, if they exist, draws them.
    ///
    func createAndShowQuadrantRects() {
        print("createAndShowQuadrantRects")
        createQuadGateRectangles()
        if quadRectsExist == false {
            return
        }
        else {
            for qR: QuadRect in quadRectArray {
                qR.drawContentsInView(myView!)
            }
        }
    } // End of createAndShowQuadrantRects

    
    /// drawingBounds determines the drawing bounds for the quadGate. Assume that drawContentsInView and drawHandlesInView will be doing the drawing. Start with the plain bounds of the graphic, then take drawing of handles at the corners of the bounds into account, then optional stroke drawing.
    ///
    /// - Returns: drawing bounds
    func drawingBounds() -> NSRect { // Apparently not called within QuadGate.
        //
        var outset: CGFloat = GateHandleHalfWidth
        if drawingStroke == true {
            let strokeOutset: CGFloat = 0.5 * strokeWidth
            if strokeOutset > outset {
                outset = strokeOutset
            }
        } // End of drawingStroke == true
        
        let inset = -outset
        var myDrawingBounds = NSInsetRect(bounds, inset, inset)
        
        // -drawHandleInView:atPoint: draws a one-unit drop shadow too.
        myDrawingBounds.size.width += 1.0
        myDrawingBounds.size.height += 1.0
        
        return myDrawingBounds
        
    } // End of drawingBounds
    
    
    /// creationCursor
    ///
    /// - Returns: the Crosshairs cursor
    class func creationCursor() -> NSCursor {
        // crosshairsCursor is default.
        var crosshairsCursor: NSCursor?
        
        if crosshairsCursor == nil {
            let crosshairsImage = NSImage(named: "Cross")
            crosshairsCursor = NSCursor(image: crosshairsImage!, hotSpot: NSMakePoint(0.5 * crosshairsImage!.size.width, 0.5 * crosshairsImage!.size.height))
        }
        
        return crosshairsCursor!
        
    } // End of creationCursor
    
    
    /// contentsUnderPoint determines whether the contents of a quadGate in under the mousePoint
    ///
    /// - Parameter point: mousePoint
    /// - Returns: true if the quadGate in under the mousePoint
    func contentsUnderPoint(_ point: NSPoint) -> Bool {
        // Just check against the graphic's bounds.
        
        return NSPointInRect(point, bounds)
        
    } // End of contentsUnderPoint

    
    // MARK: *** Handles ***
    
    /// drawHandlesInView
    ///
    /// - Parameter view: GraphicSubview
    func drawHandlesInView(_ view: GraphicSubview) {
        
        drawHandleInView(myView!, point: NSMakePoint(xLocation, yLocation))
        
    } // End of drawHandlesInView
    
    
    /// drawHandleInView draws a handle at a point
    ///
    /// - Parameters:
    ///   - view: GraphicSubview
    ///   - point: point at center of the handle
    func drawHandleInView(_ view: GraphicSubview, point: NSPoint) {
        // Figure out a rectangle that's centered on the point but lined up with device pixels.
        var handleBounds = NSZeroRect
        handleBounds.origin.x = point.x - GateHandleHalfWidth
        handleBounds.origin.y = point.y - GateHandleHalfWidth
        handleBounds.size.width = GateHandleWidth
        handleBounds.size.height = GateHandleWidth
        handleBounds = view.centerScanRect(handleBounds)
        
        // Draw the shadow of the handle.
        let handleShadowBounds = NSOffsetRect(handleBounds, 1.0, 1.0)
        strokeColor = NSColor.controlDarkShadowColor
        handleShadowBounds.fill()
        
        // Draw the handle itself
        NSColor.knobColor.set()
        handleBounds.fill()
        
    } // End of drawHandleInView
    
    
    /// handleUnderPoint determines whether a handle is under the mousePoint
    ///
    /// - Parameter point: mouse point
    /// - Returns: true if handle is under the point
    func handleUnderPoint(_ point: NSPoint) -> Int {
        var handle = GateNoHandle
        
        quadPtArray = [QuadPoint](quadPtDict.values)
        for i in 0..<quadPtArray.count {
            quadPoint = quadPtArray[i]
            xLocation = quadPoint.qPt.x
            yLocation = quadPoint.qPt.y
            quadPtHandle = quadPoint.quadPtHandle
            if handleAtPoint(NSMakePoint(xLocation, yLocation), point: point) {
                handle = quadPtHandle
            }
        } // End of loop over quatPtArray
        
        return handle
        
    } // End of handleUnderPoint
    
    
    /// handleAtPoint. Check a handle-sized rectangle that's centered on the handle point.
    ///
    /// - Parameters:
    ///   - handlePoint: center point of handle under consideration
    ///   - point: mouse point
    /// - Returns: true of point is inside handleBounds
    func handleAtPoint(_ handlePoint: NSPoint, point: NSPoint) -> Bool {
        let handleBounds = NSMakeRect(handlePoint.x - GateHandleHalfWidth, handlePoint.y - GateHandleHalfWidth, GateHandleWidth, GateHandleWidth)
        return NSPointInRect(point, handleBounds)
        
    } // End of handleAtPoint
    
    
    /// repositionByMovingHandle enables repositioning of a handle
    ///
    /// - Parameters:
    ///   - handle: handle under consideration
    ///   - point: mouse point
    /// - Returns: handle which was moved
    func repositionByMovingHandle(_ handle: Int, point: NSPoint) -> Int {
        // Keep gate inside histogramBox (innerBox)
        var movedHandle = GateNoHandle
        var aPoint = point
        let leftH = myView!.histogramGraphic!.xOffset
        let bottomH = myView!.histogramGraphic!.yOffset
        let rightH = leftH + myView!.histogramGraphic!.innerBoxWidth
        let topH = bottomH + myView!.histogramGraphic!.innerBoxHeight
        if point.x < leftH {
            aPoint.x = leftH
        }
        if point.y < bottomH {
            aPoint.y = bottomH
        }
        if point.x > rightH {
            aPoint.x = rightH
        }
        if point.y > topH {
            aPoint.y = topH
        }
        
        quadPtArray = [QuadPoint](quadPtDict.values)        
        for i in 0..<quadPtArray.count {
            quadPoint = quadPtArray[i]
            if quadPoint.quadPtHandle == handle { // handle to move
                xLocation = aPoint.x
                yLocation = aPoint.y
                quadPoint.qPt = NSMakePoint(aPoint.x, aPoint.y)
                movedHandle = quadPoint.quadPtHandle
                quadPtDict[quadPoint.quadPtKey] = quadPoint
                return movedHandle
            }
            
        } // End of loop over quatPtArray
        
        return movedHandle
        
    } // End of repositionByMovingHandle
    
    
    /// translateQuadPtByX. Not called *******************************
    ///
    /// - Parameters:
    ///   - myX: x value of quadPt
    ///   - myY: y value of quadPt
    func translateQuadPtByX(_ myX: CGFloat, myY: CGFloat) {
        let movedHandle = repositionByMovingHandle(quadPtHandle, point: NSMakePoint(myX, myY))
        if movedHandle == GateNoHandle {
            print("QuadGate.translateQuadPtByX.movedHandle is GateNoHandle.")
        }
    } // End of translateQuadPtByX
    
    
    /// description
    override var description: String {
        get {
            let result = "\ngateType: \(gateType) quadPtDict: \(quadPtDict) quadPtArray: \(quadPtArray)"
            return result
        }
        
    } // End of description
    
    /// roundCGFloat rounds a CGFloat to an integer and returns a CGFloat
    ///
    /// - Parameter inCGFloat: CFFloat number
    /// - Returns: a CGFloat number that is now the nearest integer
    func roundCGFloat(_ inCGFloat: CGFloat) -> CGFloat {
        var outCGFloat = CGFloat(0.0)
        var nearestInt = 0
        nearestInt = Int(round(Double(inCGFloat)))
        outCGFloat = CGFloat(nearestInt)
        return outCGFloat
    }

} // End of QuadGate class
