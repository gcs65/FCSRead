//
//  GateRotationWC.swift activates the rotation angle window and controls the ellipse rotation angle. Initialized by RectGate.showEllipseGateRotationWindow()
//  FCSRead
//
//  Created by Mr. Salzman on 1/16/2016.
//  Copyright © 2019 Gary Salzman. All rights reserved.

import Cocoa

class GateRotationWindowController: NSWindowController {
    
    var angle: CGFloat = 0.0
    weak var mySubview: GraphicSubview?
    weak var myGate: RectGate?

    @IBOutlet weak var angleTextField: NSTextField!
    @IBOutlet weak var angleSlider: NSSlider!
        
    override func windowDidLoad() {
        super.windowDidLoad()
        angle = 0.0
        angleSlider.floatValue = 0.0
        angleTextField.floatValue = 0.0
    }
    
    
    /// passTheGate passes in the gate. Called from RectGate.showRotationWindow
    ///
    /// - Parameters:
    ///   - gate: instantiated Gate
    ///   - subview: GraphicSubview
    func passTheGate(_ gate: RectGate, subview: GraphicSubview) {
        myGate = gate
        mySubview = subview
    }
    
    
    /// changeAngleSlider changes the rotation angle based on user action (slider)
    ///
    /// - Parameter sender: slider
    @IBAction func changeAngleSlider(_ sender: AnyObject) {
        angleSlider.floatValue = sender.floatValue
        angle = CGFloat(angleSlider.floatValue)
        angleTextField.floatValue = Float(angle)
        myGate!.rotationAngle = angle
        
        validateAngleAndDisplay()
        
    } // End of changeAngleSlider
    
    
    /// resetToZero resets the angle slider to 0.0 deg.
    ///
    /// - Parameter sender: Zero the angle button
    @IBAction func resetToZero(_ sender: AnyObject) {
        angleSlider.floatValue = 0.0
        angle = CGFloat(0.0)
        angleTextField.floatValue = Float(0.0)
        myGate!.rotationAngle = angle
        
        validateAngleAndDisplay()
        
    } // End of resetToZero
    
    
    /// validateAngleAndDisplay constrains the ellipse rotation angle so that ellipse stays inside histogram box.
    func validateAngleAndDisplay() {
        
        myGate!.rotatedCoordinatesFromRotatedEllipseBounds()
        
        if !myGate!.validateRotationAngleOfEllipse() { // Invalid rotation angle
            myGate!.rotationAngle = myGate!.oldRotationAngle
            angle = myGate!.oldRotationAngle
            angleSlider.floatValue = Float(myGate!.oldRotationAngle)
        }
            
        else {
            myGate!.oldRotationAngle = myGate!.rotationAngle
        }
        
        mySubview!.setNeedsDisplay(mySubview!.innerBoxDrawingBounds())
        
    } // End of validateAngleAndDisplay
    
} // End of class GateRotationWindowController
