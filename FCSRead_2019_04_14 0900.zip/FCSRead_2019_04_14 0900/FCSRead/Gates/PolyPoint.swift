//
//  PolyPoint.swift is a class for polygon vertices (points). It supports the polygon gate class.
//  FCSRead
//
//  Created by Mr. Salzman on 1/27/16.
//  Copyright © 2019 Gary Salzman. All rights reserved.
//

import Cocoa

class PolyPoint: NSObject {
    
    var pPt = NSZeroPoint
    var pHandle = 0
    var pKey = ""
    var isLastPoint = false
    
    override init() {
        super.init()
    }
    
    
    /// convenience init
    ///
    /// - Parameters:
    ///   - myPoint: point to be instantiated
    ///   - myHandle: handle of the point
    ///   - key: unused here
    ///   - isLastPoint: boolean true if this is the last point in the polygon
    convenience init(myPoint: NSPoint, myHandle: Int, key: String, isLastPoint: Bool) {
        self.init()
        pPt = myPoint
        pHandle = myHandle
        pKey = key
        self.isLastPoint = isLastPoint
        
    } // End of convenience init
    
    
    /// description
    override var description: String {
        get {
            return "PolyPoint pPt:\(NSStringFromPoint(pPt)) pHandle:\(pHandle) pKey:\(pKey) isLastPoint:\(isLastPoint)"
        }
    } // End of description
    
} // End of class PolyPoint
