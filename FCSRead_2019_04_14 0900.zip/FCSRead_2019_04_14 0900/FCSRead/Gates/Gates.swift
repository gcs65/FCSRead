//
//  Gates.swift Supports rectangular gate for univariate and rectangular and elliptical gates for bivariate histograms. A univariate histogram will have yVariate=0. Supported gate types: RectangleGateTag, EllipseGateTag, PolygonGateTag, QuadrantGateTag.
//  FCSRead
//
//  Created by Mr. Salzman on 12/1/15.
//  Copyright © 2019 Gary Salzman. All rights reserved.
//

//let BivariateTag = "Bivariate" (See Document.swift)
//let UnivariateTag = "Univariate"
//let RectangleGateTag = "RectangleGate"
//let EllipseGateTag = "EllipseGate"
//let PolygonGateTag = "PolygonGate"
//let QuadrantGateTag = "QuadrantGate"

import Cocoa

class Gates: NSObject {

    var xVariate = 0 // Default values obtained with Gates()
    var yVariate = 0
    var polygonGate: PolygonGate? = nil
    var quadGate: QuadGate? = nil
    var rectGate: RectGate? = nil // rectGate types: RectangleGateTag, EllipseGateTag
    // RectGate has rectGate.gateSubType: UnivariateTag or BivariateTag
    var gateType = "" // RectangleGateTag, EllipseGateTag, PolygonGateTag, QuadrantGateTag
    var gateActive = false // true if a gate has been drawn on a histogram.
    
    override init() {
        super.init()
    }
    
    
    /// onvenience init instantiates a Gate object with a gateType
    ///
    /// - Parameters:
    ///   - xVar: x variate
    ///   - yVar: y variate
    ///   - gateType: gateType String (see above)
    convenience init(xVar: Int, yVar: Int, gateType: String) {
        self.init()
        self.gateType = gateType
        xVariate = xVar
        yVariate = yVar
        gateActive = true
    }
    
    
    /// description
    override var description: String { // Gates description
        get {
            var gateString = ""
            if let rectGateString = rectGate?.description {
                gateString = "gate: \(gateType) x:\(xVariate) y:\(yVariate)" + rectGateString
                // Works only for rectGate for the moment *************
            }
            
            // Needs Work ************************
            
            return gateString
        }
        
    } // End of description
    
} // End of class Gates
