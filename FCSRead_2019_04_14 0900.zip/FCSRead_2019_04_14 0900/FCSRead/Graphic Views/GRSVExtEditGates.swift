//
//  GRSVExtEditGates.swift GraphicSubview Extension to support editing of gates.
//  FCSRead
//
//  Created by Mr. Salzman on 1/23/16.
//  Copyright © 2016 Gary Salzman. All rights reserved.
//
// Functions in GRSVExtensionEditGates.swift
// func createUnivariateGateDictionaryEntry()
// func createBivariateGateDictionaryEntry()
// func axesChangedGateDictionaryEntry() (empty)
// func editGateDictionaryEntry() (empty)
// func resetGateDictionaryEntry() (empty)
// func showMyGate() (empty)
// func showGateDictionary() (empty)
// func gateBoundariesForUniGate() (empty?)
// func gateBoundariesForBivGate() (empty?)
// func gateBoundariesForPolyGate() (empty?)
// func gateBoundariesForQuadGate() (empty?)
// func keyString() -> String

//  Note that func keyString has been moved from HistogramGraphic to GraphicSubview. keyString supports the Gate Dictionary.

import Cocoa

extension GraphicSubview { // GRSVExtensionEditGates
    
    
    /// createUnivariateGateDictionaryEntry creates a gate dictionary entry for a univariate rectangular gate. Method called from GRSVExtSupport.mouseDown(... after gate.bounds have been set. Adds myGate entry to fcs.gateDict with key:keyString
    func createUnivariateGateDictionaryEntry() { // For univariate histograms only.
        if currentGateTypeSetting == CreateRectangleGateTag { // Univariate gates are rectangles only.
            rectGate!.gateSubType = UnivariateTag
            Swift.print("createUnivariateGateDictionaryEntry rectGate \(String(describing: rectGate))")
            myGate = Gates(xVar: xVariate, yVar: 0, gateType: RectangleGateTag)
            myGate!.rectGate = rectGate
            myGate!.gateActive = true
            Swift.print("createUnivariateGateDictionaryEntry myGate!.rectGate \(myGate!)")
            if let delegate = delegate { // Delegate is MainViewController
                delegate.setGateDictEntryForKey(keyString(), gate: myGate!)
            } else {
                Swift.print("createUnivariateGateDictionaryEntry delegate at setGateDictEntryForKey(...) failed.")
            }
            
        } // End of if currentGateTypeSetting == CreateRectangleGateTag
        
        else {}
        
    } // end of createUnivariateGateDictionaryEntry
    
    
    /// createBivariateGateDictionaryEntry creates a gate dictionary entry for a bivariate gate.
    func createBivariateGateDictionaryEntry() {
        
        if currentGateTypeSetting == CreateRectangleGateTag { // 56534
            myGate = Gates(xVar: xVariate, yVar: yVariate, gateType: RectangleGateTag)
            rectGate!.gateSubType = BivariateTag
            myGate!.rectGate = rectGate
            myGate!.gateActive = true
            Swift.print("createBivariateGateDictionaryEntry myGate!.rectGate \(String(describing: myGate!.rectGate))")
            if let delegate = delegate { // Delegate is MainViewController
                delegate.setGateDictEntryForKey(keyString(), gate: myGate!)
            } else {
                Swift.print("createBivariateGateDictionaryEntry: delegate at setGateDictEntryForKey(...) failed.")
            }
            
        } // End of CreateRectangleGateTag
            
        else if currentGateTypeSetting == CreateEllipseGateTag {
            myGate = Gates(xVar: xVariate, yVar: yVariate, gateType: EllipseGateTag)
            rectGate?.gateSubType = BivariateTag
            myGate!.rectGate = rectGate
            myGate!.gateActive = true
            Swift.print("createBivariateGateDictionaryEntry \(myGate!.rectGate!)")
            if let delegate = delegate { // Delegate is MainViewController
                delegate.setGateDictEntryForKey(keyString(), gate: myGate!)
            }
            
        } // End of CreateEllipseGateTag
            
        else if currentGateTypeSetting == CreateQuadrantGateTag { // In GRSVExtEditGates.swift
            // Only a single quadPoint is in the quadGate now.
            myGate = Gates(xVar: xVariate, yVar: yVariate, gateType: QuadrantGateTag)
            quadGate?.gateSubtype = BivariateTag
            myGate!.quadGate = quadGate
            myGate!.gateActive = true
            Swift.print("createBivariateGateDictionaryEntry \(myGate!.quadGate!)")
            if let delegate = delegate { // Delegate is MainViewController
                delegate.setGateDictEntryForKey(keyString(), gate: myGate!)
            }
            
        } // End of if CreateQuadrantGateTag
            
        else if currentGateTypeSetting == CreatePolygonGateTag {
            myGate = Gates(xVar: xVariate, yVar: yVariate, gateType: PolygonGateTag)
            polygonGate?.gateSubtype = BivariateTag
            myGate!.polygonGate = polygonGate
            myGate!.gateActive = true
            if let delegate = delegate { // Delegate is MainViewController
                delegate.setGateDictEntryForKey(keyString(), gate: myGate!)
            }
            Swift.print("createBivariateGateDictionaryEntry \(myGate!.polygonGate!)")
            
        } // End of if CreatePolygonGateTag
        
    } // End of createBivariateGateDictionaryEntry
    
    
    /// editGateDictionaryEntry. Here the gate has been changed, but the axes remain unchanged. Called from all selectAndTrack... methods Note: graphic is the HistogramGraphic object owned by GraphicSubview. keyString is a method in GraphicSubview that returns the concatenation of the xVariate-yVariate. For univariate histogram, e.g., @"1-0". Called from GRSVExt ...PolyMouseEvents ...QuadMouseEvents or ...RectMouseEvents. Also called from GraphicView.updateGateDictionaryEntries(), which is called from mvc.updateGateDictEntries(), which is called from GRSVExtRightMouse.gateTheDataSetup.
    func editGateDictionaryEntry() {
        
        if myGate == nil { // No gate to edit. myGate created in createUnivariateGateDictionaryEntry() or createBivariateGateDictionaryEntry()
            Swift.print("GRSVExtEditGates.editGateDictionaryEntry(): myGate is nil. Return w/o edit.**********")
            return
        }
        
        if currentGateTypeSetting == CreateRectangleGateTag || currentGateTypeSetting == CreateEllipseGateTag {
            if let delegate = delegate { // The delegate is MainViewController
                Swift.print("GRSVExtEditGates.editGateDictionaryEntry xVariate \(xVariate) yVariate \(yVariate)")
                myGate = delegate.retrieveGateDictEntryForKey(keyString())
                if let rGate = rectGate {
                    myGate!.rectGate! = rGate
                    delegate.setGateDictEntryForKey(keyString(), gate: myGate!)
                }
            }
        }
        
        else if currentGateTypeSetting == CreatePolygonGateTag {
            if let delegate = delegate { // The delegate is MainViewController
                myGate = delegate.retrieveGateDictEntryForKey(keyString())
                if let pGate = polygonGate {
                    myGate!.polygonGate! = pGate
                    delegate.setGateDictEntryForKey(keyString(), gate: myGate!)
                }
            }
        }
        
        else if currentGateTypeSetting == CreateQuadrantGateTag {
            if let delegate = delegate { // The delegate is MainViewController
                myGate = delegate.retrieveGateDictEntryForKey(keyString())
                if let qGate = quadGate {
                    myGate!.quadGate! = qGate
                    delegate.setGateDictEntryForKey(keyString(), gate: myGate!)
                }
            }
        }
        
        else {}
                
    } // End of editGateDictionaryEntry
    
    
    /// keyString is used throughout GraphicSubview: as key for fcs.gateDict. NSArray *gateObjects = _fcs.gateDict.allValues in GraphicView: gatedEventArray. key for fcs.gateDict (see GraphicSubview) Change:now use xVariate-yVariate instead of concatenation of axis labels.
    ///
    /// - Returns: String, e.g. "1-2"
    func keyString() -> String {
        // Used throughout GraphicSubview: as key for fcs.gateDict. NSArray *gateObjects = _fcs.gateDict.allValues in GraphicView: gatedEventArray. key for fcs.gateDict (see GraphicSubview) Change:now use xVariate-yVariate instead of concatenation of axis labels.
        
        return "\(xVariate)-\(yVariate)"
        
    } // End of keyString

} // End of extension GRSVExtEditGates
