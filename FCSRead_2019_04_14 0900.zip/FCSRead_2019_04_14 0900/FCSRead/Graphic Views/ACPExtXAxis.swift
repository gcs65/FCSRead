//
//  ACPExtXAxis.swift is an extension of the AxesChangePanel class to support x axis manipulations.
//  FCSRead
//
//  Created by Mr. Salzman on 4/8/16.
//  Copyright © 2019 Gary Salzman. All rights reserved.
//

import Cocoa

extension AxesChangePanel { // ACPExtXAxis.swift X-AXIS ***************
    
    
    /// setStateForXVariates. Called from xAxisRadioState(), which is called in setCurrentParameters()
    func setStateForXVariates() {
        switch myXAxisType {
        case LinearTag:
            enableLinearX()
        case LogTag:
            enableLogX()
        case LogicleTag, HyperlogTag, AsinhTag:
            enableAllX()
        default:
            disableAllX()
        }
    } // End of setStateForXVariates
    
    func enableLinearX() {
        myXLinEnabled = true
        myXLogEnabled = false
        myXTEnabled = false
        myXWEnabled = false
        myXMEnabled = false
        myXAEnabled = false
    } // End of enableLinearX
    
    func enableLogX() {
        myXLinEnabled = false
        myXLogEnabled = true
        myXTEnabled = false
        myXWEnabled = false
        myXMEnabled = false
        myXAEnabled = false
    } // End of enableLog
    
    func enableLogLikeX() {
        myXLinEnabled = false
        myXLogEnabled = false
        myXTEnabled = true
        myXWEnabled = true
        myXMEnabled = true
        myXAEnabled = true
    } // End of enableLogLike
    
    func disableAllX() {
        myXLinEnabled = false
        myXLogEnabled = false
        myXTEnabled = false
        myXWEnabled = false
        myXMEnabled = false
        myXAEnabled = false
    } // End of disableAllX
    
    func enableAllX() {
        myXLinEnabled = true
        myXLogEnabled = true
        myXTEnabled = true
        myXWEnabled = true
        myXMEnabled = true
        myXAEnabled = true
    } // End of enableAllX
    
    
    /// xAxisButtonPressed enables selection of one of the X Scale Types
    ///
    /// - Parameter sender: radio button for X Scale Type
    @IBAction func xAxisButtonPressed(sender: NSButton) {
        for aButton in xAxisButtonList() {
            if aButton == sender {
                aButton.state = NSControl.StateValue.on
                xAxisTypeFromXRadioState(button: aButton)
                setStateForXVariates()
                ok(aButton) // Update histogram
            } else {
                aButton.state = NSControl.StateValue.off
            }
        }
    } // End of @IBAction func xAxisButtonPressed
    
    
    /// xAxisTypeFromXRadioState. Called from xAxisButtonPressed. Sets xAxisType.
    ///
    /// - Parameter button: X Scale Type radio button
    func xAxisTypeFromXRadioState(button: NSButton) {
        for button in xAxisButtonList() {
            if button.state == NSControl.StateValue.on {
                switch button {
                case xLinearRadio:
                    myXAxisType = LinearTag
                case xLogRadio:
                    myXAxisType = LogTag
                case xLogicleRadio:
                    myXAxisType = LogicleTag
                case xHyperlogRadio:
                    myXAxisType = HyperlogTag
                case xAsinhRadio:
                    myXAxisType = AsinhTag
                default:
                    myXAxisType = ""
                }
            }
            histLimitsX!.xAxisType = xAxisType
        }
    } // End of xAxisTypeFromXRadioState
    
    
    /// xAxisRadioState. Called from setCurrentParameters(). Sets xAxis radio button state depending on myXAxisType.
    func xAxisRadioState() {
        switch myXAxisType {
        case LinearTag:
            xLinearRadio.state = NSControl.StateValue.on
        case LogTag:
            xLogRadio.state = NSControl.StateValue.on
        case LogicleTag:
            xLogicleRadio.state = NSControl.StateValue.on
        case HyperlogTag:
            xHyperlogRadio.state = NSControl.StateValue.on
        case AsinhTag:
            xAsinhRadio.state = NSControl.StateValue.on
        default:
            print("myXAxisType: \(myXAxisType)")
            exit(-1)
        }
    } // End of xAxisRadioState
    
    
    /// restrictXLogicleParameters. Called from xAxisTypeMatrixAction to restrict range of Logicle parameters.
    func restrictXLogicleParameters() {
        // T & M > 0 and W >= 0 guaranteed by numberFormatters
        if myXW > 0.5 * myXM {
            myXW = 0.5 * myXM // range is linear at xW = 0.5 * xM
        }
        if -myXA > myXW || -myXA + myXW > myXM - myXW {
            myXA = -myXW
        }
        
    } // End of restrictXLogicleParameters
    
    
    /// restrictXLogLimits. Restrict xMinLog and xMaxLog to major or minor tic positions. Major tic positions at 10^-1, 10^0, etc. Minor tic positions in between: 0.2, 0.3...200, 300, 400... For example, _xMinLog value of 0.25 converted to 0.2. Force xMin to minor tic decades (25->20, etc.)
    func restrictXLogLimits() {
        var base = 0.0
        var temp = 0.0
        
        if xMinLog == 0.0 {
            xMinLog = 1.0
        }
        base = floor(log10(xMinLog)) // = -1 for xMinLog = (0,1)???
        temp = xMinLog * pow(10.0, -base) // temp = (1,10)
        xMinLog = floor(temp) * pow(10.0, base)
        // Force xMaxLog to next higher minor tic decade.
        if xMaxLog == 0.0 {
            xMaxLog = 1.0
        }
        base = floor(log10(xMaxLog))
        temp = xMaxLog * pow(10.0, -base)
        xMaxLog = ceil(temp) * pow(10.0, base)
        print("restrictXLogLimits xMinLog: \(xMinLog) xMaxLog: \(xMaxLog)")
        
    } // End of restrictXLogLimits

} // End of extension AxesChangePanel for ACPExtXAxis
