//
//  GRSVExtPolyMouseEvents.swift Graphic subviewe extension for polygon creation and editing.
//  FCSRead
//
//  Created by Mr. Salzman on 3/24/16.
//  Copyright © 2019 Gary Salzman. All rights reserved.
//

import Cocoa

extension GraphicSubview { // GRSVExtPolyMouseEvents
    
    
    /// createPolygonGate creates a polygon gate following a right click on a bivariate histogram and selection of "Create Polygon Gate"
    ///
    /// - Parameter event: right click event followed by left click selecction.
    func createPolygonGate(_ event: NSEvent) {
        
        var graphicPt = convert(event.locationInWindow, from: nil)
        
        constrainPointToHistogramBox(&graphicPt)
        
        if polygonGate == nil { // Add 1st polyPt
            currentGateClass = PolygonGate.self
            polygonGate = PolygonGate(frameRect: NSZeroRect, view: self)
            polygonGate!.bounds = histogramGraphic!.innerBox
            polygonGate!.gateType = PolygonGateTag
            polygonGate!.currentHandle = 0
            polygonGate!.polyPtIndex = 0
            polygonGate!.currentPt = graphicPt
            let myPolyPt = createPolyPtWithEvent(event)
            polygonGate!.polyPtArray.append(myPolyPt)
            // createPolyPtWithEvent increments currentHandle and polyPtIndex.
        } // End of if polygonGate == nil (add 1st polyPt)
            
        else { // polygonGate exists, add next polyPt
            polygonGate?.currentPt = graphicPt
            let myPolyPt = createPolyPtWithEvent(event)
            if myPolyPt.isLastPoint == true {
                // this polyPt will replace the previous polyPt. The only change is that myPolyPt.isLastPoint is now true.
                polygonGate!.polyPtArray.removeLast()
                polygonGate!.polyPtArray.append(myPolyPt)
                polygonGate!.polygonGateExists = true
                NSCursor.arrow.set()
            } // End of if myPolyPt.isLastPoint == true
                
            else { // Not the last polyPt
                polygonGate!.polyPtArray.append(myPolyPt)
            }
        } // End of polygonGate exists, add polyPt ...
        
        setNeedsDisplay(innerBoxDrawingBounds())
        
        if polygonGate!.polygonGateExists == true {
            // createBivariateGateDictionaryEntry puts a copy of the polyPtArray into Gates so that if the axes are changed, the graphical polyPtArray can be restored on the display.
            createBivariateGateDictionaryEntry()
            gateActionMode = 1 // Switch to edit mode
            NSCursor.arrow.set()
        }
        
    } // End of createPolygonGate
    
    
    /// polygonGateUnderPoint selects whether the contents of the polygon or a vertex of the polygon are selected by left mouse. Point is on the polygonGate selection handle (selectedGateHandle) or on the gate itself(gateContentSelected). Called from selectAndTrackPolyMouse...
    ///
    /// - Parameter point: NSPoint at the tip of the mouse arrow
    /// - Returns: boolean for gateContentSelected or an integer showing which vertex was selected.
    func polygonGateUnderPoint(_ point: NSPoint) -> (gateContentSelected: Bool, selectedGateHandle: Int) {

        
        var gateContentSelected = false
        var selectedGateHandle = GateNoHandle
        
        if NSPointInRect(point, polygonGate!.drawingBounds()) {
            // Check the gate's selection handles first, because they take precedence when they overlap the gate's contents.
            let handle = polygonGate!.handleUnderPoint(point)
            if handle != GateNoHandle { // The user clicked on a handle of the gate.
                selectedGateHandle = handle // Now have valid handle.
                gateContentSelected = false
            }
                
            else { // Inside drawingBounds but not on a handle
                gateContentSelected = polygonGate!.isContentsUnderPoint(point)
                if gateContentSelected == true {
                    // The user clicked on the contents of a gate (ready to drag gate)
                    selectedGateHandle = GateNoHandle
                }
            }
            
        } // End of NSPointInRect(...
        
        return (gateContentSelected, selectedGateHandle)
        
    } // End of polygonGateUnderPoint
    
    
    /// createPolyPtWithEvent is called from createPolygonGate and when polyPoint objects are added to the polygon. newPolyPt.pt is referenced to the window location at [0,0] rather than to the lower-left corner of the histogramBox.
    ///
    /// - Parameter event: mouseDown event
    /// - Returns: a PolyPoint
    func createPolyPtWithEvent(_ event: NSEvent) -> PolyPoint {

        var myEvent = event
        var handleLocation = NSZeroPoint
        
        if myEvent.clickCount == 1 { // Single left mouse down (newPolyPt)
            Swift.print("myEvent.clickCount \(myEvent.clickCount)")
            while myEvent.type != NSEvent.EventType.leftMouseUp {
                myEvent = (window?.nextEvent(matching: NSEvent.EventTypeMask(rawValue: UInt64(Int(NSEvent.EventTypeMask.leftMouseUp.union(.leftMouseDragged).rawValue)))))!
                autoscroll(with: myEvent)
                // handleLocation includes xOffset and yOffset.
                handleLocation = convert(myEvent.locationInWindow, from: nil)
                polygonGate?.restrictLocationOfPoint(&handleLocation)
                // Lower-left corner of histogramBox is at [xOffset, yOffset]
                
                polyPt = PolyPoint(myPoint: handleLocation, myHandle: (polygonGate!.currentHandle), key: "", isLastPoint: false) // Template for polyPt
                polyPt!.pKey = NSString.localizedStringWithFormat("P%i", polygonGate!.polyPtIndex) as String
                
                polygonGate!.currentPt = handleLocation
                Swift.print("createPolyPtWithEvent \(String(describing: polyPt))")
                polygonGate!.currentHandle += 1 // Prepare for next point.
                polygonGate!.polyPtIndex += 1
            } // Left mouse now up
        } // End of myEvent.clickCount == 1
            
        else if myEvent.clickCount == 2 { // Double click to set last point in polygon.
            Swift.print("myEvent.clickCount \(myEvent.clickCount)")
            polygonGate!.currentHandle -= 1 // Previous point was last point.
            polygonGate!.polyPtIndex -= 1
            while myEvent.type != NSEvent.EventType.leftMouseUp {
                myEvent = (window?.nextEvent(matching: NSEvent.EventTypeMask(rawValue: UInt64(Int(NSEvent.EventTypeMask.leftMouseUp.union(.leftMouseDragged).rawValue)))))!
                autoscroll(with: myEvent)
                polyPt?.isLastPoint = true
                Swift.print("createPolyPtWithEvent.lastPoint \(String(describing: polyPt))")
            } // Left mouse now up
            
        } // End of myEvent.clickCount > 1
            
        else {
            polyPt = PolyPoint() // Empty
        }
        
        return polyPt!
        
    } // End of createPolyPtWithEvent
    
    
    /// selectAndTrackPolyMouseWithEvent enables selection of a gate handle or the gate itself. Returns iVars gateContentsSelected and selectGateHandle
    ///
    /// - Parameter event: left mouseDown event.
    func selectAndTrackPolyMouseWithEvent(_ event: NSEvent) {
        
        var gateContentsSelected = false
        var selectedGateHandle = GateNoHandle
        
        if polygonGate == nil { // Can't edit if there is no gate.
            return
        }
        
        // Has the user clicked on a polygonGate?
        let mouseLocation = convert(event.locationInWindow, from: nil)
        
        (gateContentsSelected, selectedGateHandle) = polygonGateUnderPoint(mouseLocation)
        
        if polygonGate!.bounds != NSZeroRect { // polygonGate is valid and mouse is somewhere over the gate. Clicking on a gate handle takes precedence.
            if selectedGateHandle != GateNoHandle {
                Swift.print("polygon handle selected") // mouse is over a handle. The user clicked on a gate's handle. Let the user drag the handle around.
                resizePolygonGateUsing(selectedGateHandle, event: event)
            }
                
            else if gateContentsSelected == true { // The user clicked on a gate's contents. Let the user move the polygon gate.
                Swift.print("polygon content selected")
                movePolygonGateWithEvent(event)
            }
                
            else {}
            
            editGateDictionaryEntry()
                        
        } // End of if polygonGate.bounds != NSZeroRect (valid polygonGate)
        
    } // End of selectAndTrackPolyMouseWithEvent
    
    
    /// resizePolygonGateUsing enables resizing polygonGate by dragging a vertex. Called from selectAndTrackPolyMouseWithEvent. Passed in handle numbers start at 0.
    ///
    /// - Parameters:
    ///   - handle: selectedGateHandle
    ///   - event: mouseDown (left) event.
    func resizePolygonGateUsing(_ handle: Int, event: NSEvent) {
        var myEvent = event
        var handleLocation = NSZeroPoint
        
        while myEvent.type != NSEvent.EventType.leftMouseUp {
            myEvent = (window?.nextEvent(matching: NSEvent.EventTypeMask(rawValue: UInt64(Int(NSEvent.EventTypeMask.leftMouseUp.union(.leftMouseDragged).rawValue)))))!
            autoscroll(with: myEvent)
            handleLocation = convert(myEvent.locationInWindow, from: nil)
            polygonGate!.resizeByMovingHandle(handle, point: &handleLocation)
            setNeedsDisplay(innerBoxDrawingBounds())
        } // Left mouse up here
        
    } // End of resizePolygonGate
    
    
    /// movePolygonGateWithEvent enables moving of polygonGate. Called from selectAndTrackPolyMouseWithEvent.
    ///
    /// - Parameter event: mouseDown event inside polygonGate to move the polygon.
    func movePolygonGateWithEvent(_ event: NSEvent) {
        var lastPoint = NSZeroPoint
        var curPoint = NSZeroPoint
        var isMoving = false
        var myEvent = event
        
        lastPoint = convert(event.locationInWindow, from: nil)
        
        while myEvent.type != NSEvent.EventType.leftMouseUp {
            myEvent = (window?.nextEvent(matching: NSEvent.EventTypeMask(rawValue: UInt64(Int(NSEvent.EventTypeMask.leftMouseUp.union(.leftMouseDragged).rawValue)))))!
            autoscroll(with: myEvent)
            curPoint = convert(myEvent.locationInWindow, from: nil)
            if !isMoving && (abs(curPoint.x - lastPoint.x) >= 2.0) || (abs(curPoint.y - lastPoint.y) >= 2.0) {
                isMoving = true
                isHidingHandles = true
                
            } // End of if !isMoving...
            
            if isMoving {
                if !NSEqualPoints(lastPoint, curPoint) {
                    isHidingHandles = true
                    var tempX = curPoint.x - lastPoint.x
                    var tempY = curPoint.y - lastPoint.y
                    polygonGate!.translatePolygonByX(&tempX, deltaY: &tempY)
                }
                
                lastPoint = curPoint
                setNeedsDisplay(innerBoxDrawingBounds())
                
            } // End of if isMoving == true
            
        } // End of while loop. LeftMouseUp at this point
        
        setNeedsDisplay(innerBoxDrawingBounds())
        
        isHidingHandles = false
        
    } // End of movePolygonGateWithEvent

} // End of GRSVExtPolyMouseEvents
