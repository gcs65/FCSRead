//
//  GraphicSubview.swift Display for one histogram.
//  FCSRead
//
//  Created by Mr. Salzman on 12/20/17.
//  Copyright © 2019 Gary Salzman. All rights reserved.
//
//  // View for each histogram.

import Cocoa

protocol GraphicSubviewDelegate { // delegate is MainViewController.
    func generateUnivariateHistogramWithVariate(_ varNum: Int) -> UnivariateHistogram
    func generateBivariateHistogramWithXVariate(_ xVariate: Int, yVariate: Int) -> BivariateHistogram
    func gateTheData() -> Bool // Returns mainVC.isDataGated true.
    func gateTheQuadrantData() -> Bool // returns mainVC.isDataGated true.
    func gateTheDataSequentially() -> Bool // Returns mainVC.isDataGated true.
    func ungateTheData() -> Bool // Returns mainVC.isDataGated false.
    func statistics() // opens window showing gate statistics
    func setGateDictEntryForKey(_ key: String, gate: Gates)
    func retrieveGateDictEntryForKey(_ key: String) -> Gates
    func deleteGateDictEntryForKey(_ key: String)
    func deleteAllGateDictEntries()
    func updateGateDictEntries()
    func isTheDataGated() -> Bool // Returns mainViewController.isDataGated
    func gateDictCount() -> Int
    func getMainViewController() -> MainViewController
}

// These are used in GraphicSubviewExtRightMouse.swift
// They are returned as currentGateTypeSetting = sender.tag()
let CreateNoGateTag = 56580 // Right click popup "No selection"
let CreateRectangleGateTag = 56533 // Right click popup "Create RectangleGate"
let CreateEllipseGateTag = 56534 // Right click popup "Create EllipseGate"
let CreateQuadrantGateTag = 56535 // Right click popup "Create QuadrantGate"
let MergeSelectedQuadrantRectsTag = 56536 // Right click popup
let GateTheDataTag = 56537 // Right click popup "Gate The Data"
let UngateTheDataTag = 56538 // Right click popup "Ungate The Data"
let CreateAndShowQuadrantRectsTag = 56539 // Right click popup "Show QuadrantRects"
let CreatePolygonGateTag = 56540 // Right click popup "Create Polygon Gate"
let ChangeAxesTag = 56550 // Right click popup "Change Axes label"
let ShowCursorLocationTag = 56560 // Right click popup "Show cursor location"
let RotateEllipseGateTag = 56570 // Right click popup "Rotate Ellipse Gate"


class GraphicSubview: GraphicView {
    
    /* These values are set in AppDelegate.registrationDictionary. See GraphicView.
     Preferences.OuterBoxHeightKey:510.0 as CGFloat,
     Preferences.OuterBoxWidthKey:560.0 as CGFloat,
     Preferences.InnerBoxWidthKey:400.0 as CGFloat,
     Preferences.InnerBoxHeightKey:400.0 as CGFloat,
     Preferences.XOffsetKey:120.0 as CGFloat,
     Preferences.YOffsetKey:70.0 as CGFloat,
     Preferences.FontNameKey:"Helvetica" as String,
     Preferences.FontSizeKey:12.0 as CGFloat
     */
    
    var histogramType = UnknownTag // BivariateTag or UnivariateTag (see MainViewController)
    var myFrame = NSZeroRect
    var xVariate = 0
    var yVariate = 0
    var axesChangePanel: AxesChangePanel?
    var delegate: GraphicSubviewDelegate?
    var bivHist: BivariateHistogram?
    var gatedBivHist: BivariateHistogram?
    var uniHist: UnivariateHistogram?
    var gatedUniHist: UnivariateHistogram?
    var histogramGraphic: HistogramGraphic?
    
    var currentGateClass: AnyClass?
    var myGate: Gates? // Includes the variates and the gates below.
    var rectGate: RectGate? // Can be either univariate or bivariate.
    var polygonGate: PolygonGate?
    var polyPt: PolyPoint?
    var quadGate: QuadGate?
    var currentGateTypeSetting = 0
    var currentAxisTypeSetting = 0
    var gateActionMode = 0 // create = 0, startEdit = 1, add quadElement = 2
    
    var mouseInsideHistogramBox = false // See mouseEntered( and mouseExited(.
    var myUserInfo = [String: AnyObject]() // Used by myTrackingArea.
    var myTrackingArea : NSTrackingArea?
    var isHidingHandles = false
    var showCursorLocationSetting = 0
    var mouseGraphicLocation = NSZeroPoint
    var mouseRealLocation = NSZeroPoint
    var mouseXYLocationString = NSAttributedString()
    var mouseXYLocationStringAttributes: [NSAttributedString.Key:Any] = [:] // Swift 4; was String
    
    override init(frame frameRect: NSRect) {
        super.init(frame: frameRect)
        myFrame = frameRect
    }
    

    /// convenience init initializes the frame for a bivariate graphic subview.
    ///
    /// - Parameters:
    ///   - frameRect: frame rectangle for a bivariate graphic subview
    ///   - xVar: x variate
    ///   - yVar: y variate
    ///   - mainVC: MainViewController
    convenience init(frame frameRect: NSRect, xVar: Int, yVar: Int, mainVC: MainViewController) { // Bivariate
        self.init(frame: frameRect)
        xVariate = xVar
        yVariate = yVar
        histogramType = BivariateTag
        // Note: mainViewController was passed into GraphicView in createSubviews.
        mainViewController = mainVC
        delegate = mainViewController
        if let del = delegate { // The delegate is MainViewController
            bivHist = del.generateBivariateHistogramWithXVariate(xVariate, yVariate: yVariate)
            histogramGraphic = HistogramGraphic(myFrame: myFrame, xVar: xVariate, yVar: yVariate, view: self, mainVC: mainViewController!)
            myUserInfo = ["XVariateKey":xVariate as AnyObject, "YVariateKey":yVariate as AnyObject, "HistogramTypeKey":histogramType as AnyObject] // Used by myTrackingArea.
            myAddTrackingArea()
        }
    } // End of convenience init for bivariate
    
    
    /// convenience init initializes the frame for a univariate graphic subview.
    ///
    /// - Parameters:
    ///   - frameRect: frame rectangle for a univariate graphic subview.
    ///   - xVar: x variate
    ///   - mainVC: MainViewController
    convenience init(frame frameRect: NSRect, xVar: Int, mainVC: MainViewController) { // Univariate
        self.init(frame: frameRect)
        xVariate = xVar
        yVariate = 0 // Clue that this is a univariate histogram.
        histogramType = UnivariateTag
        mainViewController = mainVC
        delegate = mainViewController
        if let del = delegate { // The delegate is MainViewController
            uniHist = del.generateUnivariateHistogramWithVariate(xVariate)
            histogramGraphic = HistogramGraphic(myFrame: myFrame, variate: xVariate, view: self, mainVC: mainViewController!)
            myUserInfo = ["XVariateKey":xVariate as AnyObject, "YVariateKey":0 as AnyObject, "HistogramTypeKey":histogramType as AnyObject] // Used by myTrackingArea.
            myAddTrackingArea()
        }
        
    } // End of convenience init for univariate
    
    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
    }
    
    
    /// axesChangedBivariate generates a new bivariate based on changes in axes from AxesChangePanel.ok. Delegate is MainViewController.
    func axesChangedBivariate() {
        if let delegate = delegate {
            bivHist = nil
            bivHist = delegate.generateBivariateHistogramWithXVariate(xVariate, yVariate: yVariate)
            if let hG = histogramGraphic {
                hG.axesShouldChange = true
                _ = hG.prepareBivariateDrawingContents()
            } else {
                print("GSV.axesChangedBivariate: histogramGraphic is nil")
                exit(-1)
            }
            myUserInfo = ["XVariateKey":xVariate as AnyObject, "YVariateKey":yVariate as AnyObject, "HistogramTypeKey":histogramType as AnyObject]
            myAddTrackingArea()
        }
    } // End of GraphicSubview.axesChangedBivariate
    
    
    /// axesChangedUnivariate generates a new univariate based on changes in axes from AxesChangePanel.ok. Delegate is MainViewController.
    func axesChangedUnivariate() {
        if let delegate = delegate {
            uniHist = nil
            uniHist = delegate.generateUnivariateHistogramWithVariate(xVariate)
            if let hG = histogramGraphic {
                hG.axesShouldChange = true
                _ = hG.prepareUnivariateDrawingContents()
            } else {
                print("GSV.axesChangedUnivariate: histogramGraphic is nil")
                exit(-1)
            }
        }
        myUserInfo = ["XVariateKey":xVariate as AnyObject, "YVariateKey":0 as AnyObject, "HistogramTypeKey":histogramType as AnyObject]
        myAddTrackingArea()

        // Note: When displaying a univariate and a bivariate: Change xMin on univariate and then do change axes on the bivariate and click OK if you want the bivariate scales updated. xMin is updated on change axes panel, but xMin is not updated on display.
    } // End of GraphicSubview.axesChangedUnivariate
    
    
    /// innerBoxDrawingBounds creates a rect for the inner bounds of a histogram. The inner bounds are the bounds of the actual histogram. The outer bounds include space for the axis labels.
    ///
    /// - Returns: rect for the inner bounds.
    func innerBoxDrawingBounds() -> NSRect {
        let rect = NSMakeRect(histogramGraphic!.xOffset, histogramGraphic!.yOffset, histogramGraphic!.innerBoxWidth, histogramGraphic!.innerBoxHeight)
        let drawingBounds = NSInsetRect(rect, -3.0, -3.0)
        return drawingBounds
        
    } // End of innerBoxDrawingBounds
    
    
    /// myAddTrackingArea creates an NSTrackingArea for the mouse over a histogram.
    func myAddTrackingArea() {
        myRemoveTrackingArea()
        
        let trackingOptions : NSTrackingArea.Options = NSTrackingArea.Options(rawValue: 0x01 | 0x02 | 0x04 | 0x40 | 0x400)
        // 0x01 = NSTrackingAreaOptions.MouseEnteredAndExited
        // 0x02 = NSTrackingAreaOptions.MouseMoved
        // 0x04 = NSTrackingAreaOptions.CursorUpdate
        // 0x40 = NSTrackingAreaOptions.ActiveInActiveApp
        // 0x400 = NSTrackingAreaOptions.EnabledDuringMouseDrag
        myTrackingArea = NSTrackingArea(rect: innerBoxDrawingBounds(), options: trackingOptions, owner: self, userInfo: myUserInfo) // Track the entire view (bounds)
        addTrackingArea(myTrackingArea!)
    } // End of myAddTrackingArea
    
    
    /// myRemoveTrackingArea removes myTrackingArea
    func myRemoveTrackingArea() {
        if myTrackingArea != nil {
            removeTrackingArea(myTrackingArea!)
            myTrackingArea = nil
        }
    }
    
    
    /// cursorUpdate updates the type of cursor displayed over the histogram.
    ///
    /// - Parameter event: mouseDown event
    override func cursorUpdate(with event: NSEvent) {
        // ready to create gate(0), edit gate(1) or add quadElement(2)
        if mouseInsideHistogramBox { // true (inside)
            if gateActionMode == 0 || gateActionMode == 2 {
                NSCursor.crosshair.set()
            }
            else { // ready to edit gate (gateActionMode = 1)
                NSCursor.arrow.set()
            }
        } // End of mouseInsideHistogramBox
            
        else { // false (outside) or exiting
            NSCursor.arrow.set()
        }
        
        display()
        
    } // End of cursorUpdate
    
    
    /// mouseEntered detects when the mouse is inside the inner box of the histogram.
    ///
    /// - Parameter theEvent: mouse moved event.
    override func mouseEntered(with theEvent: NSEvent) {
        mouseInsideHistogramBox = true
        display()
    } // End of mouseEntered
    
    
    /// mouseExited detects when the mouse leaves the inner box of the histogram.
    ///
    /// - Parameter theEvent: mouse exited event.
    override func mouseExited(with theEvent: NSEvent) {
        mouseInsideHistogramBox = false
        display()
    } // End of mouseExited
    
    
    /// draw does the actual drawing for the GraphicSubview.
    ///
    /// - Parameter dirtyRect: <#dirtyRect description#>
    override func draw(_ dirtyRect: NSRect) { // GraphicSubview
        super.draw(dirtyRect)
        let currentContext = NSGraphicsContext.current
        currentContext?.saveGraphicsState()
        if histogramType == UnivariateTag {
            if histogramGraphic!.drawUnivariateHistogramInView(self) == false {
                Swift.print("GraphicSubview.histogramGraphic.drawUnivariateHistogramInView failed.")
            }
        }
        else if histogramType == BivariateTag {
            if histogramGraphic!.drawBivariateHistogramInView(self) == false {
                Swift.print("GraphicSubview.histogramGraphic.drawBivariateHistogramInView failed.")
            }
        }
        else {}
        currentContext?.restoreGraphicsState()
        
        if delegate!.isTheDataGated() == true { // returns MainViewController.isTheDataGated
            if histogramType == UnivariateTag {
                if histogramGraphic!.drawGatedUnivariateHistogramOverlayInView(self) == false {
                    Swift.print("GraphicSubview.histogramGraphic!.drawGatedUnivariateHistogramOverlayInView failed.")
                }
            }
            else if histogramType == BivariateTag {
                if histogramGraphic!.drawGatedBivariateHistogramOverlayInView(self) == false {
                    Swift.print("GraphicSubview.histogramGraphic!.drawGatedBivariateHistogramOverlayInView failed.")
                }
            }
            else {}
        }
        
        if mouseInsideHistogramBox {
            // Cursor changes from Arrow to large Cross on entry.
            // Right click menu to Show/Hide extended cursor.
            
            if showCursorLocationSetting == 1 { // Show mouseRealLocation & mouseGraphicLocation.
                let xyTextR = String(format:"X: %6.3g, Y: %6.3g", mouseRealLocation.x, mouseRealLocation.y)
                mouseXYLocationString = NSAttributedString(string: xyTextR, attributes: mouseXYLocationStringAttributes)
                let ptR = NSMakePoint(1.05 * histogramGraphic!.xOffset, 0.95 * (histogramGraphic!.yOffset + histogramGraphic!.innerBoxHeight))
                mouseXYLocationString.draw(at: ptR)
                
                let xyTextG = String(format:"X: %6.3g, Y: %6.3g", mouseGraphicLocation.x, mouseGraphicLocation.y)
                mouseXYLocationString = NSAttributedString(string: xyTextG, attributes: mouseXYLocationStringAttributes)
                let ptG = NSMakePoint(1.05 * histogramGraphic!.xOffset, 0.90 * (histogramGraphic!.yOffset + histogramGraphic!.innerBoxHeight))
                mouseXYLocationString.draw(at: ptG)
            } // End of showCursorLocationSetting == 1
        } // End of mouseInsideHistogramBox
        
        // Draw whichever gate exists
        if currentGateClass == RectGate.self && rectGate != nil {
            rectGate!.drawContentsInView(self)
            if isHidingHandles == false {
                NSColor.black.setStroke()
                rectGate!.drawHandlesInView(self)
            }
        }
            
        else if currentGateClass == QuadGate.self && quadGate != nil {
            quadGate!.drawContentsInView(self)
        }
            
        else if currentGateClass == PolygonGate.self && polygonGate != nil {
            polygonGate!.drawContentsInView(self)
        }
    } // End of draw
    
    func acceptsFirstResponder(_ sender: AnyObject) -> Bool {
        return true
    }
    
} // End of class GraphicSubview
