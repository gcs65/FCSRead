//
//  AxesChangePanel.swift. This class supports the AxesChangePanel, which enables a user to change histogram axes in a variety of ways.
//  FCSRead
//
//  Created by Mr. Salzman on 4/6/16.
//  Copyright © 2019 Gary Salzman. All rights reserved.
//

import Cocoa

class AxesChangePanel: NSWindowController {
    
    weak var graphicSubview: GraphicSubview?
    
    var xVar = 0 // X-Axis ****************************************
    @IBOutlet weak var xLinearRadio: NSButton!
    @IBOutlet weak var xLogRadio: NSButton!
    @IBOutlet weak var xLogicleRadio: NSButton!
    @IBOutlet weak var xHyperlogRadio: NSButton!
    @IBOutlet weak var xAsinhRadio: NSButton!
    var histLimitsX: HistLimits?
    var xAxisLabel = ""
    
    var xAxisType = "" // LinearTag, LogTag, LogicleTag, HyperlogTag, AsinhTag
    var logLikeScaleTransformX = 0 // Logicle
    var xMinLin = 0.0
    var xMaxLin = 0.0
    var xMinLog = 1.0
    var xMaxLog = 1.0
    var xT = 0.0
    var xW = 0.0
    var xM = 0.0
    var xA = 0.0
    
    var xAxisLabelEnabled = true
    var xLinEnabled = false
    var xLogEnabled = false
    var xTEnabled = false
    var xWEnabled = false
    var xMEnabled = false
    var xAEnabled = false
    
    // Enabling xVars
    @objc dynamic var myXAxisLabelEnabled: Bool {
        set {xAxisLabelEnabled = newValue}
        get {return xAxisLabelEnabled}}
    @objc dynamic var myXLinEnabled: Bool {
        set {xLinEnabled = newValue}
        get {return xLinEnabled}}
    @objc dynamic var myXLogEnabled: Bool {
        set {xLogEnabled = newValue}
        get {return xLogEnabled}}
    @objc dynamic var myXTEnabled: Bool {
        set {xTEnabled = newValue}
        get {return xTEnabled}}
    @objc dynamic var myXWEnabled: Bool {
        set {xWEnabled = newValue}
        get {return xWEnabled}}
    @objc dynamic var myXMEnabled: Bool {
        set {xMEnabled = newValue}
        get {return xMEnabled}}
    @objc dynamic var myXAEnabled: Bool {
        set {xAEnabled = newValue}
        get {return xAEnabled}}
    
    // Getting/Setting xVars
    @objc dynamic var myXAxisLabel: String { // bound to value of text field in ACP
        set {xAxisLabel = newValue;histLimitsX!.xAxisLabel = xAxisLabel;histLimitsDict[xVar] = histLimitsX!}
        get {return xAxisLabel}}
    @objc dynamic var myXAxisType: String { // Set initially in setCurrentParameters(). Changed in xAxisTypeFromXRadioState(), which is called from xAxisButtonPressed().
        set {xAxisType = newValue;histLimitsX!.xAxisType = xAxisType;histLimitsDict[xVar] = histLimitsX!}
        get {return xAxisType}}
    @objc dynamic var myLogLikeScaleTransformX: Int {
        set {logLikeScaleTransformX = newValue;histLimitsX!.logLikeScaleTransform = logLikeScaleTransformX;histLimitsDict[xVar] = histLimitsX!}
        get {return logLikeScaleTransformX}}
    @objc dynamic var myXMinLin: Double {
        set {xMinLin = newValue;histLimitsX!.xMinLin = xMinLin;histLimitsDict[xVar] = histLimitsX!}
        get {return xMinLin}}
    @objc dynamic var myXMaxLin: Double {
        set {xMaxLin = newValue;histLimitsX!.xMaxLin = xMaxLin;histLimitsDict[xVar] = histLimitsX!}
        get {return xMaxLin}}
    @objc dynamic var myXMinLog: Double {
        set {xMinLog = newValue;histLimitsX!.xMinLog = xMinLog;histLimitsDict[xVar] = histLimitsX!}
        get {return xMinLog}}
    @objc dynamic var myXMaxLog: Double {
        set {xMaxLog = newValue;histLimitsX!.xMaxLog = xMaxLog;histLimitsDict[xVar] = histLimitsX!}
        get {return xMaxLog}}
    @objc dynamic var myXT: Double {
        set {xT = newValue;histLimitsX!.T = xT;histLimitsX!.logicleT = xT;histLimitsDict[xVar] = histLimitsX!}
        get {return xT}}
    @objc dynamic var myXW: Double {
        set {xW = newValue;histLimitsX!.W = xW;histLimitsX!.logicleW = xW;histLimitsDict[xVar] = histLimitsX!}
        get {return xW}}
    @objc dynamic var myXM: Double {
        set {xM = newValue;histLimitsX!.M = xM;histLimitsX!.logicleM = xM;histLimitsDict[xVar] = histLimitsX!}
        get {return xM}}
    @objc dynamic var myXA: Double {
        set {xA = newValue;histLimitsX!.A = xA;histLimitsX!.logicleA = xA;histLimitsDict[xVar] = histLimitsX!}
        get {return xA}}
    
    var yVar = 0 // Y-Axis****************************************
    @IBOutlet weak var yLinearRadio: NSButton!
    @IBOutlet weak var yLogRadio: NSButton!
    @IBOutlet weak var yLogicleRadio: NSButton!
    @IBOutlet weak var yHyperlogRadio: NSButton!
    @IBOutlet weak var yAsinhRadio: NSButton!
    var histLimitsY: HistLimits?
    var yAxisLabel = ""
    var yAxisType = "" // LinearTag, LogTag, LogicleTag, HyperlogTag, AsinhTag
    var yAutoScale = true
    var logLikeScaleTransformY = 0 // Logicle
    var yMinLin = 0.0
    var yMaxLin = 0.0
    var yMinLog = 1.0
    var yMaxLog = 1.0
    
    var yT = 0.0
    var yW = 0.0
    var yM = 0.0
    var yA = 0.0
    
    var yAxisLabelEnabled = true
    var yLinEnabled = false
    var yLogEnabled = false
    var yTEnabled = false
    var yWEnabled = false
    var yMEnabled = false
    var yAEnabled = false
    var yAutoScaleEnabled = true
    
    var yLogicleScaleEnabled = false
    var yHyperlogScaleEnabled = false
    var yAsinhScaleEnabled = false
    
    // Enabling yVars
    @objc dynamic var myYLogicleScaleEnabled: Bool {
        set {yLogicleScaleEnabled = newValue}
        get {return yLogicleScaleEnabled}}
    @objc dynamic var myYHyperlogScaleEnabled: Bool {
        set {yHyperlogScaleEnabled = newValue}
        get {return yHyperlogScaleEnabled}}
    @objc dynamic var myYAsinhScaleEnabled: Bool {
        set {yAsinhScaleEnabled = newValue}
        get {return yAsinhScaleEnabled}}
    @objc dynamic var myYAxisLabelEnabled: Bool {
        set {yAxisLabelEnabled = newValue}
        get {return yAxisLabelEnabled}}
    @objc dynamic var myYLinEnabled: Bool {
        set {yLinEnabled = newValue}
        get {return yLinEnabled}}
    @objc dynamic var myYLogEnabled: Bool {
        set {yLogEnabled = newValue}
        get {return yLogEnabled}}
    @objc dynamic var myYTEnabled: Bool {
        set {yTEnabled = newValue}
        get {return yTEnabled}}
    @objc dynamic var myYWEnabled: Bool {
        set {yWEnabled = newValue}
        get {return yWEnabled}}
    @objc dynamic var myYMEnabled: Bool {
        set {yMEnabled = newValue}
        get {return yMEnabled}}
    @objc dynamic var myYAEnabled: Bool {
        set {yAEnabled = newValue}
        get {return yAEnabled}}
    @objc dynamic var myYAutoScaleEnabled: Bool {
        set {yAutoScaleEnabled = newValue
            if graphicSubview!.histogramType == BivariateTag {yAutoScaleEnabled = false}}
        get {return yAutoScaleEnabled}}
    
    // Getting/Setting yVars
    @objc dynamic var myYAxisLabel: String {
        set {yAxisLabel = newValue
            if graphicSubview!.histogramType == BivariateTag {
                histLimitsY!.xAxisLabel = yAxisLabel;histLimitsDict[yVar] = histLimitsY!
            }else {histLimitsX!.yAxisLabel = yAxisLabel;histLimitsDict[xVar] = histLimitsX!}} // Univariate
        get {return yAxisLabel}}
    @objc dynamic var myYAxisType: String { // Set initially in setCurrentParameters(). Changed in yAxisTypeFromYRadioState(), which is called from yAxisButtonPressed().
        set {yAxisType = newValue
            if graphicSubview!.histogramType == BivariateTag {
                histLimitsY!.xAxisType = yAxisType;histLimitsDict[yVar] = histLimitsY!
            }else {histLimitsX!.yAxisType = yAxisType;histLimitsDict[xVar] = histLimitsX!}} // Univariate
        get {return yAxisType}}
    @objc dynamic var myLogLikeScaleTransformY: Int {
        set {logLikeScaleTransformY = newValue
            if graphicSubview!.histogramType == BivariateTag {
                histLimitsY!.logLikeScaleTransform = logLikeScaleTransformY;histLimitsDict[yVar] = histLimitsY!
            }else {histLimitsX!.logLikeScaleTransform = logLikeScaleTransformY;histLimitsDict[xVar] = histLimitsX!}} // Univariate
        get {return logLikeScaleTransformY}}
    @objc dynamic var myYMinLin: Double {
        set {yMinLin = newValue
            if graphicSubview!.histogramType == BivariateTag {
                histLimitsY!.xMinLin = yMinLin;histLimitsDict[yVar] = histLimitsY!
            }else {histLimitsX!.yMinLin = yMinLin;histLimitsDict[xVar] = histLimitsX!}} // Univariate
        get {return yMinLin}}
    @objc dynamic var myYMaxLin: Double {
        set {yMaxLin = newValue
            if graphicSubview!.histogramType == BivariateTag {
                histLimitsY!.xMaxLin = yMaxLin;histLimitsDict[yVar] = histLimitsY!
            }else {histLimitsX!.yMaxLin = yMaxLin;histLimitsDict[xVar] = histLimitsX!}} // Univariate
        get {return yMaxLin}}
    @objc dynamic var myYMinLog: Double {
        set {yMinLog = newValue
            if graphicSubview!.histogramType == BivariateTag {
                histLimitsY!.xMinLog = yMinLog;histLimitsDict[yVar] = histLimitsY!
            }else {histLimitsX!.yMinLog = yMinLog;histLimitsDict[xVar] = histLimitsX!}} // Univariate
        get {return yMinLog}}
    @objc dynamic var myYMaxLog: Double {
        set {yMaxLog = newValue
            if graphicSubview!.histogramType == BivariateTag {
                histLimitsY!.xMaxLog = yMaxLog;histLimitsDict[yVar] = histLimitsY!
            }else {histLimitsX!.yMaxLog = yMaxLog;histLimitsDict[xVar] = histLimitsX!}} // Univariate
        get {return yMaxLog}}
    @objc dynamic var myYT: Double {
        set {yT = newValue
            histLimitsY!.T = yT;histLimitsY!.logicleT = yT;histLimitsDict[yVar] = histLimitsY!}
        get {return yT}}
    @objc dynamic var myYW: Double {
        set {yW = newValue;histLimitsY!.W = yW;histLimitsY!.logicleW = yW;histLimitsDict[yVar] = histLimitsY!}
        get {return yW}}
    @objc dynamic var myYM: Double {
        set {yM = newValue;histLimitsY!.M = yM;histLimitsY!.logicleM = yM;histLimitsDict[yVar] = histLimitsY!}
        get {return yM}}
    @objc dynamic var myYA: Double {
        set {yA = newValue;histLimitsY!.A = yA;histLimitsY!.logicleA = yA;histLimitsDict[yVar] = histLimitsY!}
        get {return yA}}
    @objc dynamic var myYAutoScale: Bool {
        set {yAutoScale = newValue
             if graphicSubview!.histogramType == UnivariateTag {
                histLimitsX!.yAutoScale = yAutoScale;histLimitsDict[xVar] = histLimitsX!
                if yAutoScale == true {disableAllY()}}}
        get {return yAutoScale}}
    
    override func windowDidLoad() {
        super.windowDidLoad()
    }
    
    override init(window: NSWindow?) {
        super.init(window: window)
    }
    
    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
    }
    
    // MARK: *** Init **********************************************************
    
    
    /// convenience init. Called from GRSVExtRightMouse.showAxesChangePanel(). Invokes the AxesChangePanel for a histogram.
    ///
    /// - Parameters:
    ///   - xVar: x axis vaiate
    ///   - yVar: y axis variate
    ///   - graphicSubview: link to GraphicSubview for the histogram
    ///   - window: window containing the GraphicSubview
    convenience init(xVar: Int, yVar: Int, graphicSubview: GraphicSubview, window: NSWindow) {
        self.init()
        self.graphicSubview = graphicSubview
        self.xVar = xVar
        self.yVar = yVar
        showWindow(nil)
    }
    
    override var windowNibName: NSNib.Name? {
        return "AxesChangePanel"
    } // End of windowNibName
    
    override func awakeFromNib() { // Methods below must be called AFTER nib file is loaded so that iVars such as _xAxisTypeMatrix are instantiated by the nib file and are not nil.
        setCurrentParameters()
    } // End of awakeFromNib
    
    func xAxisButtonList() -> Array<NSButton> {
        return [xLinearRadio, xLogRadio, xLogicleRadio, xHyperlogRadio, xAsinhRadio]
    } // End of xAxisButtonList
    
    func yAxisButtonList() -> Array<NSButton> {
        return [yLinearRadio, yLogRadio, yLogicleRadio, yHyperlogRadio, yAsinhRadio]
    } // End of yAxisButtonList
    
    
    /// setCurrentParameters. Called in awakeFromNib. Initializes the iVars to be observed and changed. First section for both univariate and bivariate.
    func setCurrentParameters() {
        histLimitsX = histLimitsDict[xVar]!
        myXAxisLabel = histLimitsX!.xAxisLabel
        myXAxisType = histLimitsX!.xAxisType
        xAxisRadioState() // Sets x-axis radio button states depending on myXAxisType
        myLogLikeScaleTransformX = histLimitsX!.logLikeScaleTransform
        myXMinLin = histLimitsX!.xMinLin
        myXMaxLin = histLimitsX!.xMaxLin
        myXMinLog = histLimitsX!.xMinLog
        myXMaxLog = histLimitsX!.xMaxLog
        myXT = histLimitsX!.T
        myXW = histLimitsX!.W
        myXM = histLimitsX!.M
        myXA = histLimitsX!.A
        setStateForXVariates()
        if graphicSubview?.histogramType == UnivariateTag { // Univariate y axis
            myYAxisLabel = histLimitsX!.yAxisLabel
            myYAxisType = histLimitsX!.yAxisType
            yAxisRadioState() // Sets y-axis radio button states depending on myYAxisType.
            myYMinLin = histLimitsX!.yMinLin
            myYMaxLin = histLimitsX!.yMaxLin
            myYMinLog = histLimitsX!.yMinLog
            myYMaxLog = histLimitsX!.yMaxLog
            myYAutoScale = histLimitsX!.yAutoScale
            setStateForYVariates()
        } else { // Bivariate Y axis
            histLimitsY = histLimitsDict[yVar]!
            myYAxisLabel = histLimitsY!.xAxisLabel
            myYAxisType = histLimitsY!.xAxisType
            yAxisRadioState()
            myLogLikeScaleTransformY = histLimitsY!.logLikeScaleTransform
            myYMinLin = histLimitsY!.xMinLin
            myYMaxLin = histLimitsY!.xMaxLin
            myYMinLog = histLimitsY!.xMinLog
            myYMaxLog = histLimitsY!.xMaxLog
            myYT = histLimitsY!.T
            myYW = histLimitsY!.W
            myYM = histLimitsY!.M
            myYA = histLimitsY!.A
            myYAutoScale = true
            myYAutoScaleEnabled = false
            setStateForYVariates()
        } // End for Bivariate Y axis
    } // End of setCurrentParameters
    
    
    /// yAutoScaleCheckBoxchanged. Determines whether the univariate y axis is scaled automatically or not.
    ///
    /// - Parameter sender: Autoscale univariate y axis checkbox
    @IBAction func yAutoScaleCheckBoxchanged(_ sender: NSButton) {
        if sender.state == NSControl.StateValue.on { // Checked
            myYAutoScale = true
            myYLinEnabled = false
            myYLogEnabled = false
            updateHistogram()
            updateUnivariateYDisplayLimits()
        }
        else { // unchecked
            myYAutoScale = false
            if myYAxisType == LinearTag {
                myYLinEnabled = true
                myYLogEnabled = false
            }
            else { // LogTag
                myYLogEnabled = true
                myYLinEnabled = false
            }
        }
        print("myYAutoScale: \(myYAutoScale)")
    } // End of yAutoScaleCheckBoxchanged
    
    
    /// ok button pressed to update the histogram and dismiss the AxesChangedPanel
    ///
    /// - Parameter sender: ok NSButton
    @IBAction func ok(_ sender: AnyObject) {
        updateHistogram()
        close()
    } // End @IBAction func ok
    
    
    /// updateHistogram updates the histLimitsDict and regenerates the univariate histogram
    func updateHistogram() {
        if graphicSubview!.histogramType == UnivariateTag {
            histLimitsDict[xVar] = histLimitsX
            graphicSubview!.axesChangedUnivariate() // Generates univariate histogram
        } else {
            histLimitsDict[xVar] = histLimitsX
            histLimitsDict[yVar] = histLimitsY
            graphicSubview!.axesChangedBivariate() // Generates histogram
        }
    } // End of updateHistogram
    
    
    /// updateUnivariateYDisplayLimits updates the appropriate histLimits class object. Called by yAutoScaleCheckBoxchanged
    func updateUnivariateYDisplayLimits() {
        myYMinLin = histLimitsX!.yMinLin
        myYMaxLin = histLimitsX!.yMaxLin
        myYMinLog = histLimitsX!.yMinLog
        myYMaxLog = histLimitsX!.yMaxLog
    }
    
} // End of AxesChangePanel
