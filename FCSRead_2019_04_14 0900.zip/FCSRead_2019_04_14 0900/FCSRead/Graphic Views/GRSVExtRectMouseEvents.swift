//
//  GRSVExtRectMouseEvents.swift GraphicSubviewExtensionRectMouseEvents enables creation of rectangle or elliptical gates on histograms. Rigth click on popup menu then left click to select rectangle or ellipse gate.
//  FCSRead
//
//  Created by Mr. Salzman on 3/27/16.
//  Copyright © 2019 Gary Salzman. All rights reserved.
//

import Cocoa

extension GraphicSubview { // GRSVExtRectMouseEvents
    
    
    /// createRectGateEvent is called from (left) mouseDown for RectGate (rectangle or ellipse) See GRSVExtSupport.mouseDown(...
    ///
    /// - Parameter event: left mouse down event.
    func createRectGateEvent(_ event: NSEvent) { // Called from (left) mouseDown for RectGate (rectangle or ellipse) See GRSVExtSupport.mouseDown(...
        Swift.print("GRSVExtRectMouseEvents.createRectGateEvent")
        var graphicPt = convert(event.locationInWindow, from: nil)
        
        constrainPointToHistogramBox(&graphicPt)
        
        currentGateClass = RectGate.self
        // Instantiate a RectGate
        rectGate = RectGate(frameRect: NSZeroRect, view: self)
        rectGate!.bounds = NSMakeRect(graphicPt.x, graphicPt.y, 0.0, 0.0)
        
        // Set gateType for RectGate
        if currentGateTypeSetting == CreateEllipseGateTag {
            rectGate!.gateType = EllipseGateTag
        }
        else if currentGateTypeSetting == CreateRectangleGateTag {
            rectGate!.gateType = RectangleGateTag
        }
        else {}
        
        // Let the user size the new rectangular gate until left mouseUp.
        var handle = GateLowerRightHandle
        resizeRectGate(&handle, event: event)
        
        // Left mouse up here - finished resizing gate during gate creation.
        Swift.print("rectGate.bounds \(rectGate!.bounds)")
        
        rectGate!.gateCenterForBounds(rectGate!.bounds)
        // Now have rectGate.bounds (nonrotated) and rectGate.gateCenter
        
        // Updates iVars for Gate:myGate with values from rectGate using keyString that identifies the histogram. It is in GRSVExtensionEditGates.swift
        if histogramType == UnivariateTag {
            createUnivariateGateDictionaryEntry() // In GRSVExtEditGates
        } else { // histogramType == BivariateTag
            createBivariateGateDictionaryEntry() // In GRSVExtEditGates
        }
        
        setNeedsDisplay(rectGate!.drawingBounds())
        
    } // End of createRectGateEvent
    
    
    /// rectGateUnderPoint. Point is on a rectGate or ellipseGate selection handle (selectedGateHandle) or on the gate itself(gateContentSelected). Called from GraphicSubview:selectAndTrackMouse...
    ///
    /// - Parameter point: mouse point
    /// - Returns: gateContentSelected (inside gate) and selectedGateHandle (may be GateNoHandle)
    func rectGateUnderPoint(_ point: NSPoint) -> (gateContentSelected: Bool, selectedGateHandle: Int) {
        
        var gateContentSelected = false
        var selectedGateHandle = GateNoHandle
        
        if NSPointInRect(point, rectGate!.drawingBounds()) {
            // Check the gate's selection handles first, because they take precedence when they overlap the gate's contents.
            let handle = rectGate!.handleUnderPoint(point)
            if handle != GateNoHandle { // The user clicked on a handle of the gate.
                selectedGateHandle = handle // Now have valid handle.
            }
                
            else { // Inside drawingBounds but not on a handle
                gateContentSelected = rectGate!.isContentUnderPoint(point)
                if gateContentSelected {
                    // The user clicked on the contents of a gate (ready to drag gate)
                    selectedGateHandle = GateNoHandle
                }
            }
            
        } // End of NSPointInRect(...
        
        return (gateContentSelected, selectedGateHandle)
        
    } // End of gateUnderPoint (for rectGate)
    
    
    /// rotatedEllipseGateUnderPoint. // Point is on a rotatedEllipseGate selection handle (selectedGateHandle) or on the gate itself(gateContentSelected). Called from selectAndTrackEllipseMouse...
    ///
    /// - Parameter point: left mouse point.
    /// - Returns: gateContentSelected (inside gate) and selectedGateHandle (may be GateNoHandle)
    func rotatedEllipseGateUnderPoint(_ point: NSPoint) -> (aRectGate: RectGate, gateContentSelected: Bool, selectedGateHandle: Int) {
        
        var aRectGate = RectGate()
        var gateContentSelected = false
        var selectedGateHandle = GateNoHandle
        
        if NSPointInRect(point, rectGate!.drawingBounds()) {
            // Check the gate's selection handles first, because they take precedence when they overlap the gate's contents.
            let handle = rectGate!.whichHandleOnRotatedEllipseIsUnderPoint(point)
            if handle != GateNoHandle { // The user clicked on a handle of the gate.
                aRectGate = rectGate!
                selectedGateHandle = handle // Now have valid handle.
            }
                
            else { // Inside drawingBounds but not on a handle
                gateContentSelected = rectGate!.isContentUnderPoint(point)
                if gateContentSelected {
                    // The user clicked on the contents of a gate (ready to drag gate)
                    aRectGate = rectGate!
                    selectedGateHandle = GateNoHandle
                }
            }
            
        } // End of NSPointInRect(...
        
        return (aRectGate, gateContentSelected, selectedGateHandle)
        
    } // End of rotatedEllipseGateUnderPoint
    
    
    /// resizeRectGate. Called from mouseDown for rectGate after (left) mouseDown to resize gate during gate creation and on (left) mouseDown during gate resizing.
    ///
    /// - Parameters:
    ///   - handle: handle for rectGate
    ///   - event: left mouseDown event
    func resizeRectGate(_ handle: inout Int, event: NSEvent) {
        
        var myEvent = event
        var handleLocation = NSZeroPoint
        
        while myEvent.type != NSEvent.EventType.leftMouseUp {
            myEvent = (window?.nextEvent(matching: NSEvent.EventTypeMask(rawValue: UInt64(Int(NSEvent.EventTypeMask.leftMouseUp.union(.leftMouseDragged).rawValue)))))!
            autoscroll(with: event)
            handleLocation = convert(myEvent.locationInWindow, from: nil)
            // Constrain handleLocation to prevent failures with logicle
            // _lowerLeft and _upperRight NSPoints are corners of histogramBox.
            // These values are set in HistogramGraphic.prepareDrawingContents.
            if handleLocation.x < histogramGraphic!.lowerLeft.x {
                handleLocation.x = histogramGraphic!.lowerLeft.x
            }
            if handleLocation.y < histogramGraphic!.lowerLeft.y {
                handleLocation.y = histogramGraphic!.lowerLeft.y
            }
            if handleLocation.x > histogramGraphic!.upperRight.x {
                handleLocation.x = histogramGraphic!.upperRight.x
            }
            if handleLocation.y > histogramGraphic!.upperRight.y {
                handleLocation.y = histogramGraphic!.upperRight.y
            }
            
            if rectGate?.rotationAngle == 0.0 {
                rectGate?.resizeByMovingHandle(&handle, point: &handleLocation)
            }
            else { // Rotated ellipse
                rectGate?.resizeByMovingRotatedEllipseHandle(&handle, point: &handleLocation)
            }
            
            setNeedsDisplay(histogramGraphic!.innerBox)
            
        } // End of while event.type != NSEventType.LeftMouseUp
        
    } // End of resizeGate
    
    
    /// selectAndTrackRectMouseWithEvent. Called from mouseDown: (left mouse) for rectGate, which as been created with rightMouseDown - createRectangleGate.
    ///
    /// - Parameter event: left mouseDown event
    func selectAndTrackRectMouseWithEvent(_ event: NSEvent) {
        
        var gateContentsSelected = false
        var selectedGateHandle = GateNoHandle
        
        if rectGate == nil { // Can't edit if there is no gate.
            return
        }
        
        // Has the user clicked on a rectGate?
        let mouseLocation = convert(event.locationInWindow, from: nil)
        
        (gateContentsSelected, selectedGateHandle) = rectGateUnderPoint(mouseLocation)
        
        if rectGate!.bounds != NSZeroRect { // rectGate is valid
            // mouse is somewhere over the gate. Clicking on a gate handle takes precedence.
            if selectedGateHandle != GateNoHandle {
                // mouse is over a handle. The user clicked on a gate's handle. Let the user drag it around.
                resizeRectGate(&selectedGateHandle, event: event)
            }
                
            else if gateContentsSelected == true { // The user clicked on a rectGate's contents. Let the user move the selected gate.
                moveRectGateWithEvent(event)
            }
                
            else {}
            
            editGateDictionaryEntry()
            
        } // End of if aRectGate.bounds != NSZeroRect (valid rectGate)
        
    } // End of selectAndTrackMouseWithEvent
    
    
    /// selectAndTrackEllipseMouseWithEvent. Called from mouseDown: (left mouse) to track changes in rotated ellipse.
    ///
    /// - Parameter event: left mouseDown event
    func selectAndTrackEllipseMouseWithEvent(_ event: NSEvent) {
        // Called from mouseDown: (left mouse).
        
        var aRectGate = RectGate()
        var gateContentsSelected = false
        var selectedGateHandle = GateNoHandle
        
        if rectGate == nil { // Can't edit if there is no gate.
            return
        }
        
        // Has the user clicked on a rectGate?
        let mouseLocation = convert(event.locationInWindow, from: nil)
        
        (aRectGate, gateContentsSelected, selectedGateHandle) = rotatedEllipseGateUnderPoint(mouseLocation)
        if aRectGate.bounds != NSZeroRect { // aRectGate is valid
            // mouse is somewhere over the gate. Clicking on a gate handle takes precedence.
            if selectedGateHandle != GateNoHandle {
                // mouse is over a handle. The user clicked on a gate's handle. Let the user drag it around.
                resizeRectGate(&selectedGateHandle, event: event)
            }
                
            else if gateContentsSelected == true { // The user clicked on a gate's contents. Let the user move the selected gate.
                moveRotatedEllipseGateWithEvent(event)
            }
                
            else {}
            
            editGateDictionaryEntry()
            
        } // End of if aRectGate.bounds != NSZeroRect (valid rectGate)
        
        
    } // End of selectAndTrackEllipseMouseWithEvent
    
    
    /// moveRectGateWithEvent. Called from selectAndTrackMouseWithEvent to move a rectGate.
    ///
    /// - Parameter event: left mouseDown event
    func moveRectGateWithEvent(_ event: NSEvent) {
        var lastPoint = NSZeroPoint
        var curPoint = NSZeroPoint
        var isMoving = false
        var didMove = false
        var myEvent = event
        
        lastPoint = convert(event.locationInWindow, from: nil)
        
        while myEvent.type != NSEvent.EventType.leftMouseUp {
            myEvent = (window!.nextEvent(matching: NSEvent.EventTypeMask(rawValue: UInt64(Int(NSEvent.EventTypeMask.leftMouseUp.union(.leftMouseDragged).rawValue)))))!
            autoscroll(with: myEvent)
            curPoint = convert(myEvent.locationInWindow, from: nil)
            if (/*!isMoving &&*/ ((abs(curPoint.x - lastPoint.x) >= 2.0) || (abs(curPoint.y - lastPoint.y) >= 2.0))) {
                isMoving = true
                isHidingHandles = true
                
            } // End of if !isMoving...
            
            if isMoving == true {
                if !NSEqualPoints(lastPoint, curPoint) {
                    var tempX = curPoint.x - lastPoint.x
                    var tempY = curPoint.y - lastPoint.y
                    rectGate!.translateRect(&tempX, deltaY: &tempY)
                    didMove = true
                }
                
                lastPoint = curPoint
                setNeedsDisplay(innerBoxDrawingBounds())
                
            } // End of if isMoving == true
            
        } // End of while loop. LeftMouseUp at this point
        
        if didMove == true {
            isHidingHandles = false // Show handles
        }
        
        setNeedsDisplay(innerBoxDrawingBounds())
        
    } // End of moveRectGateWithEvent
    
    
    /// moveRotatedEllipseGateWithEvent. Called from selectAndTrackEllipseMouseWithEvent to track movement of rotatedEllipse.
    ///
    /// - Parameter event: left mouseDown event
    func moveRotatedEllipseGateWithEvent(_ event: NSEvent) {
        
        var lastPoint = NSZeroPoint
        var curPoint = NSZeroPoint
        var isMoving = false
        var myEvent = event
        
        lastPoint = convert(event.locationInWindow, from: nil)
        
        while myEvent.type != NSEvent.EventType.leftMouseUp {
            myEvent = (window?.nextEvent(matching: NSEvent.EventTypeMask(rawValue: UInt64(Int(NSEvent.EventTypeMask.leftMouseUp.union(.leftMouseDragged).rawValue)))))!
            autoscroll(with: myEvent)
            curPoint = convert(myEvent.locationInWindow, from: nil)
            let deltaPoint = NSMakePoint(curPoint.x - lastPoint.x, curPoint.y - lastPoint.y)
            if !isMoving && (abs(deltaPoint.x) >= 2.0) || (abs(deltaPoint.y) >= 2.0) {
                isMoving = true
                isHidingHandles = true
                
            } // End of if !isMoving...
            
            if isMoving {
                if !NSEqualPoints(lastPoint, curPoint) {
                    rectGate?.translateRotatedEllipseGivenDeltaPoint(deltaPoint)
                }
                
                lastPoint = curPoint
                setNeedsDisplay(innerBoxDrawingBounds())
                
            } // End of if isMoving == true
            
        } // End of while loop. LeftMouseUp at this point
        
        if isMoving == true {
            isHidingHandles = false
        }
        
        setNeedsDisplay(innerBoxDrawingBounds())
        
    } // End of moveRotatedEllipseGateWithEvent

} // End of GRSVExtRectMouseEvents
