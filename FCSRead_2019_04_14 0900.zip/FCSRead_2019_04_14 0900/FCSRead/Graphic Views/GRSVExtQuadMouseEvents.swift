//
//  GRSVExtQuadMouseEvents.swift enables setting and editing quadrant gates. Partially works ******************************
//  FCSRead
//
//  Created by Mr. Salzman on 3/27/16.
//  Copyright © 2019 Gary Salzman. All rights reserved.
//

import Cocoa

extension GraphicSubview { // GRSVExtQuadMouseEvents
    
    
    /// createQuadGateEvent is called from popup menu (left) mouseDown "Create Quadrant Gate Point and Show Stats"
    ///
    /// - Parameter event: left mouseDown after right click popup menu.
    func createQuadGateEvent(_ event: NSEvent) { // Creates quadrant point and quadRectArray. In GRSVExtQuadMouseEvents.
        
        var graphicPt = convert(event.locationInWindow, from: nil)
        var rect = NSZeroRect
        
        constrainPointToHistogramBox(&graphicPt)
        
        // Invoked by mouseDown. Create QuadrantGate for QuadGate class or add quadPoint, update quadPtDict and updateGateDictionary
        if quadGate == nil {
            // No quadGate exists, so create a new quadGate object and add the first quadPoint (right click:"Create quadrant gate point").
            currentGateClass = QuadGate.self
            quadGate = QuadGate(frameRect: NSZeroRect, view: self)
            quadGate!.bounds = NSMakeRect(histogramGraphic!.xOffset, histogramGraphic!.yOffset, histogramGraphic!.innerBoxWidth, histogramGraphic!.innerBoxHeight)
            quadGate!.gateType = QuadrantGateTag
            quadGate!.quadPtIndex = 0
            
            // Reposition the new quadPoint until mouse up.
            repositionQuadGateUsingHandle(quadGate!.quadPtHandle, event: event)
            let quadPtKey = NSString.localizedStringWithFormat("P%i", quadGate!.quadPtIndex) as String
            quadGate!.xLocation = roundCGFloat(graphicPt.x)
            quadGate!.yLocation = roundCGFloat(graphicPt.y)
            quadGate!.quadPoint = QuadPoint(aPoint: NSMakePoint(quadGate!.xLocation, quadGate!.yLocation), handle: quadGate!.quadPtHandle, key: quadPtKey)
            quadGate!.quadPtDict[quadPtKey] = quadGate!.quadPoint
            quadGate!.quadPtArray = [QuadPoint](quadGate!.quadPtDict.values)
            createBivariateGateDictionaryEntry() // In GRSVExtEditGates.swift
            NSCursor.arrow.set()
           print("graphicPt.x: \(graphicPt.x) quadGate!.xLocation: \(quadGate!.xLocation) graphicPt.y: \(graphicPt.y) quadGate!.yLocation: \(quadGate!.yLocation)")
            
            // Create the four quadRects using quadGate xLocation and yLocation and innerBox boundaries.
            rect = NSRect(x: quadGate!.xOffset, y: quadGate!.yOffset, width: (quadGate!.xLocation - quadGate!.xOffset), height: (quadGate!.yLocation - quadGate!.yOffset))
            quadGate!.quadRect = QuadRect(r: rect, key: "LL")
            quadGate!.quadRectArray.append(quadGate!.quadRect)
            
            rect = NSRect(x: quadGate!.xLocation, y: quadGate!.yOffset, width: (quadGate!.innerBoxWidth + quadGate!.xOffset - quadGate!.xLocation), height: (quadGate!.yLocation - quadGate!.yOffset))
            quadGate!.quadRect = QuadRect(r: rect, key: "LR")
            quadGate!.quadRectArray.append(quadGate!.quadRect)
            
            rect = NSRect(x: quadGate!.xOffset, y: quadGate!.yLocation, width: (quadGate!.xLocation - quadGate!.xOffset), height: (quadGate!.innerBoxHeight + quadGate!.yOffset - quadGate!.yLocation))
            quadGate!.quadRect = QuadRect(r: rect, key: "UL")
            quadGate!.quadRectArray.append(quadGate!.quadRect)
            
            rect = NSRect(x: quadGate!.xLocation, y: quadGate!.yLocation, width: (quadGate!.innerBoxWidth + quadGate!.xOffset - quadGate!.xLocation), height: (quadGate!.innerBoxHeight + quadGate!.yOffset - quadGate!.yLocation))
            quadGate!.quadRect = QuadRect(r: rect, key: "UR")
            quadGate!.quadRectArray.append(quadGate!.quadRect)
            
            print("quadGate!.quadRectArray: \(quadGate!.quadRectArray)")
            
            createBivariateGateDictionaryEntry()
            
        } // End of if quadGate == nil
            
        else { // Add another quadPoint (right click:"Create quadrant gate point") This has been disabled ****
            // quadGate exists, add quadPoint, update quadPtDict and updateGateDictionary
            NSCursor.arrow.set()
            setNeedsDisplay(innerBoxDrawingBounds())
            return
        } // End of add another quadPoint
    } // End of createQuadGateEvent. End of creation/addition and repositioning of quadPoints in the QuadGate class object.
    
    
    /// quadGateUnderPoint
    ///
    /// - Parameter point: mouse point
    /// - Returns: gateContentSelected and selectedGateHandle
    func quadGateUnderPoint(_ point: NSPoint) -> (gateContentSelected: Bool, selectedGateHandle: Int) {
        // Point is on a quadGate selection handle (selectedGateHandle) or on the gate itself(gateContentSelected). Called from selectAndTrackQuadMouse...
        
        var gateContentSelected = false
        var selectedGateHandle = GateNoHandle
        
        if NSPointInRect(point, quadGate!.drawingBounds()) {
            // Check the gate's selection handles first, because they take precedence when they overlap the gate's contents.
            let handle = quadGate!.handleUnderPoint(point)
            if handle != GateNoHandle { // The user clicked on a handle of the gate.
                selectedGateHandle = handle // Now have valid handle.
            }
                
            else { // Inside drawingBounds but not on a handle
                gateContentSelected = quadGate!.contentsUnderPoint(point)
                if gateContentSelected {
                    // The user clicked on the contents of a gate (ready to drag gate)
                    selectedGateHandle = GateNoHandle
                }
            }
            
        } // End of NSPointInRect(...
        
        return (gateContentSelected, selectedGateHandle)
        
    } // End of quadGateUnderPoint
    
    
    /// repositionQuadGateUsingHandle repositions handle based on left mouseDown event. Called from selectAndTrackQuadMouseWithEvent
    ///
    /// - Parameters:
    ///   - handle: Int describing handle for the quadPoint
    ///   - event: left mouseDown event
    func repositionQuadGateUsingHandle(_ handle: Int, event: NSEvent) {
        var myHandle = handle
        var myEvent = event
        while myEvent.type != NSEvent.EventType.leftMouseUp {
            myEvent = (window?.nextEvent(matching: NSEvent.EventTypeMask(rawValue: UInt64(Int(NSEvent.EventTypeMask.leftMouseUp.union(.leftMouseDragged).rawValue)))))!
            autoscroll(with: myEvent)
            let handleLocation = convert(myEvent.locationInWindow, from: nil)
            myHandle = quadGate!.repositionByMovingHandle(myHandle, point: handleLocation)
            quadGate!.xLocation = handleLocation.x
            quadGate!.yLocation = handleLocation.y
            setNeedsDisplay(innerBoxDrawingBounds())
        } // Left mouse is up. End of while
        
    } // End of repositionGate for quadGate
    
    
    /// selectAndTrackQuadMouseWithEvent
    ///
    /// - Parameter event: left mouseDown event on "Move or Resize Gate" right click menu
    func selectAndTrackQuadMouseWithEvent(_ event: NSEvent) {
        print("selectAndTrackQuadMouseWithEvent")
        // Called from mouseDown: (left mouse). This version is for quadGate only.
        
        var gateContentsSelected = false
        var selectedGateHandle = GateNoHandle
        var modifyingExistingSelection = false
        
        if quadGate == nil { // Can't edit if there is no gate.
            return
        }
        
        // Are we changing the existing selection instead of setting a new one? Shift key down sets to true
        let modifierFlag = event.modifierFlags.rawValue
        let shiftKeyMask = NSEvent.ModifierFlags.shift.rawValue
        let shiftKey = modifierFlag & shiftKeyMask
        if shiftKey > 0 {
            modifyingExistingSelection = true
        }
        else {
            modifyingExistingSelection = false
        }
        
        // Has the user clicked on a quadGate?
        let mouseLocation = convert(event.locationInWindow, from: nil)
        
        (gateContentsSelected, selectedGateHandle) = quadGateUnderPoint(mouseLocation)
        
        if gateContentsSelected == true || selectedGateHandle != GateNoHandle { // aQuadGate is valid
            // mouse is somewhere over the gate. Clicking on a gate handle takes precedence.
            if selectedGateHandle != GateNoHandle {
                // mouse is over a handle. The user clicked on a gate's handle. Let the user drag it around.
                repositionQuadGateUsingHandle(selectedGateHandle, event: event)
                editGateDictionaryEntry()
            } // End of clicked on quadGate handle
                
            else { // User clicked on gate's contents.
                if modifyingExistingSelection == true {
                    if gateContentsSelected == true {
                        gateContentsSelected = false // Remove gate from selection.
                    }
                    else {
                        gateContentsSelected = true // Add gate to selection.
                    }
                } // End of modifyingExistingSelection == true
                    
                else { // modifyingExistingSelection == false
                    if gateContentsSelected == false {
                        gateContentsSelected = true
                    }
                }
                
                if gateContentsSelected == true { // User can move all selected gates.
                    editGateDictionaryEntry()
                }
                
            } // End of user clicked on gate's contents.
            
        } // End of if aQuadGate.bounds != NSZeroRect (valid quadGate)
        
     } // End of selectAndTrackQuadMouseWithEvent
    
    
    /// roundCGFloat rounds a CGFloat to an integer and returns a CGFloat
    ///
    /// - Parameter inCGFloat: CFFloat number
    /// - Returns: a CGFloat number that is now the nearest integer
    func roundCGFloat(_ inCGFloat: CGFloat) -> CGFloat {
        var outCGFloat = CGFloat(0.0)
        var nearestInt = 0
        nearestInt = Int(round(Double(inCGFloat)))
        outCGFloat = CGFloat(nearestInt)
        return outCGFloat
    }
    
} // End of GRSVExtQuadMouseEvents
