//
//  MatrixOps.swift constains a set of funcs for matrix manipulation
//  CentroidFCSGenerator and FCSRead
//
//  Created by Mr. Salzman on 2/20/17.
//  Copyright © 2019 Gary Salzman. All rights reserved.
//

import Foundation


/// rowsColsForMatrix returns the number of rows and columns in a matrix
///
/// - Parameter mat: input matrix
/// - Returns: (number of rows, number of columns)
func rowsColsForMatrix(_ mat: [[Double]]) -> (Int, Int) {
    let matRows = mat.count
    if matRows < 1 {
        return (0, 0)
    }
    let tempRow: [Double] = mat[0] // first row of mat
    let matCols = tempRow.count // number of columns in mat
    
    return (matRows, matCols)
    
} // End of rowsColsForMatrix


/// transposeOfMatrix transposes an input matrix and returns the transposed matrix
///
/// - Parameter mat: input matrix
/// - Returns: transposed matrix
func transposeOfMatrix(_ mat: [[Double]]) -> [[Double]] {
    
    // Find number of rows and columns of mat
    let matRows = mat.count
    let tempRow: [Double] = mat[0] // first row of mat
    let matCols = tempRow.count // number of columns in mat
    
    var transpose = [[Double]]()
    let transposeRows = matCols
    let transposeCols = matRows
    for _ in 0..<transposeRows {
        transpose.append(Array(repeating: 0.0, count: transposeCols))
    }
    
    for r in 0..<transposeRows {
        for c in 0..<transposeCols {
            transpose[r][c] = mat[c][r]
        }
    }
    
    return transpose
    
} // End of transposeOfMatrix


/// transposeInPlaceForMatrix transposes a matrix in place (inout)
///
/// - Parameter mat: input and output matrix
func transposeInPlaceForMatrix(_ mat: inout [[Double]]) { // square matrix only
    mat = transposeOfMatrix(mat)
    
} // End of transposeInPlaceForMatrix


/// determinantForMatrix calculates and returns the determinant of a matrix. Called by inverseForMatrix. Adapted from Inverse of a square matrix by Paul Bourke(2002). https://www.cs.rochester.edu/~brown/Crypto/assts/projects/adj.html
///
/// - Parameters:
///   - a: input matrix
///   - rows: number of rows in the input matrix
/// - Returns: the determinant of the matrix
func determinantForMatrix(_ a: [[Double]], rows: Int) -> Double { // Called by inverseForMatrix. Adapted from Inverse of a square matrix by Paul Bourke(2002). https://www.cs.rochester.edu/~brown/Crypto/assts/projects/adj.html
    print("MatrixOps.determinantForMatrix rows: \(rows)")
    
    var j2 = 0
    var m = [[Double]]()
    var det = 0.0
    
    if rows == 1 {
        det = a[0][0]
    } else if rows == 2 {
        det = a[0][0] * a[1][1] - a[1][0] * a[0][1]
    } else {
        det = 0.0
        for j1 in 0..<rows {
            for _ in 0..<(rows - 1) {
                m.append(Array(repeating: 0.0, count: (rows - 1)))
            }
            for i in 1..<rows {
                j2 = 0
                for j in 0..<rows {
                    if j == j1 {
                        continue
                    }
                    m[i - 1][j2] = a[i][j]
                    j2 += 1
                } // End of loop over j
                
            } // End of loop over i
            det += pow(-1.0, (Double(j1) + 2.0)) * a[0][j1] * determinantForMatrix(m, rows: (rows - 1))
        } // End of loop over j1
        
    } // End of else
    
    return det
    
} // End of determinantForMatrix


/// inverseForMatrix. Calculates the inverse of a square matrix. Adapted from Inverse of a square matrix by Paul Bourke(2002). https://www.cs.rochester.edu/~brown/Crypto/assts/projects/adj.html. Used by inverseUsingAdjointForMatrix. a is the input square matrix and b is the output inverse matrix. Uses determinantForMatrix() and transposeInPlaceForMatrix().
///
/// - Parameters:
///   - a: input matrix
///   - b: inverse of input matrix
func inverseForMatrix(_ a: [[Double]], b: inout [[Double]]) { // Adapted from Inverse of a square matrix by Paul Bourke(2002). https://www.cs.rochester.edu/~brown/Crypto/assts/projects/adj.html. Used by inverseUsingAdjointForMatrix. a is the input square matrix and b is the output inverse matrix. Uses determinantForMatrix() and transposeInPlaceForMatrix().
    
    var i1 = 0
    var j1 = 0
    var det = 0.0
    let (aRows, _) = rowsColsForMatrix(a)
    let detA = determinantForMatrix(a, rows: aRows) // In MatrixOps.swift
    print("inverseForMatrix")
    var c = [[Double]]() // minor submatrix
    for _ in 0..<(aRows - 1){
        c.append(Array(repeating: 0.0, count: (aRows - 1)))
    }
    for j in 0..<aRows {
        for i in 0..<aRows {
            i1 = 0
            for ii in 0..<aRows {
                if ii != i {
                    j1 = 0
                    for jj in 0..<aRows {
                        if jj != j {
                            c[i1][j1] = a[ii][jj]
                            j1 += 1
                        }
                    } // End of loop over jj
                    i1 += 1
                }
            }
//            print("c: \(c)")
            det = determinantForMatrix(c, rows: (aRows - 1))
//            print("det for c: \(det)")
            b[i][j] = pow(-1.0, Double(i + j + 2)) * det / detA
            
        } // End of loop over i
        
    } // End of loop over j
    
//    print("b, cofactor: \(b)")
    
    transposeInPlaceForMatrix(&b) // In MatrixOps.swift
    
//    print("b transpose: \(b)")
    
} // End of inverseForMatrix


/// inverseUsingAdjointForMatrix calculates the inverse of a square matrix using adjoints.
///
/// - Parameter a: input matrix
/// - Returns: inverse of the input matrix
func inverseUsingAdjointForMatrix(_ a: [[Double]]) -> [[Double]] { // In MatrixOps.swift
    
    var aRows = 0
    (aRows, _) = rowsColsForMatrix(a)
    print("inverseUsingAdjointForMatrix a: \(a) aRows: \(aRows)")
    var b = [[Double]]() // inverse of a
    for _ in 0..<aRows {
        b.append(Array(repeating: 0.0, count: aRows))
    }
    
    inverseForMatrix(a, b: &b)
    
    return b
    
} // End of inverseUsingAdjointForMatrix


/// multiplyForMatrices multiplies two matrices and returns the result matrix
///
/// - Parameters:
///   - aa: first input matrix
///   - bb: second input matrix
/// - Returns: result matrix
func multiplyForMatrices(_ aa: [[Double]], bb: [[Double]]) -> [[Double]] {
    // Find number of rows and columns of aa
    let (aaRows, aaCols) = rowsColsForMatrix(aa)
    let (bbRows, bbCols) = rowsColsForMatrix(bb)
    
    if bbRows != aaCols {
        print("#rows of bb not equal to #cols of aa - failed")
        exit(-1)
    }
    
    var cc = [[Double]]() // aaRows x bbCols
    for _ in 0..<aaRows {
        cc.append(Array(repeating: 0.0, count: bbCols))
    }
    
    for i in 0..<aaRows {
        for j in 0..<bbCols {
            for k in 0..<aaCols {
                cc[i][j] += aa[i][k] * bb[k][j]
            }
        }
    }
    
    return cc
    
} // End of multiplyForMatrices


class CholDecomp { // In MatrixOps.swift. Adapted from Numerical Recipes 3, p. 100. Performs Cholesky Decomposition. Instantiated by class NormalDistributions. Input is covariance matrix a. Output is a lower triangular matrix, aL, which is used internally by aMultiply.
    
    var a = [[Double]]() // Input matrix
    var aL = [[Double]]() // Cholesky decomposition matrix.
    var rows = 0
    var cols = 0
    
    init() {}
    
    
    /// convenience init initializes CholDecomp and performs the decomposition of the matrix
    ///
    /// - Parameter aa: input matrix
    convenience init(_ aa: inout [[Double]]) {
        self.init()
        a = aa
        (rows, cols) = rowsColsForMatrix(a)
        guard cols == rows else {
            print("CholDecomp: cols != rows -> fail")
            exit(-1)
        }
        for _ in 0..<rows {
            aL.append(Array(repeating:0.0, count: cols))
        }
        cholD() // Do decomposition
        print("\nCholesky decomposition matrix aL:")
        for i in 0..<rows {
            print("\(aL[i])")
        }
        
    } // End of convenience init
    
    
    /// cholD. Performs Cholesky decomposition for covariance matrix (populates aL).
    func cholD() {
        var sum = 0.0
        
        for j in 0..<rows {
            for i in j..<rows {
                if i == j {
                    sum = 0.0
                    for k in 0..<i {
                        sum += aL[i][k] * aL[j][k]
                    }
                    aL[i][j] = a[i][i] - sum
                    guard aL[i][j] > 0.0 else {
                        print("CholDecomp.cholD failed, matrix not positive-definite. aL[i][j]: \(aL[i][j])")
                        exit(-1)
                    }
                    aL[i][j] = sqrt(a[i][i] - sum)
                } else { // i != j
                    sum = 0.0
                    for k in 0..<j {
                        sum += aL[i][k] * aL[j][k]
                    }
                    aL[i][j] = (a[i][j] - sum) / aL[j][j]
                } // End for i != j
                
            } // End of loop over i
            
        } // End of loop over j
        
    } // End of func cholD
    
    
    /// aMultiply compute a * y = b, where y and b are vectors and a is a matrix.
    ///
    /// - Parameters:
    ///   - y: input vector
    ///   - b: output vector
    /// - Returns: true if successful
    func aMultiply(y : inout [Double], b: inout [Double]) -> Bool {
        if b.count != rows || y.count != rows {
            print("bad lengths in CholDecomp.aMultiply")
            return false
        }
        for i in 0..<rows {
            b[i] = 0.0
            for j in 0...i {
                b[i] += aL[i][j] * y[j] // aL is the Cholesky decomposition of the matrix a. a and aL are iVars in CholDecomp
            }
        }
        
        return true
        
    } // End of func amultiply
    
} // End of class CholDecomp


class Covariance { // In MatrixOps.swift. Computes covariance matrix from event matrix. Used by NormalDistributions.
    var events = [[Double]]() // events matrix
    var event = [Double]() // one event
    var cov = [[Double]]()
    var total = 0 // rows for events matrix
    var covRows = 0
    var cols = 0 // for both cov and events
    
    init() {}
    
    
    /// convenience init initializes an instance of the Covariance class
    ///
    /// - Parameters:
    ///   - evs: evs is the events matrix with rows = total number of events and cols = number of physical variates.
    ///   - takeLog: takeLog is always false for normal distributions. takeLog default is false.
    convenience init(_ evs: [[Double]], takeLog: Bool = false) {
        self.init()
        events = evs
        (total, cols) = rowsColsForMatrix(events)
        covRows = cols
        for _ in 0..<covRows {
            cov.append(Array(repeating: 0.0, count: cols))
        }
        event = Array(repeating: 0.0, count: cols) // One event
        if takeLog == true { // Take log of input events matrix to convert lognormal data to normal data.
            for i in 0..<total { // Take log of events to calculate the output covariance matrix and, hence, rho, the correlation coefficient matrix.
                for j in 0..<cols {
                    events[i][j] = log(events[i][j])
                }
            }
        }
        
    } // End of convenience init
    
    
    /// covMatrix is the covariance matrix calculated from events matrix.
    func covMatrix() { //
        var mn = [Double]()
        mn = Array(repeating: 0.0, count: cols)
        var sumDevs = [[Double]]()
        for _ in 0..<covRows {
            sumDevs.append(Array(repeating: 0.0, count: cols))
        }
        
        (mn, _) = means_sds() // means and standard deviations
        
        for evNo in 0..<total {
            event = events[evNo]
            for i in 0..<covRows {
                for j in 0...i {
                    sumDevs[i][j] += (event[i] - mn[i]) * (event[j] - mn[j])
                } // End of loop over j
            } // End of loop over i
        } // End of loop over EvNo (event number)
        
        for i in 0..<covRows {
            for j in 0...i {
                cov[i][j] = sumDevs[i][j] / Double(total - 1)
                if j != i {
                    cov[j][i] = cov[i][j]
                }
            }
        }
        
    } // End of covMatrix
    
    
    /// means_sds calculates means and standard deviations from the events matrix. Returns ([means], [standard deviations])
    ///
    /// - Returns: ([means], [standard deviations])
    func means_sds() -> ([Double], [Double]) {
        var mn = [Double]()
        mn = Array(repeating: 0.0, count: cols)
        var sums = [Double]()
        sums = Array(repeating: 0.0, count: cols)
        for j in 0..<cols {
            for i in 0..<total {
                sums[j] += events[i][j]
            }
            mn[j] = sums[j] / Double(total)
        }
        
        var deviate = 0.0
        var sumsSD2 = [Double]()
        sumsSD2 = Array(repeating:0.0, count: cols)
        var sd = [Double]()
        sd = Array(repeating:0.0, count:cols)
        for j in 0..<cols {
            for i in 0..<total {
                deviate = (events[i][j] - mn[j])
                sumsSD2[j] += deviate * deviate
            }
            sd[j] = sqrt(sumsSD2[j] / Double(total - 1))
        }
        
        return (mn, sd)
        
    } // End of mean_sds
    
    
    /// mus_sigmas calculates vectors of location parameters (µ) and scale parameters (Greek sigma) for lognormal distribution.
    ///
    /// - Returns: ([location parameters], [scale parameters])
    func mus_sigmas() -> ([Double], [Double]) {
        var mu1 = Array(repeating: 0.0, count: cols) // Calculated mean for lognormal
        var sigma1 = Array(repeating: 0.0, count: cols) // Calculated sigma for lognormal
        var sum = Array(repeating: 0.0, count: cols)
        for i in 0..<total {
            for j in 0..<cols {
                sum[j] += log(events[i][j])
            }
        }
        for i in 0..<cols {
            mu1[i] = sum[i] / Double(total)
        }
        var diff = 0.0
        var sumDiff2 = Array(repeating: 0.0, count: cols)
        for i in 0..<total {
            for j in 0..<cols {
                diff = log(events[i][j]) - mu1[j]
                sumDiff2[j] += diff * diff
            }
        }
        for j in 0..<cols {
            sigma1[j] = sqrt(sumDiff2[j] / Double(total - 1))
        }
        
        return (mu1, sigma1)
        
    } // End of mus_sigmas
    
} // End of class Covariance


/// gaussj is Gauss-Jordan elimination. Adapted from Numerical Recipes 3, p. 44. Input matrix a[0,n-1][0,n-1], b[0,m-1][1] right hand side vector. Output: a is matrix inverse and b is solution vector.
///
/// - Parameters:
///   - a: Input matrix a[0,n-1][0,n-1]
///   - b: b[0,m-1][1] right hand side vector
func gaussj(_ a : inout [[Double]], b : inout [[Double]]) {
    
    var iCol = 0
    var iRow = 0
    let n = a.count // number of rows
    let bRow: [Double] = b[0]
    let m = bRow.count // number of columns
    var big = 0.0
    var dum = 0.0
    var pivInv = 0.0
    var indxc = Array(repeating: 0, count: n)
    var indxr = Array(repeating: 0, count: n)
    var ipiv = Array(repeating: 0, count: n)
    
    for i in 0..<n {
        big = 0.0
        for j in 0..<n {
            if ipiv[j] != 1 {
                for k in 0..<n {
                    if ipiv[k] == 0 {
                        if fabs(a[j][k]) >= big {
                            big = fabs(a[j][k])
                            iRow = j
                            iCol = k
                        } // End for fabs(...
                    } // End for if ipiv[k] == 0
                } // End of loop over k
            } // End of if ipiv[j] != 1
        } // End of loop over j
        
        ipiv[iCol] += 1
        if iRow != iCol {
            for l in 0..<n {
                (a[iRow][l], a[iCol][l]) = exchange(x: a[iRow][l], y: a[iCol][l])
            }
            for l in 0..<m {
                (b[iRow][l], b[iCol][l]) = exchange(x: b[iRow][l], y: b[iCol][l])
            }
        } // End of if iRow != iCol
        
        indxr[i] = iRow
        indxc[i] = iCol
        guard a[iCol][iCol] != 0.0 else {
            print("guassj singular matrix - exiting")
            exit(-1)
        }
        pivInv = 1.0 / a[iCol][iCol]
        a[iCol][iCol] = 1.0
        for l in 0..<n {
            a[iCol][l] *= pivInv
        }
        for l in 0..<m {
            b[iCol][l] *= pivInv
        }
        for ll in 0..<n {
            if ll != iCol {
                dum = a[ll][iCol]
                a[ll][iCol] = 0.0
                for l in 0..<n {
                    a[ll][l] -= a[iCol][l] * dum
                }
                for l in 0..<m {
                    b[ll][l] -= b[iCol][l] * dum
                }
            } // End of if ll != iCol
        } // End of loop over ll
    } // End of loop over i
    for l in stride(from: (n - 1), through: 0, by: -1) { // was to:
        if indxr[l] != indxc[l] {
            for k in 0..<n {
                a[k].swapAt(indxr[l], indxc[l])
            } // End of loop over k
        } // End of if indxr[l] != indxc[l]
    } // End of descending loop over l
} // End of gaussj


/// exchange exchanges two Doubles
///
/// - Parameters:
///   - x: input x value
///   - y: input y value
/// - Returns: (y, x)
func exchange(x: Double, y:Double) -> (Double, Double) {
    let yy = x
    let xx = y
    return (xx, yy)
    
} // End of exchange


/// gaussj0 performs Gauss-Jordan elimination in place.
///
/// - Parameter a: input and output matrix for Gauss-Jordan elimination
func gaussj0(_ a : inout [[Double]]) { // matrix inverse in place. b is dummy matrix with zero cols.
    var b = [[Double]]()
    for _ in 0..<a.count {
        b.append(Array(repeating: 0.0, count: 0))
    }
    gaussj(&a, b: &b)
    
} // End of gaussj0

// End of MatrixOps.swift
