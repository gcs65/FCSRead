//
//  HistLimits.swift. This object is used to access the histLimitsDict in Document. The histLimitsDict stores already calculated histogram limits so that we can avoid recalculating variables that are already available. Initialized in MainViewController with placeholder data.
//  FCSRead
//
//  Created by Mr. Salzman on 11/30/15.
//  Copyright © 2019 Gary Salzman. All rights reserved.
//

import Cocoa

public class HistLimits: NSObject, NSCopying, NSMutableCopying {
    
    var xVariate = 0 // xVariate must be present.
    var xAxisLabel = UnknownTag
    var xAxisType = UnknownTag // one of {LinearTag, LogTag, LogicleTag, AsinhTag, HyperlogTag, UnknownTag}
    var xMinLin = 0.0 // Linear value at bottom of scale.
    var xMinLog = 1.0 // Linear value at the bottom of the log part of the scale. For a scale that is entirely log, xMinLin = xMinLog (nonzero)
    var xMaxLin = 0.0 // Linear value at the top of the scale.
    var xMaxLog = 1.0 // Linear value at the top of the log part of the scale.
    
    var yVariate = 0 // For univariate. Values below are used only for univariate.
    var yAxisLabel = "Count" // Default
    var yAxisType = LinearTag // Default. One of {"Linear", "Log"}
    var yMinLin = 0.0
    var yMinLog = 1.0
    var yMaxLin = 0.0
    var yMaxLog = 1.0
    var yAutoScale: Bool = true
    
    var logLikeScaleTransform = 0 // Logicle=0, Asinh=1, Hyperlog=2
    
    // Log like histogram display parameters
    var T = 0.0
    var W = 0.0
    var M = 0.0
    var A = 0.0
    
    // Logicle parameters
    var logicleT = 0.0
    var logicleW = 0.0
    var logicleM = 0.0
    var logicleA = 0.0
    
    // Asinh parameters
    var asinhT = 0.0
    var asinhW = 0.0
    var asinhM = 0.0
    var asinhA = 0.0
    
    // Hyperlog parameters
    var hyperlogT = 0.0
    var hyperlogW = 0.0
    var hyperlogM = 0.0
    var hyperlogA = 0.0
    
    override init() {
    }
    
    
    /// convenience init initializes histogram limits object and sets preferences
    ///
    /// - Parameter variate: x variate
    convenience init(variate: Int) {
        self.init()
        xVariate = variate
        xAxisLabel = UnknownTag
        xAxisType = UnknownTag
        xMinLin = 0.0
        xMinLog = 1.0
        xMaxLin = 0.0
        xMaxLog = 1.0
        
        let defaults = UserDefaults.standard // class func
        
        logicleT = defaults.double(forKey: Preferences.LogicleTKey)
        logicleW = defaults.double(forKey: Preferences.LogicleWKey)
        logicleM = defaults.double(forKey: Preferences.LogicleMKey)
        logicleA = defaults.double(forKey: Preferences.LogicleAKey)
        
        asinhT = defaults.double(forKey: Preferences.AsinhTKey)
        asinhW = defaults.double(forKey: Preferences.AsinhWKey)
        asinhM = defaults.double(forKey: Preferences.AsinhMKey)
        asinhA = defaults.double(forKey: Preferences.AsinhAKey)
        
        hyperlogT = defaults.double(forKey: Preferences.HyperlogTKey)
        hyperlogW = defaults.double(forKey: Preferences.HyperlogWKey)
        hyperlogM = defaults.double(forKey: Preferences.HyperlogMKey)
        hyperlogA = defaults.double(forKey: Preferences.HyperlogAKey)
        
        logLikeScaleTransform = defaults.integer(forKey: Preferences.LogLikeScaleTransformKey)
        switch logLikeScaleTransform {
        case 0:
            T = logicleT
            W = logicleW
            M = logicleM
            A = logicleA
        case 1:
            T = asinhT
            W = asinhW
            M = asinhM
            A = asinhA
        case 2:
            T = hyperlogT
            W = hyperlogW
            M = hyperlogM
            A = hyperlogA
        default:
            T = 300000.0
            W = 1.0
            M = 4.5
            A = 0.0
        }
        
        yVariate = 0
        yAxisLabel = "Count"
        yAxisType = LinearTag
        yMinLin = 0.0
        yMinLog = 1.0
        yMaxLin = 0.0
        yMaxLog = 1.0
        yAutoScale = true
        
    } // End of convenience init
    
    
    /// copy supports copy function
    ///
    /// - Parameter zone: NSZone
    /// - Returns: new histogram limits
    public func copy(with zone: NSZone?) -> Any {
        let newHistLimits = HistLimits(variate: xVariate)
        newHistLimits.xVariate = xVariate
        newHistLimits.xAxisLabel = xAxisLabel
        newHistLimits.xMinLin = xMinLin
        newHistLimits.xMinLog = xMinLog
        newHistLimits.xMaxLin = xMaxLin
        newHistLimits.xMaxLog = xMaxLog
        
        newHistLimits.logLikeScaleTransform = logLikeScaleTransform
        
        newHistLimits.logicleT = logicleT
        newHistLimits.logicleW = logicleW
        newHistLimits.logicleM = logicleM
        newHistLimits.logicleA = logicleA
        
        newHistLimits.asinhT = asinhT
        newHistLimits.asinhW = asinhW
        newHistLimits.asinhM = asinhM
        newHistLimits.asinhA = asinhA
        
        newHistLimits.hyperlogT = hyperlogT
        newHistLimits.hyperlogW = hyperlogW
        newHistLimits.hyperlogM = hyperlogM
        newHistLimits.hyperlogA = hyperlogA
        
        newHistLimits.T = T
        newHistLimits.W = W
        newHistLimits.M = M
        newHistLimits.A = A
        
        newHistLimits.yVariate = yVariate
        newHistLimits.yAxisLabel = yAxisLabel
        newHistLimits.yAxisType = yAxisType
        newHistLimits.yMinLin = yMinLin
        newHistLimits.yMinLog = yMinLog
        newHistLimits.yMaxLin = yMaxLin
        newHistLimits.yMaxLog = yMaxLog
        newHistLimits.yAutoScale = yAutoScale
        
        return newHistLimits
        
    } // End of copyWithZone
    
    
    /// mutableCopy supports copy function
    ///
    /// - Parameter zone: NSZone
    /// - Returns: new histogram limits
    public func mutableCopy(with zone: NSZone?) -> Any {
        let newHistLimits = HistLimits(variate: xVariate)
        newHistLimits.xVariate = xVariate
        newHistLimits.xAxisLabel = xAxisLabel
        newHistLimits.xMinLin = xMinLin
        newHistLimits.xMinLog = xMinLog
        newHistLimits.xMaxLin = xMaxLin
        newHistLimits.xMaxLog = xMaxLog
        
        newHistLimits.logLikeScaleTransform = logLikeScaleTransform
        
        newHistLimits.logicleT = logicleT
        newHistLimits.logicleW = logicleW
        newHistLimits.logicleM = logicleM
        newHistLimits.logicleA = logicleA
        
        newHistLimits.asinhT = asinhT
        newHistLimits.asinhW = asinhW
        newHistLimits.asinhM = asinhM
        newHistLimits.asinhA = asinhA
        
        newHistLimits.hyperlogT = hyperlogT
        newHistLimits.hyperlogW = hyperlogW
        newHistLimits.hyperlogM = hyperlogM
        newHistLimits.hyperlogA = hyperlogA
        
        newHistLimits.T = T
        newHistLimits.W = W
        newHistLimits.M = M
        newHistLimits.A = A
        
        newHistLimits.yVariate = yVariate
        newHistLimits.yAxisLabel = yAxisLabel
        newHistLimits.yAxisType = yAxisType
        newHistLimits.yMinLin = yMinLin
        newHistLimits.yMinLog = yMinLog
        newHistLimits.yMaxLin = yMaxLin
        newHistLimits.yMaxLog = yMaxLog
        newHistLimits.yAutoScale = yAutoScale
        
        return newHistLimits
        
    } // End of mutableCopyWithZone
    
    
    /// description
    override public var description: String {
        get {
            var result = "\n\nxVariate \(xVariate)  xAxisType \(xAxisType)  xAxisLabel \(xAxisLabel)\n"
            result += "xMinLin \(xMinLin)  xMaxLin \(xMaxLin) logLikeScaleTransform \(logLikeScaleTransform)\n"
            result += "xMinLog \(xMinLog)  xMaxLog \(xMaxLog)\n"
            result += "T \(T)  W \(W)  M \(M)  A \(A)\n"
            result += "logicleT \(logicleT)  logicleW \(logicleW)  logicleM \(logicleM)  logicleA \(logicleA)\n"
            result += "asinhT \(asinhT)  asinhW \(asinhW)  asinhM \(asinhM)  asinhA \(asinhA)\n"
            result += "hyperlogT \(hyperlogT)  hyperlogW \(hyperlogW)  hyperlogM \(hyperlogM)  hyperlogA \(hyperlogA)\n"
            result += "yVariate \(yVariate)  yAxisType \(yAxisType)  yAxisLabel \(yAxisLabel)\n"
            result += "yMinLin \(yMinLin)  yMaxLin \(yMaxLin)\n"
            result += "yMinLog \(yMinLog)  yMaxLog \(yMaxLog)  yAutoScale \(yAutoScale)"
            return result
        }
        
    } // End description
    
} // End of HistLimits class
