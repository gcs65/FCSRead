//
//  HistogramGraphicExtUnivariate.swift is an extension of HistogramGraphic to support univariate histograms.
//  FCSRead
//
//  Created by Mr. Salzman on 12/26/15.
//  Copyright © 2019 Gary Salzman. All rights reserved.
//

import Cocoa

extension HistogramGraphic {

    /// createInnerBoxPath, which is the rectangle surrounding the histogram.
    ///
    /// - Returns: NSBezierPath innerBoxPath
    func createInnerBoxPath() -> NSBezierPath {
        var r1 = NSMakeRect(0.0, 0.0, innerBoxWidth, innerBoxHeight)
        // Expand innerBox to show overflow at histogram boundaries.
        r1 = NSInsetRect(r1, -3.0, -3.0)
        let innerBoxPath = NSBezierPath(rect: r1)
        return innerBoxPath
        
    } // End of createInnerBoxPath
    
    
    /// createUnivariateHistogramPath. Called by HistogramGraphic.drawUnivariateHistogramInView to create the ungated univariate histogram path.
    ///
    /// - Returns: NSBezierPath univariateHistogramPath decribing the univariate histogram.
    func createUnivariateHistogramPath() -> NSBezierPath {
        var bX: CGFloat = 0.0
        var bY: CGFloat = 0.0
        let univariateHistogramPath = NSBezierPath()
        
        scaleX = innerBoxWidth / CGFloat(uniHist!.histRange1P)
        scaleY = innerBoxHeight / (yMax - yMin)
        let yMinInt = Int(yMin)
        let yMaxInt = Int(yMax)
        for bin in 0..<uniHist!.histRange1P { // Constrain y values
            var value = uniHist!.histogramValues[bin]
            if value < yMinInt {
                value = yMinInt
            } else if value > yMaxInt {
                value = yMaxInt
            }
        } // End of constrain y values
        for bin in 0..<uniHist!.histRange1P {
            bX = scaleX * CGFloat(bin)
            bY = scaleY * (CGFloat(uniHist!.histogramValues[bin]) - yMin)
            if bin == 0 {
                univariateHistogramPath.move(to: NSMakePoint(bX, bY))
            }
            else {
               univariateHistogramPath.line(to: NSMakePoint(bX, bY))
            }
        } // End of for bin in 0..
        return univariateHistogramPath
        
    } // End of createUnivariateHistogramPath
    
    
    /// createGatedUnivariateHistogramPath. Called by HistogramGraphic.drawGatedUnivariateInView to create the gated univariate histogram path.
    ///
    /// - Returns: NSBezierPath univariateHistogramPath decribing the gated univariate histogram.
    func createGatedUnivariateHistogramPath() -> NSBezierPath {
        var bX: CGFloat = 0.0
        var bY: CGFloat = 0.0
        let gatedHistogramPath = NSBezierPath()
        scaleX = innerBoxWidth / CGFloat(uniHist!.histRange1P)
        scaleY = innerBoxHeight / (yMax - yMin)
        for bin in 0..<uniHist!.histRange1P { // Constrain y values
            let yMinInt = Int(yMin)
            let yMaxInt = Int(yMax)
            var value = uniHist!.gatedHistogramValues[bin]
            if value < yMinInt {
                value = yMinInt
            } else if value > yMaxInt {
                value = yMaxInt
            }
        } // End of constrain y values
       for bin in 0..<uniHist!.histRange1P {
            bX = scaleX * CGFloat(bin)
            bY = scaleY * (CGFloat(uniHist!.gatedHistogramValues[bin]) - yMin)
            if bin == 0 {
                gatedHistogramPath.move(to: NSMakePoint(bX, bY))
            }
            else {
                gatedHistogramPath.line(to: NSMakePoint(bX, bY))
            }
        } // End of for bin in 0..
        return gatedHistogramPath
    } // End of createGatedUnivariateHistogramPath
    
    
    /// xAxisLabel draws the x axis label String
    func xAxisLabel() {
        var textRect = NSZeroRect
        let myFont:NSFont = NSFont(name: fontName, size: fontSize)!
        let textColor = NSColor.black
        let textStyle = NSMutableParagraphStyle.default.mutableCopy() as! NSMutableParagraphStyle
        textStyle.alignment = NSTextAlignment.center
        let textFontAttributes: Dictionary = [NSAttributedString.Key.font:myFont,
            NSAttributedString.Key.foregroundColor:textColor, NSAttributedString.Key.paragraphStyle:textStyle]
        textRect = NSMakeRect(0.0, -0.15 * innerBoxHeight, innerBoxWidth, 0.05 * innerBoxHeight)
        xAxisLabelString.draw(in: textRect, withAttributes: textFontAttributes)
    } // End of xAxisLabel
    
    
    /// xAxisNumbers creates and draws linear x-axis numbers.
    func xAxisNumbers() {
        // Creates and draws linear x-axis numbers.
        var r = NSZeroRect
        var text = String()
        let myFont:NSFont = NSFont(name: fontName, size: fontSize)!
        let textColor = NSColor.black
        let textStyle = NSMutableParagraphStyle.default.mutableCopy() as! NSMutableParagraphStyle
        textStyle.alignment = NSTextAlignment.left
        let textFontAttributes: Dictionary = [NSAttributedString.Key.font:myFont,
                NSAttributedString.Key.foregroundColor:textColor, NSAttributedString.Key.paragraphStyle:textStyle]
        
        var x = xMin
        while x <= xMax {
            if x < 100.0 {
                text = String(format: "%2.0f", x)
            } else if x >= 100.0 && x < 1000.0 {
                text = String(format: "%3.0f", x)
            } else if x >= 1000.0 && x < 10_000.0 {
                text = String(format: "%4.0f", x)
            } else if x >= 10_000.0 && x < 100_000.0 {
                text = String(format: "%5.0f", x)
            } else {
                text = String(format: "%6.0f", x)
            }
            let styledText = NSAttributedString(string: text, attributes: textFontAttributes)
            let b = (x - xMin) * (innerBoxWidth / (xMax - xMin))
            r = NSMakeRect(b - 0.03 * innerBoxWidth, -0.28 * innerBoxHeight, 0.2 * innerBoxWidth, 0.25 * innerBoxHeight)
            styledText.draw(in: r)
            x += xMajorDiv
        }
    } // End of xAxisNumbers
    
    
    /// xAxisTics creates and draws linear x-axis tics.
    ///
    /// - Returns: NSBezierPath for linear x-axis tics.
    func xAxisTics() -> NSBezierPath {
        var b: CGFloat = 0.0
        let minorTicLength: CGFloat = 0.5 * majorTicLength
        let xTicPath = NSBezierPath()
        
        var x = xMin
        while x <= xMax {
            b = (x - xMin) * innerBoxWidth / (xMax - xMin)
            xTicPath.move(to: NSMakePoint(b, -2.0))
            xTicPath.line(to: NSMakePoint(b, -majorTicLength))
            xTicPath.move(to: NSMakePoint(b, innerBoxHeight + 2.0))
            xTicPath.line(to: NSMakePoint(b, innerBoxHeight + majorTicLength))
            x += xMajorDiv
        }
        
        x = xMin
        while x <= xMax {
            b = (x - xMin) * (innerBoxWidth / (xMax - xMin))
            xTicPath.move(to: NSMakePoint(b, -2.0))
            xTicPath.line(to: NSMakePoint(b, -minorTicLength))
            xTicPath.move(to: NSMakePoint(b, innerBoxHeight + 2.0))
            xTicPath.line(to: NSMakePoint(b, innerBoxHeight + minorTicLength))
            x += xMinorDiv
        }
        
        return xTicPath
        
    } // End of xAxisTics
    
    
    /// yAxisTics creates and draws linear y-axis tics.
    ///
    /// - Returns: NSBezierPath for linear y-axis tics.
    func yAxisTics() -> NSBezierPath {
        // Creates and draws linear y-axis tics
        var b: CGFloat = 0.0
        let minorTicLength: CGFloat = 0.5 * majorTicLength
        let yTicPath = NSBezierPath()
        
        var y = yMin
        while y <= yMax { // Major tics
            b = (y - yMin) * innerBoxHeight / (yMax - yMin)
            yTicPath.move(to: NSMakePoint(-2.0, b)) // Major tics on left
            yTicPath.line(to: NSMakePoint(-majorTicLength - 2.0, b))
            yTicPath.move(to: NSMakePoint(innerBoxWidth + 2.0, b))
            yTicPath.line(to: NSMakePoint(innerBoxWidth + majorTicLength + 2.0, b))
            y += yMajorDiv
        }
        
        y = yMin
        while y <= yMax { // Minor tics
            b = (y - yMin) * innerBoxHeight / (yMax - yMin)
            yTicPath.move(to: NSMakePoint(-2.0, b)) // Minor tics on left.
            yTicPath.line(to: NSMakePoint(-minorTicLength - 2.0, b))
            yTicPath.move(to: NSMakePoint(innerBoxWidth + 2.0, b)) // Minor tics on right.
            yTicPath.line(to: NSMakePoint(innerBoxWidth + minorTicLength + 2.0, b))
            y += yMinorDiv
        }
        
        return yTicPath
        
    } // End of yAxisTics
    
    
    /// yAxisLabel draws the y axis label String
    func yAxisLabel() {
        var textRect = NSZeroRect
        let myFont:NSFont = NSFont(name: fontName, size: fontSize)!
        let textColor = NSColor.black
        let textStyle = NSMutableParagraphStyle.default.mutableCopy() as! NSMutableParagraphStyle
        textStyle.alignment = NSTextAlignment.center
        let textFontAttributes: Dictionary = [NSAttributedString.Key.font:myFont,
            NSAttributedString.Key.foregroundColor:textColor, NSAttributedString.Key.paragraphStyle:textStyle]
        var xform1 = AffineTransform()
        xform1.rotate(byDegrees: 90.0) // Rotate by 90 degrees.
        (xform1 as NSAffineTransform).concat()
        textRect = NSMakeRect(0.0, 0.18 * innerBoxWidth, innerBoxHeight, 0.05 * innerBoxWidth)
        yAxisLabelString.draw(in: textRect, withAttributes: textFontAttributes)
        xform1.rotate(byDegrees: -90.0)
        (xform1 as NSAffineTransform).concat()
        
    } // End of yAxisLabel
    
    
    /// yAxisNumbers creates and draws linear y-axis numbers.
    func yAxisNumbers() {
        var r = NSZeroRect
        var text = String()
        let myFont:NSFont = NSFont(name: fontName, size: fontSize)!
        let textColor = NSColor.black
        let textStyle = NSMutableParagraphStyle.default.mutableCopy() as! NSMutableParagraphStyle
        let textFontAttributes: Dictionary = [NSAttributedString.Key.font:myFont,
            NSAttributedString.Key.foregroundColor:textColor, NSAttributedString.Key.paragraphStyle:textStyle]
        var y = yMin
        while y <= yMax {
            text = String(format: "%4.0f", y)
            let styledText = NSAttributedString(string: text, attributes: textFontAttributes)
            let b = (y - yMin) * innerBoxHeight / (yMax - yMin)
            r = NSMakeRect(-0.15 * innerBoxWidth, b - 0.23 * innerBoxHeight, 0.15 * innerBoxWidth, 0.25 * innerBoxHeight)
            styledText.draw(in: r)
            y += yMajorDiv
        }
    } // End of yAxisNumbers
    
} // End of HistogramGraphicExtensionLinear
