//
//  HistogramGraphicExtensionLog.swift is an extension of HistogramGraphic for log scale tics and numbers.
//  FCSRead
//
//  Created by Mr. Salzman on 12/26/15.
//  Copyright © 2019 Gary Salzman. All rights reserved.
//

import Cocoa

extension HistogramGraphic { // Log
    
    
    /// xAxisLogTicsAndNumbers creates an NSBezierPath for x-axis log tics and numbers.
    ///
    /// - Returns: NSBezierPath for x-axis log tics and numbers
    func xAxisLogTicsAndNumbers() -> NSBezierPath {
        var text = String()
        var pt = NSZeroPoint
        let myFont:NSFont = NSFont(name: fontName, size: fontSize)!
        let textColor = NSColor.black
        let textStyle = NSMutableParagraphStyle.default.mutableCopy() as! NSMutableParagraphStyle
        textStyle.alignment = NSTextAlignment.left
        let textFontAttributes: Dictionary = [NSAttributedString.Key.font:myFont,
            NSAttributedString.Key.foregroundColor:textColor, NSAttributedString.Key.paragraphStyle:textStyle]
        var b: CGFloat = 0.0
        var increment: CGFloat = 0.0
        var base: CGFloat = 0.0
        var logTicValue: CGFloat = 0.0
        var ticLength: CGFloat = 0.0
        let minorTicLength = 0.5 * majorTicLength
        let xAxisLogTicPath = NSBezierPath()
        
        let x0 = CGFloat(log10(Double(xMin)))
        let x1 = CGFloat(log10(Double(xMax)))
        let slope = CGFloat(innerBoxWidth / (x1 - x0))
        var ticValue = CGFloat(xMin)
        
        repeat {
            logTicValue = CGFloat(log10(Double(ticValue)))
            if abs(logTicValue) < 0.00001 {
                logTicValue = +0.0
            }
            base = CGFloat(floor(logTicValue))
            increment = CGFloat(pow(10.0, Double(base)))
            if abs(logTicValue - base) > 0.01 { // At minor division
                ticLength = minorTicLength
            }
            else { // At major division
                ticLength = majorTicLength
                text = String(format:"%2.0f%2.0f", 10.0, base)
                let logAxisNumberString = NSMutableAttributedString(string: text, attributes: textFontAttributes)
                logAxisNumberString.beginEditing()
                logAxisNumberString.addAttribute(NSAttributedString.Key.baselineOffset, value: NSNumber(value: Float(0.02 * innerBoxHeight)), range: NSMakeRange(2, 2))
                logAxisNumberString.endEditing()
                b = slope * (logTicValue - x0)
                pt = NSMakePoint(b - 0.04 * innerBoxWidth, -0.09 * innerBoxHeight)
                logAxisNumberString.draw(at: pt)
            } // End of else
            
            // Now draw tic marks
            b = slope * (logTicValue - x0)
            xAxisLogTicPath.move(to: NSMakePoint(b, -2.0)) // tics on bottom
            xAxisLogTicPath.line(to: NSMakePoint(b, -ticLength - 2.0))
            xAxisLogTicPath.move(to: NSMakePoint(b, innerBoxHeight + 2.0)) // tics at top
            xAxisLogTicPath.line(to: NSMakePoint(b, innerBoxHeight + ticLength + 2.0))
            
            ticValue += increment
            
        } while ticValue < xMax + increment
        
        return xAxisLogTicPath
        
    } // End of xAxisLogTicsAndNumbers
    
    
    /// yAxisLogTicsAndNumbers creates an NSBezierPath for y-axis log tics and numbers.
    ///
    /// - Returns: NSBezierPath for y-axis log tics and numbers
    func yAxisLogTicsAndNumbers() -> NSBezierPath {
        var text = String()
        var pt = NSZeroPoint
        let myFont:NSFont = NSFont(name: fontName, size: fontSize)!
        let textColor = NSColor.black
        let textStyle = NSMutableParagraphStyle.default.mutableCopy() as! NSMutableParagraphStyle
        textStyle.alignment = NSTextAlignment.left
        let textFontAttributes: Dictionary = [NSAttributedString.Key.font:myFont,
            NSAttributedString.Key.foregroundColor:textColor, NSAttributedString.Key.paragraphStyle:textStyle]
        var b: CGFloat = 0.0
        var increment: CGFloat = 0.0
        var base: CGFloat = 0.0
        var logTicValue: CGFloat = 0.0
        var ticLength: CGFloat = 0.0
        let minorTicLength = 0.5 * majorTicLength
        let yAxisLogTicPath = NSBezierPath()
        
        let y0 = CGFloat(log10(Double(yMin)))
        let y1 = CGFloat(log10(Double(yMax)))
        let slope = CGFloat(innerBoxHeight / (y1 - y0))
        var ticValue = CGFloat(yMin)
        
        repeat {
            logTicValue = CGFloat(log10(Double(ticValue)))
            if abs(logTicValue) < 0.00001 {
                logTicValue = +0.0
            }
            base = CGFloat(floor(logTicValue))
            increment = CGFloat(pow(10.0, Double(base)))
            if abs(logTicValue - base) > 0.01 { // At minor division
                ticLength = minorTicLength
            }
            else { // At major division
                ticLength = majorTicLength
                text = String(format:"%2.0f%2.0f", 10.0, base)
                let logAxisNumberString = NSMutableAttributedString(string: text, attributes: textFontAttributes)
                logAxisNumberString.beginEditing()
                logAxisNumberString.addAttribute(NSAttributedString.Key.baselineOffset, value: NSNumber(value: Float(0.02 * innerBoxWidth)), range: NSMakeRange(2, 2))
                logAxisNumberString.endEditing()
                b = slope * (logTicValue - y0)
                pt = NSMakePoint(-0.12 * innerBoxWidth, b - 0.03 * innerBoxHeight)
                logAxisNumberString.draw(at: pt)
            } // End of else
            
            // Now draw tic marks
            b = slope * (logTicValue - y0)
            yAxisLogTicPath.move(to: NSMakePoint(-2.0, b)) // tics on left
            yAxisLogTicPath.line(to: NSMakePoint(-ticLength - 2.0, b))
            yAxisLogTicPath.move(to: NSMakePoint(innerBoxWidth + 2.0, b)) // tics on right
            yAxisLogTicPath.line(to: NSMakePoint(innerBoxWidth + ticLength + 2.0, b))
            
            ticValue += increment
            
        } while ticValue < yMax + increment
        
        return yAxisLogTicPath
        
    } // End of yAxisLogTicsAndNumbers
    
} // End of HistogramGraphicExtensionLog
