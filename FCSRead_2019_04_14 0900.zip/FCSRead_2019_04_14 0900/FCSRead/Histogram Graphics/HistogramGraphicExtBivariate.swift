//
//  HistogramGraphicExtBivariate.swift is an extension of HistogramGraphic for bivariate histograms.
//  FCSRead
//
//  Created by Mr. Salzman on 12/29/15.
//  Copyright © 2019 Gary Salzman. All rights reserved.
//

import Cocoa

extension HistogramGraphic {
    
    /// createBivariateHistogramPath. Called by HistogramGraphic.drawBivariateHistogramInView. Truncated linear color scale for zValue for dotPlot (6 levels) (Used here). Creates ungated bivariate histogram path.
    ///
    /// - Returns: NSBezierPath called bivariateHistogramPath
    func createBivariateHistogramPath() -> NSBezierPath {
        let bivariateHistogramPath = NSBezierPath()
        var rectPath = NSBezierPath()
        var aRect = NSZeroRect
        var bX: CGFloat = 0.0
        var bY: CGFloat = 0.0
        var myFillColor = NSColor.white
        scaleX2P = innerBoxWidth / CGFloat(bivHist!.histRange2P)
        scaleY2P = innerBoxHeight / CGFloat(bivHist!.histRange2P)
        let widthDot = scaleX2P
        let heightDot = scaleY2P
        var aPoint = NSZeroPoint
        var index = 0
        var zValue = 0
        
        for binX in 0..<bivHist!.histRange2P {
            bX = CGFloat(binX) * scaleX2P
            for binY in 0..<bivHist!.histRange2P {
                index = binX * bivHist!.histRange2P + binY
                zValue = bivHist!.bivHistogramValues[index]
                if zValue >= 1 {
                    bY = CGFloat(binY) * scaleY2P
                    aPoint = NSMakePoint(bX, bY)
                    bivariateHistogramPath.move(to: aPoint)
                    myFillColor = chooseShortColorForValue(zValue)
                    aRect = NSMakeRect(aPoint.x, aPoint.y, widthDot, heightDot)
                    aRect = aRect.integral
                    myFillColor.set()
                    NSBezierPath.fill(aRect)
                    NSBezierPath.stroke(aRect)
                    rectPath = NSBezierPath(rect: aRect)
                    bivariateHistogramPath.append(rectPath)
                }  // End of zValue >= 1
            } // End of loop binY in 0..< end2P
        } // End of loop binX in 0..< end2P
        
        return bivariateHistogramPath
        
    } // End of createBivariateHistogramPath
    
    
    /// createGatedBivariateHistogramPath. Called by HistogramGraphic.drawGatedBivariateHistogramInView to create a gated bivariate histogram path.
    ///
    /// - Returns: NSBezierPath for a gated bivariate histogram.
    func createGatedBivariateHistogramPath() -> NSBezierPath {
        
        let gatedBivariateHistogramPath = NSBezierPath()
        var rectPath = NSBezierPath()
        var aRect = NSZeroRect
        var bX: CGFloat = 0.0
        var bY: CGFloat = 0.0
        var myFillColor = NSColor.white
        scaleX2P = innerBoxWidth / CGFloat(bivHist!.histRange2P)
        scaleY2P = innerBoxHeight / CGFloat(bivHist!.histRange2P)
        let widthDot = scaleX2P
        let heightDot = scaleY2P
        var aPoint = NSZeroPoint
        var index = 0
        var zValue = 0
        
        for binX in 0..<bivHist!.histRange2P {
            bX = CGFloat(binX) * scaleX2P
            for binY in 0..<bivHist!.histRange2P {
                index = binX * bivHist!.histRange2P + binY
                zValue = bivHist!.gatedBivHistogramValues[index]
                if zValue >= 1 {
                    bY = CGFloat(binY) * scaleY2P
                    aPoint = NSMakePoint(bX, bY)
                    gatedBivariateHistogramPath.move(to: aPoint)
                    myFillColor = bivHist!.gatedBivHistElementColor[index]
                    aRect = NSMakeRect(aPoint.x, aPoint.y, widthDot, heightDot)
                    aRect = aRect.integral
                    myFillColor.set()
                    NSBezierPath.fill(aRect)
                    NSBezierPath.stroke(aRect)
                    rectPath = NSBezierPath(rect: aRect)
                    gatedBivariateHistogramPath.append(rectPath)
                }  // End of zValue >= 1
            } // End of loop binY in 0..< end2P
        } // End of loop binX in 0..< end2P
        
        return gatedBivariateHistogramPath
        
    } // End of createGatedBivariateHistogramPath
    
    /// chooseShortColorForValue sets six levels for the colors in the bivariate histogram.
    ///
    /// - Parameter zValue: Int for the zValue above the x-y plane.
    /// - Returns: the NSColor aFillColor
    func chooseShortColorForValue(_ zValue: Int) -> NSColor {
        var aFillColor = NSColor.white
        let peak: Int = bivHist!.peak
        
        if zValue >= 1 && zValue < Int(floor(0.1 * Double(peak))) {
            aFillColor = NSColor.brown
        }
        else if zValue >= Int(floor(0.1 * Double(peak))) && zValue < Int(floor(0.3 * Double(peak))) {
            aFillColor = NSColor.cyan
        }
        else if zValue >= Int(floor(0.3 * Double(peak))) && zValue < Int(floor(0.5 * Double(peak))) {
            aFillColor = NSColor.blue
        }
        else if zValue >= Int(floor(0.5 * Double(peak))) && zValue < Int(floor(0.7 * Double(peak))) {
            aFillColor = NSColor.green
        }
        else if zValue >= Int(floor(0.7 * Double(peak))) && zValue < Int(floor(0.9 * Double(peak))) {
            aFillColor = NSColor.red
        }
        else if zValue >= Int(floor(0.9 * Double(peak))) && zValue < Int(floor(1.0 * Double(peak))) {
            aFillColor = NSColor.white
        }
        else if zValue > Int(floor(Double(peak))) {
            aFillColor = NSColor.black
        }
        else {}
        
        return aFillColor
        
    } // End of chooseShortColorForValue
    
} // End of HistogramGraphicExtBivariate


