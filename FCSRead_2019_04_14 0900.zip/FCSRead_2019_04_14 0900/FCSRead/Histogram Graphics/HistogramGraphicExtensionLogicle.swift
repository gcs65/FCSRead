//
//  HistogramGraphicExtensionLogicle.swift extension of HistogramGraphic to support Logicle, Asinh, and Hyperlog tics and numbers.
//  FCSRead
//
//  Created by Mr. Salzman on 12/26/15.
//  Copyright © 2019 Gary Salzman. All rights reserved.
//

import Cocoa

extension HistogramGraphic {
    
    
    /// xAxisLogicleTicsAndNumbers creates an NSBezierPath for Logicle x-axis tics and numbers. Called by HistogramGraphic.drawUnivariateHistogramInView and by drawBivariateHistogramInView. Used for Logicle, Asinh, and Hyperlog
    ///
    /// - Returns: NSBezierPath for Logicle x-axis tics and numbers
    func xAxisLogicleTicsAndNumbers() -> NSBezierPath {

        let xAxisLogicleTicPath = NSBezierPath()
        var text = String()
        var pt = NSZeroPoint
        let myFont:NSFont = NSFont(name: fontName, size: fontSize)!
        let textColor = NSColor.black
        let textStyle = NSMutableParagraphStyle.default.mutableCopy() as! NSMutableParagraphStyle
        textStyle.alignment = NSTextAlignment.left
        let textFontAttributes: Dictionary = [NSAttributedString.Key.font:myFont,
            NSAttributedString.Key.foregroundColor:textColor, NSAttributedString.Key.paragraphStyle:textStyle]
        
        var b: CGFloat = 0.0
        let ticLength: CGFloat = majorTicLength
        let minorTicLength = 0.5 * majorTicLength
        let slope = CGFloat(innerBoxWidth) // innerBoxWidth/1.0 for range [0,1]
        var exponent = 0
        var mySign = 0
        var label = [Double]()
        var bins = 0

        if myView?.histogramType == UnivariateTag {
            bins = uniHist!.histRange1P
        }
        else { // "Bivariate"
            bins = bivHist!.histRange2P
        }
        
        let fastLogicle = FastLogicle(inputT: histLimitsX!.T, inputW: histLimitsX!.W, inputM: histLimitsX!.M, inputA: histLimitsX!.A, inputBins: bins)
        let hyperlog = Hyperlog(inputT: histLimitsX!.T, inputW: histLimitsX!.W, inputM: histLimitsX!.M, inputA: histLimitsX!.A, inputBins: bins)
        
        if histLimitsX!.xAxisType == LogicleTag || histLimitsX?.xAxisType == AsinhTag {
            xMin = CGFloat(fastLogicle.inverseWithScale(0.0))
            label = fastLogicle.axisLabels()
        }
        else if histLimitsX!.xAxisType == HyperlogTag {
            var temp1 = 0.0
            xMin = CGFloat(hyperlog.inverseWithScale(&temp1))
            label = hyperlog.axisLabels()
        }
        
        for i in 0 ..< label.count {
            if histLimitsX?.xAxisType == HyperlogTag {
                b = CGFloat(slope * CGFloat(hyperlog.scaleWithValue(label[i])))
            }
            else { // FastLogicle
                b = CGFloat(slope * CGFloat(fastLogicle.scaleWithValue(label[i])))
            }
            
            if label[i] == 0.0 {
                exponent = 0
            }
            else {
                exponent = Int(log10(abs(label[i])))
            }
            
            if label[i] < 0.0 {
                mySign = -1  // -1 for -1_000
            }
            else {
                mySign = +1
            }
            
            if label[i] != 0.0 { // Axis label for 10^exponent
                text = String(format: "%3d%2d", mySign * 10, exponent)
                let logicleAxisNumberString = NSMutableAttributedString(string: text, attributes: textFontAttributes)
                logicleAxisNumberString.beginEditing()
                logicleAxisNumberString.addAttribute(NSAttributedString.Key.baselineOffset, value: NSNumber(value: Float(0.02 * innerBoxHeight)), range: NSMakeRange(3, 2))
                logicleAxisNumberString.endEditing()
                pt = NSMakePoint(b - 0.04 * innerBoxWidth, -0.09 * innerBoxHeight)
                logicleAxisNumberString.draw(at: pt)
            }
            else { // label[i] == 0 (Axis label 0)
                text = String(format: "%1d", 0) // zero
                let logicleAxisNumberString = NSMutableAttributedString(string: text, attributes: textFontAttributes)
                pt = NSMakePoint(b - 0.01 * innerBoxWidth, -0.09 * innerBoxHeight)
                logicleAxisNumberString.draw(at: pt)
            }
            
            // Now draw major tic marks at each label[i]
            xAxisLogicleTicPath.move(to: NSMakePoint(b, -2.0)) // tics at bottom
            xAxisLogicleTicPath.line(to: NSMakePoint(b, -ticLength - 2.0))
            xAxisLogicleTicPath.move(to: NSMakePoint(b, innerBoxHeight + 2.0))
            xAxisLogicleTicPath.line(to: NSMakePoint(b,innerBoxHeight + ticLength + 2.0)) // tics on top
            
        } // End of for i loop
        
        // Now draw minor tics (several special cases)
        if label[0] < 0.0 { // Draw minor "linear" tics up to label[2]
            let stepSize = 0.1 * label[2]  // Linear region major tics start negative.
            var step = label[0]
            while step < label[2] {
                if step >= histLimitsX!.T {
                    step = histLimitsX!.T - 1.0
                }
                if histLimitsX!.xAxisType == HyperlogTag {
                    b = CGFloat(Double(slope) * hyperlog.scaleWithValue(step))
                }
                else {
                    b = CGFloat(Double(slope) * fastLogicle.scaleWithValue(step))
                }
                xAxisLogicleTicPath.move(to: NSMakePoint(b, -2.0)) // tics on bottom
                xAxisLogicleTicPath.line(to: NSMakePoint(b, -minorTicLength - 2.0))
                xAxisLogicleTicPath.move(to: NSMakePoint(b, innerBoxHeight + 2.0))
                xAxisLogicleTicPath.line(to: NSMakePoint(b, innerBoxHeight + minorTicLength + 2.0)) // tics on top.
                step = step + stepSize
            } // End of for var step...
            
            // Draw minor "log" tics in log region starting at label[2]
            for j in 2..<label.count - 1 { // For each decade
                let stepSize = 0.1 * label[j + 1]
                var step = label[j]
                while step <= label[j + 1] {
                    if histLimitsX!.xAxisType == HyperlogTag {
                        b = CGFloat(Double(slope) * hyperlog.scaleWithValue(step))
                    } else {
                        b = CGFloat(Double(slope) * fastLogicle.scaleWithValue(step))
                    }
                    xAxisLogicleTicPath.move(to: NSMakePoint(b, -2.0)) // tics on bottom
                    xAxisLogicleTicPath.line(to: NSMakePoint(b, -minorTicLength - 2.0))
                    xAxisLogicleTicPath.move(to: NSMakePoint(b, innerBoxHeight + 2.0))
                    xAxisLogicleTicPath.line(to: NSMakePoint(b, innerBoxHeight + minorTicLength + 2.0)) // tics on top.
                    step += stepSize
                } // End of for var step...
            }
        } // End of label[0] < 0.0 if
        
        else if label[0] == 0.0 {
            for j in 0..<label.count - 1 {
                let stepSize = 0.1 * label[j + 1] // Linear region major tics start at 0.
                var step = label[j]
                while step <= label[j + 1] { // was <
                    if histLimitsX!.xAxisType == HyperlogTag {
                        b = CGFloat(Double(slope) * hyperlog.scaleWithValue(step))
                    } else {
                        b = CGFloat(Double(slope) * fastLogicle.scaleWithValue(step))
                    }
                    xAxisLogicleTicPath.move(to: NSMakePoint(b, -2.0)) // tics on bottom
                    xAxisLogicleTicPath.line(to: NSMakePoint(b, -minorTicLength - 2.0))
                    xAxisLogicleTicPath.move(to: NSMakePoint(b, innerBoxHeight + 2.0))
                    xAxisLogicleTicPath.line(to: NSMakePoint(b, innerBoxHeight + minorTicLength + 2.0)) // tics on top.
                    step += stepSize
                } // End of while
            } // End of for j = 0...
        } // End of else if label[0] == 0.0
        
        return xAxisLogicleTicPath
        
    } // End of xLogicleTicsAndNumbers
    
    
    /// yAxisLogicleTicsAndNumbers creates an NSBezierPath for Logicle y-axis tics and numbers. Called by HistogramGraphic:drawUnivariateHistogramInView: and by drawBivariateHistogramInView:. Used for Logicle, Asinh, and Hyperlog y-axes.
    ///
    /// - Returns: NSBezierPath for Logicle y-axis tics and numbers.
    func yAxisLogicleTicsAndNumbers() -> NSBezierPath {
        
        let yAxisLogicleTicPath = NSBezierPath()
        var text = String()
        var pt = NSZeroPoint
        let myFont:NSFont = NSFont(name: fontName, size: fontSize)!
        let textColor = NSColor.black
        let textStyle = NSMutableParagraphStyle.default.mutableCopy() as! NSMutableParagraphStyle
        textStyle.alignment = NSTextAlignment.left
        let textFontAttributes: Dictionary = [NSAttributedString.Key.font:myFont,
            NSAttributedString.Key.foregroundColor:textColor, NSAttributedString.Key.paragraphStyle:textStyle]
        
        var b: CGFloat = 0.0
        let ticLength: CGFloat = majorTicLength
        let minorTicLength = 0.5 * majorTicLength
        let slope = CGFloat(innerBoxHeight) // innerBoxHeight/1.0 for range [0,1]
        var exponent = 0
        var mySign = 0
        var label = [Double]()
        var bins = 0
        
        if myView?.histogramType == UnivariateTag {
            bins = uniHist!.histRange1P
        }
        else { // "Bivariate"
            bins = bivHist!.histRange2P
        }

        let fastLogicle = FastLogicle(inputT: (histLimitsY?.T)!, inputW: (histLimitsY?.W)!, inputM: (histLimitsY?.M)!, inputA: (histLimitsY?.A)!, inputBins: bins)
        let hyperlog = Hyperlog(inputT: (histLimitsY?.T)!, inputW: (histLimitsY?.W)!, inputM: (histLimitsY?.M)!, inputA: (histLimitsY?.A)!, inputBins: bins)
        
        if histLimitsY!.xAxisType == LogicleTag || histLimitsY?.xAxisType == AsinhTag {
            yMin = CGFloat(fastLogicle.inverseWithScale(0.0))
            label = fastLogicle.axisLabels()
         }
        else if histLimitsY!.xAxisType == HyperlogTag {
            var temp1 = 0.0
            yMin = CGFloat(hyperlog.inverseWithScale(&temp1))
            label = hyperlog.axisLabels()
        }
        
        for i in 0..<label.count {
            if histLimitsY?.xAxisType == HyperlogTag { // Major tic marks
                b = CGFloat(slope * CGFloat(hyperlog.scaleWithValue(label[i])))
            }
            else {
                b = CGFloat(slope * CGFloat(fastLogicle.scaleWithValue(label[i])))
            }
            
            if label[i] == 0.0 {
                exponent = 0
            }
            else {
                exponent = Int(log10(abs(label[i])))
            }
            
            if label[i] < 0.0 {
                mySign = -1  // -1 for -1_000
            }
            else {
                mySign = +1
            }
            
            if label[i] != 0.0 { // Axis label for 10^exponent
                text = String(format: "%3d%2d", mySign * 10, exponent)
                let logicleAxisNumberString = NSMutableAttributedString(string: text, attributes: textFontAttributes)
                logicleAxisNumberString.beginEditing()
                logicleAxisNumberString.addAttribute(NSAttributedString.Key.baselineOffset, value: NSNumber(value: Float(0.02 * innerBoxHeight)), range: NSMakeRange(3, 2))
                logicleAxisNumberString.endEditing()
                pt = NSMakePoint(-0.12 * innerBoxWidth, b - 0.03 * innerBoxHeight)
                logicleAxisNumberString.draw(at: pt)
            }
            else { // label[i] == 0 (Axis label 0)
                text = String(format: "%1d", 0) // zero
                let logicleAxisNumberString = NSMutableAttributedString(string: text, attributes: textFontAttributes)
                pt = NSMakePoint(-0.12 * innerBoxWidth, b - 0.03 * innerBoxHeight)
                logicleAxisNumberString.draw(at: pt)
            }
            
            // Now draw major tic marks at each label[i]
            yAxisLogicleTicPath.move(to: NSMakePoint(-2.0, b)) // tics at left
            yAxisLogicleTicPath.line(to: NSMakePoint(-ticLength - 2.0, b))
            yAxisLogicleTicPath.move(to: NSMakePoint(innerBoxWidth + 2.0, b))
            yAxisLogicleTicPath.line(to: NSMakePoint(innerBoxWidth + ticLength + 2.0, b)) // tics on right
            
        } // End of for i loop
        
        // Now draw minor tics (several special cases)
        if label[0] < 0.0 { // Draw minor "linear" tics up to label[2]
            let stepSize = 0.1 * label[2]  // Linear region major tics start negative.
            for var step in stride(from: label[0], to: label[2], by: stepSize) {
                if step >= histLimitsY!.T {
                    step = histLimitsY!.T - 1.0
                }
                if histLimitsX!.xAxisType == HyperlogTag {
                    b = CGFloat(Double(slope) * hyperlog.scaleWithValue(step))
                }
                else {
                    b = CGFloat(Double(slope) * fastLogicle.scaleWithValue(step))
                }
                yAxisLogicleTicPath.move(to: NSMakePoint(-2.0, b)) // tics on left
                yAxisLogicleTicPath.line(to: NSMakePoint(-minorTicLength - 2.0, b))
                yAxisLogicleTicPath.move(to: NSMakePoint(innerBoxWidth + 2.0, b))
                yAxisLogicleTicPath.line(to: NSMakePoint(innerBoxWidth + minorTicLength + 2.0, b)) // tics on right.
            } // End of for var step...
            
            // Draw minor "log" tics in log region starting at label[2]
            for j in 2..<label.count - 1 { // For each decade
                let stepSize = 0.1 * label[j + 1]
                var step = label[j]
                while step <= label[j + 1] {
                    if histLimitsX!.xAxisType == HyperlogTag {
                        b = CGFloat(Double(slope) * hyperlog.scaleWithValue(step))
                    } else {
                        b = CGFloat(Double(slope) * fastLogicle.scaleWithValue(step))
                    }
                    yAxisLogicleTicPath.move(to: NSMakePoint(-2.0, b)) // tics on bottom
                    yAxisLogicleTicPath.line(to: NSMakePoint(-minorTicLength - 2.0, b))
                    yAxisLogicleTicPath.move(to: NSMakePoint(innerBoxWidth + 2.0, b))
                    yAxisLogicleTicPath.line(to: NSMakePoint(innerBoxWidth + minorTicLength + 2.0, b)) // tics on top.
                    step += stepSize
                } // End of while
            } // End of for j
        } // End of label[0] < 0.0 if
            
        else if label[0] == 0.0 {
            for j in 0..<label.count - 1 {
                let stepSize = 0.1 * label[j + 1] // Linear region major tics start at 0.
                var step = label[j]
                while step < label[j + 1] { // was <=
                    if histLimitsX!.xAxisType == HyperlogTag {
                        b = CGFloat(Double(slope) * hyperlog.scaleWithValue(step))
                    } else {
                        b = CGFloat(Double(slope) * fastLogicle.scaleWithValue(step))
                    }
                    yAxisLogicleTicPath.move(to: NSMakePoint(-2.0, b)) // tics on left
                    yAxisLogicleTicPath.line(to: NSMakePoint(-minorTicLength - 2.0, b))
                    yAxisLogicleTicPath.move(to: NSMakePoint(innerBoxWidth + 2.0, b))
                    yAxisLogicleTicPath.line(to: NSMakePoint(innerBoxWidth + minorTicLength + 2.0, b)) // tics on right.
                    step += stepSize
                } // End of while
            } // End of for j = 0...
        } // End of else if label[0] == 0.0
        
        return yAxisLogicleTicPath
        
    } // End of yAxisLogicleTicsAndNumbers
    
} // End of HistogramGraphicExtensionLogicle


