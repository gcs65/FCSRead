//
//  BivariateHistorgram.swift creates a bivariate histogram. GraphicSubview contains a protocol to create a bivariate histogram. The protocol is addressed by MainViewController with the function generateBivariateHistogram..., which returns a bivariate histogram object (bivHist: BivariateHistogram).
//
//  Created by Mr. Salzman on 12/23/17.
//  Copyright © 2019 Gary Salzman. All rights reserved.
//

import Foundation

class BivariateHistogram {
    var rangeToBinFactor = 0.0
    var bivHistogramValues: [Int] = []
    var gatedBivHistogramValues: [Int] = []
    var gatedBivHistElementColor: [NSColor] = []
    var bivariateHistogramCount = 0 // Total count in a histogram.
    var gatedBivariateHistogramCount = 0 // Total count in a gated histogram.
    var peak = 0
    var xPeak = 0
    var yPeak = 0
    var countThreshold = 0 // Minimum count in a histogram bin.
    var histRange1P = 0
    var histRange2P = 0
    var doCompensation = false
    weak var mainVC: MainViewController?
    weak var fcs: ReadAndParse?
    var success = false
    var xVariate = 0 // [1, variates]
    var yVariate = 0 // [1, variates]
    var logLikeScaleTransform = 0
    var T = 300000.0
    var W = 1.0
    var M = 4.5
    var A = 0.0
    
    
    /// convenience init instantiates a bivariate histogram. Called by MainViewController.generateBivariateHistogram. This call is triggered by GraphicSubview.delegate.convenience init.
    ///
    /// - Parameters:
    ///   - xVar: x-variate
    ///   - yVar: y-variate
    ///   - mViewController: MainViewController
    convenience init(xVar: Int, yVar: Int, mViewController: MainViewController) {
        self.init()
        mainVC = mViewController
        fcs = mainVC?.readAndParse
        xVariate = xVar
        yVariate = yVar
        setPreferences()
        prepareBivariateHistogramForXVariate(xVariate, yVar: yVariate)
        
    } // End of BivariateHistogram convenience init
    
    
    /// prepareBivariateHistogramForXVariate. Called from convenience init to prepare bivariate histogram.
    ///
    /// - Parameters:
    ///   - xVar: x variate
    ///   - yVar: y variate
    func prepareBivariateHistogramForXVariate(_ xVar: Int, yVar: Int) {
        var successX = false
        var successY = false
        bivariateHistogramCount = 0
        gatedBivariateHistogramCount = 0
        var myHistLimitsX = HistLimits(variate: xVar)
        myHistLimitsX = histLimitsDict[xVar]!
        if !(myHistLimitsX.xAxisType == UnknownTag) {successX = true} // myHistLimitsX already calculated.
        else { // myHistLimitsX need to be calculated.
            let uniHist = UnivariateHistogram(myVariate: xVar, mViewController: mainVC!, univariate: false)
            successX = uniHist.calculateHistogramLimits(xVar)
        }
        var myHistLimitsY = HistLimits(variate: yVar)
        myHistLimitsY = histLimitsDict[yVar]!
        if !(myHistLimitsY.xAxisType == UnknownTag) { // myHistLimitsY already calculated.
            successY = true
        }
        else { // myHistLimitsY need to be calculated.
            let uniHist = UnivariateHistogram(myVariate: yVar, mViewController: mainVC!, univariate: false) // univariate is false here to indicate that uniHist is being used only to calculate the histogram limits for the the bivariate histogram.
            successY = uniHist.calculateHistogramLimits(yVar)
         }
        if successX && successY {
            let dataGated = mainVC!.isDataGated
            success = bivariateHistogram(gated: dataGated)
        }
        if success == false {
            print("BivariateHistogram.prepareBivariateHistogramForXVariate... Failed")
        }
    } // End of prepareBivariateHistogramForXVariate: yVariate:
    
    
    /// bivariateHistogram generates a nongated or gated bivariate histogram. Called by prepareBivariateHistogramForXVariate(xVar: yVar:)
    ///
    /// - Parameter gated: boolean true if gated bivariate histogram requested.
    /// - Returns: true if bivariate histogram successfully generated.
    func bivariateHistogram(gated: Bool) -> Bool {
        var binX = 0
        var binY = 0
        var indexBin = 0
        var linValueX = 0.0
        var linValueY = 0.0
        var rangeX = 0.0
        var rangeY = 0.0
        var logBinPerDecadeX = 0.0
        var beginLogDecXAxis = 0.0
        var endLogDecXAxis = 0.0
        var logBinPerDecadeY = 0.0
        var beginLogDecYAxis = 0.0
        var endLogDecYAxis = 0.0
        var rangeToBinFactorX = 0.0
        var rangeToBinFactorY = 0.0
        var xLowLimit = 0.0
        var yLowLimit = 0.0
        var histLimitsX = HistLimits(variate: xVariate)
        histLimitsX = histLimitsDict[xVariate]!
        var histLimitsY = HistLimits(variate: yVariate)
        histLimitsY = histLimitsDict[yVariate]!
        bivHistogramValues = [Int](repeating: 0, count: histRange2P * histRange2P)
        gatedBivHistogramValues = [Int](repeating: 0, count: histRange2P * histRange2P)
        gatedBivHistElementColor = [NSColor](repeating: NSColor.white, count: histRange2P * histRange2P)
        let fastLogicleX = FastLogicle(myVar: xVariate, myAxisType: BivariateTag)
        let fastLogicleY = FastLogicle(myVar: yVariate, myAxisType: BivariateTag)
        let hyperlogX = Hyperlog(myVar: xVariate, myAxisType: BivariateTag)
        let hyperlogY = Hyperlog(myVar: yVariate, myAxisType: BivariateTag)
        
        srand48(17) // Seed function for drand48(), random Double [0.0,1.0]
        switch histLimitsX.xAxisType { // x-axis setup
        case LinearTag:
            rangeX = histLimitsX.xMaxLin - histLimitsX.xMinLin
            if rangeX > 0.0 {
                rangeToBinFactorX = Double(histRange2P) / rangeX
            }
            else { // Failed
                rangeToBinFactorX = 0.0
                print("bivariateHistogram.rangeX = 0.0")
                return false
            }
        case LogTag:
            beginLogDecXAxis = log10(histLimitsX.xMinLog)
            endLogDecXAxis = log10(histLimitsX.xMaxLog)
            let totalLogDecX = endLogDecXAxis - beginLogDecXAxis
            if totalLogDecX <= 0.0 {
                print("bivariateHistogram.totalLogDecX <= 0.0")
                return false
            }
            logBinPerDecadeX = Double(histRange2P) / totalLogDecX
        case HyperlogTag:
            var temp = Double(0.0)
            xLowLimit = hyperlogX.inverseWithScale(&temp)
        case LogicleTag, AsinhTag:
            xLowLimit = fastLogicleX.inverseWithScale(0.0)
        default:
            break
        } // End of switch histLimitsX.xAxisType
        
        switch histLimitsY.xAxisType { // y-axis setup
        case LinearTag:
            rangeY = histLimitsY.xMaxLin - histLimitsY.xMinLin
            if rangeY > 0.0 {
                rangeToBinFactorY = Double(histRange2P) / rangeY
            }
            else { // Failed
                rangeToBinFactorY = 0.0
                print("bivariateHistogram.rangeY = 0.0")
                return false
            }
        case LogTag:
            beginLogDecYAxis = log10(histLimitsY.xMinLog)
            endLogDecYAxis = log10(histLimitsY.xMaxLog)
            let totalLogDecY = endLogDecYAxis - beginLogDecYAxis
            if totalLogDecY <= 0.0 {
                print("bivariateHistogram.totalLogDecY <= 0.0")
                return false
            }
            logBinPerDecadeY = Double(histRange2P) / totalLogDecY
        case HyperlogTag:
            var temp = Double(0.0)
            yLowLimit = hyperlogY.inverseWithScale(&temp)
        case LogicleTag, AsinhTag:
            yLowLimit = fastLogicleY.inverseWithScale(0.0)
        default:
            break
        } // End of switch histLimitsY.xAxisType
        
        for event in 1...fcs!.totalEvents { // Bivariate histogram generation
            // x-axis bin value for bivariate histogram
            linValueX = Double(fcs!.fData[event][xVariate])
            if fcs?.dataType == "I" {
                linValueX += drand48() // [0.0, 1.0]
            }
            switch histLimitsX.xAxisType {
            case LinearTag:
                binX = Int(floor(rangeToBinFactorX * (linValueX - histLimitsX.xMinLin)))
            case LogTag:
                linValueX *= pow(10.0, -beginLogDecXAxis)
                if linValueX <= 0.0 {
                    binX = 0
                }
                else {
                    binX = Int(floor(logBinPerDecadeX * log10(linValueX)))
                }
            case HyperlogTag:
                if linValueX < xLowLimit {
                    linValueX = xLowLimit
                }
                if linValueX >= histLimitsX.T {
                    linValueX = histLimitsX.T - 1.0
                }
                binX = Int(hyperlogX.intScaleWithValue(linValueX))
            case LogicleTag, AsinhTag:
                if linValueX < xLowLimit {
                    linValueX = xLowLimit
                }
                if linValueX >= histLimitsX.T {
                    linValueX = histLimitsX.T - 1.0
                }
                binX = Int(fastLogicleX.intScaleWithValue(linValueX))
            default:
                break
            } // End of switch histLimitsX.xAxisType
            if binX > histRange2P - 1 {
                binX = histRange2P - 1
            }
            if binX < 0 {
                binX = 0
            }
            // End of x-axis bin value for bivariate histogram
            
            linValueY = Double(fcs!.fData[event][yVariate]) // y-axis bin value for bivariate histogram
            if fcs?.dataType == "I" {
                linValueY += drand48() // [0.0, 1.0]
            }
            switch histLimitsY.xAxisType {
            case LinearTag:
                binY = Int(floor(rangeToBinFactorY * (linValueY - histLimitsY.xMinLin)))
            case LogTag:
                linValueY *= pow(10.0, -beginLogDecYAxis)
                if linValueY <= 0.0 {
                    binY = 0
                }
                else {
                    binY = Int(floor(logBinPerDecadeY * log10(linValueY)))
                }
            case HyperlogTag:
                if linValueY < yLowLimit {
                    linValueY = yLowLimit
                }
                if linValueY >= histLimitsY.T {
                    linValueY = histLimitsY.T - 1.0
                }
                binY = Int(hyperlogY.intScaleWithValue(linValueY))
            case LogicleTag, AsinhTag:
                if linValueY < yLowLimit {
                    linValueY = yLowLimit
                }
                if linValueY >= histLimitsY.T {
                    linValueY = histLimitsY.T - 1.0
                }
                binY = Int(fastLogicleY.intScaleWithValue(linValueY))
            default:
                break
            } // End of switch histLimitsY.xAxisType
            if binY > histRange2P - 1 {
                binY = histRange2P - 1
            }
            if binY < 0 {
                binY = 0
            } // End of y-axis bin value for bivariate histogram
            
            indexBin = binX * histRange2P + binY
            bivHistogramValues[indexBin] += 1 // ungated bivariate histogram updated
            bivariateHistogramCount += 1
            
            if gated == true {
                if mainVC!.gatedEvent[event] == -10 { // gated bivariate histogram updated for gate other than quadrant gate.
                    gatedBivHistogramValues[indexBin] += 1 // In BivariateHistogram.swift
                    gatedBivHistElementColor[indexBin] = NSColor.magenta
                    gatedBivariateHistogramCount += 1
                } else if mainVC!.gatedEvent[event] >= 1 { // gated bivariate histogram updated for quadrant gate.
                    gatedBivHistogramValues[indexBin] += 1 // In BivariateHistogram.swift
                    gatedBivHistElementColor[indexBin] = mainVC!.colors[mainVC!.gatedEvent[event]]
                    gatedBivariateHistogramCount += 1
                }
            }
        } // End of for event in 1...fcs!.totalEvents
        
        var index = 0 // Find highest point in bivHistogramValues array
        peak = 0
        for binX in 0..<histRange2P {
            for binY in 0..<histRange2P {
                index = binX * histRange2P + binY
                if bivHistogramValues[index] > peak {
                    peak = bivHistogramValues[index]
                    xPeak = binX
                    yPeak = binY
                }
            } // End of loop over binY
        } // End of loop over binX
        return true
    } // End of bivariateHistogram
    
    // MARK: - setPreferences *****************************
    
    /// setPreferences. Called from convenience init to set preferences that may be used by bivariate histograms.
    func setPreferences() {
        let defaults = UserDefaults.standard
        countThreshold = defaults.integer(forKey: Preferences.CountThresholdKey)
        histRange1P = defaults.integer(forKey: Preferences.HistRange1PKey)
        histRange2P = defaults.integer(forKey: Preferences.HistRange2PKey)
        doCompensation = defaults.bool(forKey: Preferences.DoCompensationKey)
        logLikeScaleTransform = defaults.integer(forKey: Preferences.LogLikeScaleTransformKey)
        switch logLikeScaleTransform {
        case 0: // Logicle
            T = defaults.double(forKey: Preferences.LogicleTKey)
            W = defaults.double(forKey: Preferences.LogicleWKey)
            M = defaults.double(forKey: Preferences.LogicleMKey)
            A = defaults.double(forKey: Preferences.LogicleAKey)
        case 1: // Asinh
            T = defaults.double(forKey: Preferences.AsinhTKey)
            W = defaults.double(forKey: Preferences.AsinhWKey)
            M = defaults.double(forKey: Preferences.AsinhMKey)
            A = defaults.double(forKey: Preferences.AsinhAKey)
        case 2: // Hyperlog
            T = defaults.double(forKey: Preferences.HyperlogTKey)
            W = defaults.double(forKey: Preferences.HyperlogWKey)
            M = defaults.double(forKey: Preferences.HyperlogMKey)
            A = defaults.double(forKey: Preferences.HyperlogAKey)
        default:
            break
        }
    } // End of setPreferences
    
} // End of class BivariateHistogram
