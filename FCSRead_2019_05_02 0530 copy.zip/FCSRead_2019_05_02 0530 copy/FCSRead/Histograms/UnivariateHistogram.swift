//
//  UnivariateHistogram.swift generates univariate histograms. GraphicSubview contains a protocol to create a univariate histogram. The protocol is addressed by MainViewController with the function generateUnivariateHistogramWithVariate, which returns a univariate histogram object (uniHist: UnivariateHistogram).
//
//  Created by Mr. Salzman on 12/23/17.
//  Copyright © 2019 Gary Salzman. All rights reserved.
//

import Foundation

class UnivariateHistogram {
    var rangeToBinFactor = 0.0 // Ratio of bin range to data range.
    var histogramValues: [Int] = [] // Counts per bin for an ungated histogram.
    var gatedHistogramValues: [Int] = [] // Counts per bin for a gated histogram.
    var overlayHistogramValues: [Int] = [] // Counts per bin for an overlaid histogram.
    // Next four are set in UnivariateHistogram:setPreferences. See PreferencesViewController.swift
    var countThreshold = 0 // Minimum count in a histogram bin.
    var histRange = 0 // Either 1P or 2P
    var histRange1P = 0
    var histRange2P = 0
    weak var mainVC: MainViewController?
    weak var fcs: ReadAndParse? // 1st file
    weak var fcs2: ReadAndParse? // 2nd file
    var histogramCount = 0 // Total count in a histogram.
    var gatedHistogramCount = 0 // Total count in a gated histogram.
    var overlayHistogramCount = 0 // Total count in an overlay histogram.
    var beginLogDecXAxis = 1.0 // Log decade at beginning of x-axis. **** X-axis
    var endLogDecXAxis = 1.0 // Log decade at end of x-axis.
    var xAxisLabel = UnknownTag
    var xAxisType = UnknownTag // {LinearTag, LogTag, LogicleTag, AsinhTag, HyperlogTag, UnknownTag}
    var xMinLin = 0.0 // Linear value at bottom of scale.
    var xMinLog = 1.0 // Linear value at the bottom of the log part of the scale. For a scale that is entirely log, xMinLin = xMinLog (nonzero). The log decade is log10(xMinLog).
    var xMaxLin = 0.0 // Linear value at the top of the scale.
    var xMaxLog = 1.0 // Linear value at the top of the log part of the scale.
    var xMaxHyperlog = 0.0 // Linear value at the top of the linear portion of the hyperlog scale.
    var logLikeScaleTransform = 0 // Logicle=0, Asinh=1, Hyperlog=2. Loglike histogram display properties
    var T = 300000.0
    var W = 1.0
    var M = 4.5
    var A = 0.0
    var fastLogicle: FastLogicle?
    var hyperlog: Hyperlog?
    var yVariate = 0 // For univariate. Values below are used only for univariate. *** Y-axis
    var beginLogDecYAxis = 1.0
    var endLogDecYAxis = 1.0
    var yAxisLabel = "Count"
    var yAxisType = LinearTag // {LinearTag or LogTag}
    var yMinLin = 0.0
    var yMinLog = 1.0
    var yMaxLin = 0.0
    var yMaxLog = 1.0
    var yMaxHyperlog = 0.0
    var success = false
    
    // MARK: - inits/deinit *****************************
    
    /// init instantiates a univariate histogram. Called by MainViewController.generateUnivariateHistogramWithVariate. This call is triggered by GraphicSubview.delegate.convenience init. Note: univariate: false is used to indicate that BivariateHistogram class is using the Univariate class to compute the initial histogram limits.
    ///
    /// - Parameters:
    ///   - myVariate: x axis variate (y axis is count)
    ///   - mViewController: MainViewController
    ///   - univariate: boolean indicating univariate histogram or not.
    init(myVariate: Int, mViewController: MainViewController, univariate: Bool) {
        setPreferences()
        if univariate == true {histRange = histRange1P} // This is a univariate histogram.
        else {histRange = histRange2P}
        mainVC = mViewController
        fcs = mainVC?.readAndParse
        _ = prepareHistogram(myVariate, secondFile: false)
    } // End of init
    
    deinit {}
    
    // MARK: - Prepare for histogram generation *****************************
    
    /// prepareHistogram prepares a specific type of univariate histogram. Called from init
    ///
    /// - Parameter myVariate: x variate
    /// - Returns: true if univariate histogram is successfully generated.
    func prepareHistogram(_ myVariate: Int, secondFile: Bool) -> Bool { // In UnivariateHistogram.swift
        var myHistLimits = HistLimits(variate: myVariate)
        myHistLimits = histLimitsDict[myVariate]!
        if myHistLimits.xAxisType != UnknownTag {success = true} // myHistLimits exist.
        else {success = calculateHistogramLimits(myVariate)} // myHistLimits have not yet been set.
        if success == true && myHistLimits.yVariate == 0 { // Univariate histogram
            if let mVC = mainVC {
                let dataGated = mVC.isDataGated
                switch myHistLimits.xAxisType {
                case LinearTag:
                    if linearHistogramForVariate(myVariate, myHistLimits: myHistLimits, gated: dataGated, secondFile: secondFile) == false {
                        print("UnivariateHistogram.linearHistogramForVariate failed.")
                    }
                case LogTag:
                    if logHistogramForVariate(myVariate, myHistLimits: myHistLimits, gated: dataGated, secondFile: secondFile) == false {
                        print("UnivariateHistogram.logHistogramForVariate failed.")
                    }
                case LogicleTag, AsinhTag:
                    if logicleHistogramForVariate(myVariate, myHistLimits: myHistLimits, gated:dataGated, secondFile: secondFile) == false {
                        print("UnivariateHistogram.logicleHistogramForVariate failed.")
                    }
                case HyperlogTag:
                    if hyperlogHistogramForVariate(myVariate, myHistLimits: myHistLimits, gated:dataGated, secondFile: secondFile) == false {
                        print("UnivariateHistogram.hyperlogHistogramForVariate failed.")
                    }
                default:
                    break
                }
                histLimitsDict[myVariate] = myHistLimits
            }
        }
        return success
    } // End of prepareHistogram
    
    /// calculateHistogramLimits calculates histogram limits. Called by prepareHistogram.
    ///
    /// - Parameter myVariate: x variate
    /// - Returns: true if histLimits calculated successfully
    func calculateHistogramLimits(_ myVariate: Int) -> Bool {
        print("\ncalculateHistogramLimits_begin")
        var myHistLimits = HistLimits(variate: myVariate)
        myHistLimits = histLimitsDict[myVariate]!
        myHistLimits = initialHistogramLimitsForVariate(myVariate, myHistLimits: myHistLimits) // Finds min and max values for FData[][myVariate] and set myHistLimits.
        var tempHistLimits = HistLimits(variate: myVariate)
        tempHistLimits = myHistLimits
        let currentRange = myHistLimits.xMaxLin - myHistLimits.xMinLin
        if myHistLimits.xMinLin < 0.0 && currentRange > 1.0e03 { // Now set rational x-axis limits and xAxisType. Use Logicle, Asinh, or hyperlog x-axis
            myHistLimits = prepareLogLikeScaleTransformForVariate(myVariate, myHistLimits: myHistLimits) // Sets histLimits.logicleT..., histLimits.asinhT...
            myHistLimits = setLogLikeTWMA(myHistLimits)
        } // End of if myHistLimits.xMinLin < 0.0 && largeRange > 1.0e03
        else if myHistLimits.xMinLin < 0.0 && currentRange <= 1.0e03 {
            myHistLimits.xAxisType = LinearTag
            print("myHistLimits.xMinLin < 0.0 && currentRange <= 1.0e03")
        }
        else { // normal linear or log x-axis (_xMinLin>=0.0)
            myHistLimits.xAxisType = LinearTag // Default to start
            var tempLog = 0.0
            print("myHistLimits.xMinLin >= 0 LinearTag")
            myHistLimits.xMinLin = suggestLowerLimitGivenBottom(myHistLimits.xMinLin)
            if myHistLimits.xMinLin == 0.0 {
                myHistLimits.xMinLog = 1.0
            }
            else { // myHistLimits.xMinLin > 0
                tempLog = floor(log10(myHistLimits.xMinLin))
                myHistLimits.xMinLin = pow(10.0, tempLog)
                myHistLimits.xMinLog = myHistLimits.xMinLin
            }
            print("normal linear or log x-axis")
            myHistLimits.xMaxLin = suggestUpperLimitGivenTop(myHistLimits.xMaxLin)
            myHistLimits.xMaxLog = tempHistLimits.xMaxLin
            if log10(myHistLimits.xMaxLog) - log10(myHistLimits.xMinLog) > 1.1 {
                myHistLimits.xAxisType = LogTag // Log chosen
            }
            if fcs?.PnN[myVariate] == "TIME" || fcs?.PnN[myVariate] == "EVENT" { // Exception for "TIME" or "EVENT" variate.
                myHistLimits.xAxisType = LinearTag
            }
        } // End of else for normal linear or log x-axis
        
        histLimitsDict[myVariate] = myHistLimits
        return true
        
    } // End of calculateHistogramLimits
    
    /// initialHistogramLimitsForVariate calculates initial values for histogram limmits.
    ///
    /// - Parameters:
    ///   - myVariate: x variate
    ///   - myHistLimits: histLimits
    func initialHistogramLimitsForVariate(_ myVariate: Int, myHistLimits: HistLimits) -> HistLimits {  // Finds min and max values for FData[][myVariate] and set myHistLimits.
        fcs!.extremeValuesForVariate(myVariate) // Get mostNegativeValue (or smallest) and mostPositiveValue for the variate
        myHistLimits.xMinLin = fcs!.mostNegativeValue[myVariate] // extreme initial values.
        myHistLimits.xMaxLin = fcs!.mostPositiveValue[myVariate]
        if linearHistogramForVariate(myVariate, myHistLimits: myHistLimits, gated: false, secondFile: false) == false { // Initial histogram only.
            print("UnivariateHistogram.calculateHistogramLimits.linearHistogramForVariate failed. Exiting...")
            exit(-1)
        }
        var threshold = countThreshold // Uses full range above (mostNegative and mostPositive).
        var binLow = 0 // bin limits for truncated histogram
        var binHigh = 0
        var k = 0 // Find boundaries for linear histogram. Set histogram boundaries where the threshold is countThreshold. myHistogramBinRange is set to histRange.
        var threshOK = false // Assume no histogramValue[] exceeds threshold. Start at top of histogram and find upper limit first.
        while threshOK == false { // Loop until histogramValues[k] >= threshold
            k = histRange - 1
            while histogramValues[k] < threshold && k > 1 {
                k -= 1 // Step toward bottom of histogram
            }
            if histogramValues[k] >= threshold {
                threshOK = true
            }
            else { // Got to end without exceeding threshold. Halve threshold and try again.
                threshold /= 2
                if threshold < 1 {
                    print("Too few counts in histogram. Exiting...")
                    exit(-1)
                }
            }
        } // End of loop while threshOK == false
        binHigh = k // Upper boundary for linear histogram.
        myHistLimits.xMaxLin = (Double(binHigh) / rangeToBinFactor) + myHistLimits.xMinLin
        
        threshold = countThreshold // Reset to initial value. Find lower boundary for linear histogram. ********
        k = 0
        while histogramValues[k] < threshold && k < binHigh {
            k += 1 // Move up the histogram until theshold exceeded or we reach the top.
        }
        binLow = k // Lower channel boundary for histogram.
        myHistLimits.xMinLin += (Double(binLow) / rangeToBinFactor)
        print("initialHistogramLimitsForVariate: xMinLin, xMaxLin")
        myHistLimits.xMinLin = suggestLowerLimitGivenBottom(myHistLimits.xMinLin) // First cut at proper lower and upper limits.
        myHistLimits.xMaxLin = suggestUpperLimitGivenTop(myHistLimits.xMaxLin)
        if (myHistLimits.xMinLin == myHistLimits.xMaxLin) {
            print("UnivariateHistogram.calculateHistogramLimits failed. xMinLin = xMaxLin. Exiting...")
            exit(-1)
        }
        return myHistLimits
    } // End of initialHistogramLimitsForVariate
    
    /// prepareLogLikeScaleTransformForVariate. Called from calculateHistogramLimits. Update log-like parameters, e.g., histLimits.logicleW, etc. based on just calculated values of iVars _xMinLin, _xMaxLin. Called by calcHistogramLimitsForVariate(above) afterlinear histogram has been generated.
    ///
    /// - Parameters:
    ///   - myVariate: x variate
    ///   - myHistLimits: histLimits
    /// - Returns: recalculated histLimits
    func prepareLogLikeScaleTransformForVariate(_ myVariate: Int, myHistLimits: HistLimits) -> HistLimits{
        var r = 0.0 // Calculate myHistLimits.logicleT,W,M,A parameters for Logicle display.
        print("prepareLogLikeScaleTransformForVariate")
        myHistLimits.logicleT = suggestUpperLimitGivenTop(Double(fcs!.PnR[myVariate])) // histLimits.logicleM and histLimits.logicleA set with standardUserDefaults in init for HistLimits.
        if let fcsTemp = fcs { // Calculate 5th percentile of negative range, if it is present. *****
            r = fcsTemp.rValueForNegativeRange(myVariate)
        }
        if r == 0.0 { // r Calculation failed so make educated guess for W.
            myHistLimits.logicleW = 0.75
        }
        else { // Calculate histLimits.logicleW using histLimits.logicleM and |r|
            myHistLimits.logicleW = 0.05 * (myHistLimits.logicleM - log10(myHistLimits.logicleT / abs(r)))
        }
        if myHistLimits.logicleW < 0.1 { // Note: Limits below keep things on scale; change with Change Axes (right click).
            myHistLimits.logicleW = 0.7 // was 0.5
        }
        if myHistLimits.logicleW > 0.5 * myHistLimits.logicleM {
            myHistLimits.logicleW = 0.5 * myHistLimits.logicleM
        }
        myHistLimits.asinhT = myHistLimits.logicleT // Calculate _histLimits.asinhT,W,M,A parameters for Asinh display. The only difference is that myHistLimits.asinhW = 0.0
        myHistLimits.asinhW = 0.0
        myHistLimits.asinhM = myHistLimits.logicleM
        myHistLimits.asinhA = myHistLimits.logicleA
        myHistLimits.hyperlogT = myHistLimits.logicleT // Calculate myHistLimits.hyperlogT,W,M,A parameters for Hyperlog display.
        myHistLimits.hyperlogW = myHistLimits.logicleW
        myHistLimits.hyperlogM = myHistLimits.logicleM
        myHistLimits.hyperlogA = myHistLimits.logicleA
        return myHistLimits
    } // End of prepareLogLikeScaleTransformForVariate
    
    /// setLogLikeTWMA. Called from calculateHistogramLimits. Sets .T,.W,.M and .A in myHistLimits.
    ///
    /// - Parameter myHistLimits: initial histLimits
    /// - Returns: updated histLimits
    func setLogLikeTWMA(_ myHistLimits: HistLimits) -> HistLimits {
        let defaults = UserDefaults.standard
        myHistLimits.logLikeScaleTransform = defaults.integer(forKey: Preferences.LogLikeScaleTransformKey)
        switch myHistLimits.logLikeScaleTransform
        {
        case 0: // Logicle
            let fastLogicle = FastLogicle(inputT: myHistLimits.logicleT, inputW: myHistLimits.logicleW, inputM: myHistLimits.logicleM, inputA: myHistLimits.logicleA, inputBins: histRange)
            myHistLimits.T = myHistLimits.logicleT // From prepareLogLikeScale...
            myHistLimits.W = myHistLimits.logicleW
            myHistLimits.M = myHistLimits.logicleM
            myHistLimits.A = myHistLimits.logicleA
            myHistLimits.xMinLin = fastLogicle.inverseWithScale(0.0)
            myHistLimits.xMinLog = 1.0 // Not used.
            myHistLimits.xMaxLin = myHistLimits.logicleT
            myHistLimits.xMaxLog = myHistLimits.xMaxLin
            myHistLimits.xAxisType = LogicleTag
        case 1: // Asinh
            let fastLogicle = FastLogicle(inputT: myHistLimits.logicleT, inputW: myHistLimits.logicleW, inputM: myHistLimits.logicleM, inputA: myHistLimits.logicleA, inputBins: histRange)
            myHistLimits.T = myHistLimits.asinhT
            myHistLimits.W = myHistLimits.asinhW
            myHistLimits.M = myHistLimits.asinhM
            myHistLimits.A = myHistLimits.asinhA
            myHistLimits.xMinLin = fastLogicle.inverseWithScale(0.0)
            myHistLimits.xMinLog = 1.0 // Not used.
            myHistLimits.xMaxLin = myHistLimits.asinhT
            myHistLimits.xMaxLog = myHistLimits.xMaxLin
            myHistLimits.xAxisType = AsinhTag
        case 2: // Hyperlog
            let hyperlog = Hyperlog(inputT: myHistLimits.logicleT, inputW: myHistLimits.logicleW, inputM: myHistLimits.logicleM, inputA: myHistLimits.logicleA, inputBins: histRange)
            myHistLimits.T = myHistLimits.hyperlogT
            myHistLimits.W = myHistLimits.hyperlogW
            myHistLimits.M = myHistLimits.hyperlogM
            myHistLimits.A = myHistLimits.hyperlogA
            var temp1 = 0.0
            myHistLimits.xMinLin = hyperlog.inverseWithScale(&temp1)
            myHistLimits.xMinLog = 1.0 // Not used.
            myHistLimits.xMaxLin = myHistLimits.hyperlogT
            myHistLimits.xMaxLog = myHistLimits.xMaxLin
            myHistLimits.xAxisType = HyperlogTag
        default:
            myHistLimits.T = 300000.0
            myHistLimits.W = 1.0
            myHistLimits.M = 4.5
            myHistLimits.A = 0.0
        } // End of switch histLimits!.logLikeScaleTransform
        return myHistLimits
    } // End of setLogLikeTWMA
    
    // MARK: - Histogram generation *****************************
    
    /// hyperlogHistogramForVariate generates univariate histogram with hyperlog x-axis.
    ///
    /// - Parameters:
    ///   - myVariate: x variate
    ///   - myHistLimits: histLimits
    ///   - gated: boolean indicating whether histogram is gated or not
    /// - Returns: true if histogram successfully generated
    func hyperlogHistogramForVariate(_ myVariate: Int, myHistLimits: HistLimits, gated: Bool, secondFile: Bool) -> Bool {
        let hyperlog = Hyperlog(inputT: myHistLimits.T, inputW: myHistLimits.W, inputM: myHistLimits.M, inputA: myHistLimits.A, inputBins: histRange)
        var bin = 0 // histogram bin number [0->myHistRange-1)
        var xValue = 0.0 // value converted to bin number. xValue <= 0 OK.
        var temp1 = 0.0
        let xLowLimit = hyperlog.inverseWithScale(&temp1)
        srand48(17) // Seed function for drand48(), random Double [0.0,1.0]
        histogramValues = [Int](repeating: 0, count: histRange)
        gatedHistogramValues = [Int](repeating: 0, count: histRange)
        overlayHistogramValues = [Int](repeating: 0, count: histRange)
        histogramCount = 0
        gatedHistogramCount = 0
        overlayHistogramCount = 0
        for event in 1...fcs!.totalEvents {
            xValue = fcs!.fData[event][myVariate]
            if fcs!.dataType == "I" {
                xValue += drand48() // [0.0, 1.0]
            } // End of dataType == "I"
            if xValue <= xLowLimit {
                xValue = xLowLimit + 1.0
            }
            else if xValue >= myHistLimits.T {
                xValue = myHistLimits.T - 1.0
            }
            bin = Int(hyperlog.intScaleWithValue(xValue))
            if bin < 0 {
                bin = 0
            }
            if bin > histRange - 1 {
                bin = histRange - 1
            }
            if gated == true && mainVC!.gatedEvent[event] == -10 { // Event is included in gate.
                gatedHistogramValues[bin] += 1
                gatedHistogramCount += 1
            }
            histogramValues[bin] += 1 // Do add one at bin
            histogramCount += 1
            
        } // End of loop over events
        
        if secondFile == true {
            fcs2 = mainVC?.readAndParse2
            for event in 1...fcs2!.totalEvents {
                xValue = fcs2!.fData[event][myVariate]
                if fcs!.dataType == "I" {
                    xValue += drand48() // [0.0, 1.0]
                } // End of dataType == "I"
                if xValue <= xLowLimit {
                    xValue = xLowLimit + 1.0
                }
                else if xValue >= myHistLimits.T {
                    xValue = myHistLimits.T - 1.0
                }
                bin = Int(hyperlog.intScaleWithValue(xValue))
                if bin < 0 {
                    bin = 0
                }
                if bin > histRange - 1 {
                    bin = histRange - 1
                }
                overlayHistogramValues[bin] += 1 // Do add one at bin
                overlayHistogramCount += 1
                
            } // End of loop over events
        } // End of secondFile == true
        
        if myHistLimits.yAutoScale == true {
            if yHistogramLimit(myVariate) == false { // Calculate histLimits!.(yMinLin, yMaxLin, yMinLog, yMaxLog)
                print("UnivariateHistogram.yHistogramLimit failed.")
            }
        }
        if fcs!.dataType == "I" { // Smooth data collected as integers. 5 pt moving average filter
            if gated == true {
                gatedHistogramValues = mavFilterForHistogram(gatedHistogramValues)
            }
            if secondFile == true {
                overlayHistogramValues = mavFilterForHistogram(overlayHistogramValues)
            }
            histogramValues = mavFilterForHistogram(histogramValues)
        }
        if myHistLimits.yAxisType == LogTag {
            if convertYAxisToLog(myVariate) == false {
                print("UnivariateHistogram.convertYAxisToLog failed.")
                return false
            }
        }
        return true
        
    } // End of hyperlogHistogramForVariate
    
    /// linearHistogramForVariate. Compute linear histogram using fcs data and the histogram limits, histLimits.xMinLin and histLimits.xMaxLin. Called from prepareHistogram.
    ///
    /// - Parameters:
    ///   - myVariate: x variate
    ///   - myHistLimits: histLimits
    ///   - gated: true if histogram is gated
    /// - Returns: true if histogram successfully generated
    func linearHistogramForVariate(_ myVariate: Int, myHistLimits: HistLimits, gated: Bool, secondFile: Bool) -> Bool {
        var bin = 0 // histogram bin number [0,histRange) // histRange = histRange1P or histRange2P
        var range = 0.0 // actual data range.
        var xValue = 0.0 // data value converted to bin number. xValue <= 0 OK.
        srand48(17) // Seed function for drand48(), random Double [0.0,1.0]
        range = myHistLimits.xMaxLin - myHistLimits.xMinLin // Calculated full data range. xMinLin and xMaxLin are most negative and most positive fData values in the fcs file when doing the linear histogram for the first time.
        if range != 0.0 { // range to bin conversion.
            rangeToBinFactor = Double(histRange) / range
        } else {
            print("linearHistogramForVariate \(myVariate) has zero range.")
            return false
        }
        histogramValues = [Int](repeating: 0, count: histRange)
        gatedHistogramValues = [Int](repeating: 0, count: histRange)
        overlayHistogramValues = [Int](repeating: 0, count: histRange)
        histogramCount = 0
        gatedHistogramCount = 0
        overlayHistogramCount = 0
        for event in 1...fcs!.totalEvents { // Generate linear histogram
            xValue = fcs!.fData[event][myVariate]
            if fcs!.dataType == "I" {
                xValue += drand48() // [0.0, 1.0]
            }
            bin = Int(floor(rangeToBinFactor * (xValue - myHistLimits.xMinLin)))
            if bin > histRange - 1 {
                bin = histRange - 1
            }
            else if bin < 0 {
                bin = 0
            }
            histogramValues[bin] += 1 // do add one at bin
            histogramCount += 1
            if gated == true && mainVC!.gatedEvent[event] == -10 { // Event is included in gate.
                gatedHistogramValues[bin] += 1
                gatedHistogramCount += 1
            }
        } // Initial histogram generated. End of loop over events
        
        if secondFile == true {
            fcs2 = mainVC!.readAndParse2
            for event in 1...fcs2!.totalEvents { // Generate linear histogram
                xValue = fcs2!.fData[event][myVariate]
                if fcs2!.dataType == "I" {
                    xValue += drand48() // [0.0, 1.0]
                }
                bin = Int(floor(rangeToBinFactor * (xValue - myHistLimits.xMinLin)))
                if bin > histRange - 1 {
                    bin = histRange - 1
                }
                else if bin < 0 {
                    bin = 0
                }
                overlayHistogramValues[bin] += 1 // do add one at bin
                overlayHistogramCount += 1
            } // Overlay histogram generated. End of loop over events
        }
        if myHistLimits.yAutoScale == true {
            print("UniHist.linearHistogramForVariate")
            if yHistogramLimit(myVariate) == false { // Calculate myHistLimits.(yMinLin, yMaxLin, yMinLog, yMaxLog)
                print("UnivariateHistogram.yHistogramLimit failed. - exiting")
                exit(-1)
            }
        }
        if fcs!.dataType == "I" { // 5 pt moving average filter. // Smooth data collected as integers
            if gated == true {
                gatedHistogramValues = mavFilterForHistogram(gatedHistogramValues)
            }
            if secondFile == true {
                overlayHistogramValues = mavFilterForHistogram(overlayHistogramValues)
            }
            histogramValues = mavFilterForHistogram(histogramValues)
        }
        if myHistLimits.yAxisType == LogTag { // UnivariateHistogram.linearHistogramForVariate. Transform histogram y-axis to log scale.
            if convertYAxisToLog(myVariate) == false {
                print("UnivariateHistogram.convertYAxisToLog failed.")
            }
        }
        return true
    } // End of linearHistogramForVariate
    
    /// logHistogramForVariate generates a univariate log histogram
    ///
    /// - Parameters:
    ///   - myVariate: x variate
    ///   - myHistLimits: histLimits
    ///   - gated: true if univariate log histogam is gated.
    /// - Returns: true if univariate log histogram is successfully generated.
    func logHistogramForVariate(_ myVariate: Int, myHistLimits: HistLimits, gated: Bool, secondFile: Bool) -> Bool {
        var logBin = 0
        var linValue = 0.0
        srand48(17) // Seed function for drand48(), random Double [0.0,1.0]
        histogramValues = [Int](repeating: 0, count: histRange)
        gatedHistogramValues = [Int](repeating: 0, count: histRange)
        overlayHistogramValues = [Int](repeating: 0, count: histRange)
        histogramCount = 0
        gatedHistogramCount = 0
        overlayHistogramCount = 0
        beginLogDecXAxis = log10(myHistLimits.xMinLog)
        endLogDecXAxis = log10(myHistLimits.xMaxLog)
        let totalLogDecX = endLogDecXAxis - beginLogDecXAxis
        if totalLogDecX <= 0.0 {
            print("No log histogram for variate \(myVariate)")
            return false
        }
        let logBinPerDecade = Double(histRange) / totalLogDecX
        for event in 1...fcs!.totalEvents { // Generate log histogram
            linValue = fcs!.fData[event][myVariate]
            if fcs!.dataType == "I" {
                linValue += drand48() // [0.0, 1.0]
            } // End of dataType == "I"
            linValue *= pow(10.0, -beginLogDecXAxis)
            if linValue <= 0.0 {logBin = 0}
            else {logBin = Int(floor(logBinPerDecade * log10(linValue)))}
            if logBin < 0 {logBin = 0}
            if logBin > histRange - 1 {logBin = histRange - 1}
            histogramValues[logBin] += 1 // do add one at bin
            histogramCount += 1
            if gated == true && mainVC!.gatedEvent[event] == -10 { // Event is included in gate.
                gatedHistogramValues[logBin] += 1
                gatedHistogramCount += 1
            }
        } // End of loop over events
        
        if secondFile == true {
            fcs2 = mainVC?.readAndParse2
            for event in 1...fcs2!.totalEvents { // Generate log histogram
                linValue = fcs2!.fData[event][myVariate]
                if fcs2!.dataType == "I" {
                    linValue += drand48() // [0.0, 1.0]
                } // End of dataType == "I"
                linValue *= pow(10.0, -beginLogDecXAxis)
                if linValue <= 0.0 {logBin = 0}
                else {logBin = Int(floor(logBinPerDecade * log10(linValue)))}
                if logBin < 0 {logBin = 0}
                if logBin > histRange - 1 {logBin = histRange - 1}
                overlayHistogramValues[logBin] += 1 // do add one at bin
                overlayHistogramCount += 1
            } // End of loop over events
        } // End of secondFile == true
        
        if myHistLimits.yAutoScale == true {
            print("UniHist.logHistogramForVariate")
            if yHistogramLimit(myVariate) == false { // Calculate histLimits!.(yMinLin, yMaxLin, yMinLog, yMaxLog)
                print("UnivariateHistogram.yHistogramLimit failed. - exiting")
                exit(-1)
            }
        }
        if fcs!.dataType == "I" { // 5 pt moving average filter. Smooth data collected as integers
            if gated == true {
                gatedHistogramValues = mavFilterForHistogram(gatedHistogramValues)
            }
            if secondFile == true {
                overlayHistogramValues = mavFilterForHistogram(overlayHistogramValues)
            }
            histogramValues = mavFilterForHistogram(histogramValues)
            
        }
        if myHistLimits.yAxisType == LogTag {
            if convertYAxisToLog(myVariate) == false {
                print("UnivariateHistogram.convertYAxisToLog failed. - exiting")
                exit(-1)
            }
        }
        return true
    } // End of logHistogramForVariate
    
    /// logicleHistogramForVariate generates univariate logicle histogram
    ///
    /// - Parameters:
    ///   - myVariate: x variate
    ///   - myHistLimits: histLimits
    ///   - gated: true if univariate logicle histogram is gated.
    /// - Returns: true if histogram is successfully generated
    func logicleHistogramForVariate(_ myVariate: Int, myHistLimits: HistLimits, gated: Bool, secondFile: Bool) -> Bool {
        let fastLogicle = FastLogicle(inputT: myHistLimits.T, inputW: myHistLimits.W, inputM: myHistLimits.M, inputA: myHistLimits.A, inputBins: histRange)
        var bin = 0 // histogram bin number [0->myHistRange-1)
        var xValue = 0.0 // value converted to bin number. xValue <= 0 OK.
        let xLowLimit = fastLogicle.inverseWithScale(0.0)
        srand48(17) // Seed function for drand48(), random Double [0.0,1.0]
        histogramValues = [Int](repeating: 0, count: histRange)
        gatedHistogramValues = [Int](repeating: 0, count: histRange)
        overlayHistogramValues = [Int](repeating: 0, count: histRange)
        histogramCount = 0
        gatedHistogramCount = 0
        overlayHistogramCount = 0
        for event in 1...fcs!.totalEvents {
            xValue = fcs!.fData[event][myVariate]
            if fcs!.dataType == "I" {
                xValue += drand48() // [0.0, 1.0]
            } // End of dataType == "I"
            if xValue <= xLowLimit {
                xValue = xLowLimit + 1.0
            } else if xValue >= myHistLimits.T {
                xValue = myHistLimits.T - 1.0
            }
            bin = Int(fastLogicle.intScaleWithValue(xValue))
            if bin < 0 {bin = 0}
            if bin > histRange - 1 {bin = histRange - 1}
            if gated == true && mainVC!.gatedEvent[event] == -10 { // Event is included in gate.
                gatedHistogramValues[bin] += 1
                gatedHistogramCount += 1
            }
            histogramValues[bin] += 1 // Do add one at bin
            histogramCount += 1
        } // End of loop over events
        
        if secondFile == true {
            fcs2 = mainVC?.readAndParse2
            for event in 1...fcs2!.totalEvents {
                xValue = fcs2!.fData[event][myVariate]
                if fcs2!.dataType == "I" {
                    xValue += drand48() // [0.0, 1.0]
                } // End of dataType == "I"
                if xValue <= xLowLimit {
                    xValue = xLowLimit + 1.0
                } else if xValue >= myHistLimits.T {
                    xValue = myHistLimits.T - 1.0
                }
                bin = Int(fastLogicle.intScaleWithValue(xValue))
                if bin < 0 {bin = 0}
                if bin > histRange - 1 {bin = histRange - 1}
                overlayHistogramValues[bin] += 1 // Do add one at bin
                overlayHistogramCount += 1
            } // End of loop over events
        } // End of secondFile == true
        
        if myHistLimits.yAutoScale == true {
            print("UniHist.logicleHistogramForVariate")
            if yHistogramLimit(myVariate) == false { // Calculate histLimits!.(yMinLin, yMaxLin, yMinLog, yMaxLog)
                print("UnivariateHistogram.yHistogramLimit failed.")
            }
        }
        if fcs!.dataType == "I" { // 5 pt moving average filter. Smooth data collected as integers
            if gated == true {
                gatedHistogramValues = mavFilterForHistogram(gatedHistogramValues)
            }
            if secondFile == true {
                overlayHistogramValues = mavFilterForHistogram(overlayHistogramValues)
            }
            histogramValues = mavFilterForHistogram(histogramValues)
        }
        if myHistLimits.yAxisType == LogTag {
            if convertYAxisToLog(myVariate) == false {
                print("UnivariateHistogram.convertYAxisToLog failed.")
            }
        }
        return true
    } // End of logicleHistogramForVariate
    
    // MARK: - *** Support functions ***
    
    /// yHistogramLimit. Called only if myHistLimits.yAutoScale == true. Only for y-axis on univariate histograms. Called from the various ...HistogramForVariate. Note: bins [0,kMin) are ignored in finding myHistLimits!.yMaxLin.
    ///
    /// - Parameter myVariate: x variate
    /// - Returns: true if successful
    func yHistogramLimit(_ myVariate: Int) -> Bool {
        var myHistLimits = HistLimits(variate: myVariate)
        myHistLimits = histLimitsDict[myVariate]!
        let kMin = 2 // Arbitrary cutoff to avoid counting piled up events below x = kMin.
        var maxCount = 0
        for k in kMin..<histRange - 2 {
            maxCount = Int(max(maxCount, histogramValues[k]))
        }
        print("yHistogramLimit")
        myHistLimits.yMaxLin = suggestUpperLimitGivenTop(Double(maxCount))
        myHistLimits.yMinLin = 0.0 // Default value.
        myHistLimits.yMinLog = 1.0
        myHistLimits.yMaxLog = myHistLimits.yMaxLin
        histLimitsDict[myVariate] = myHistLimits
        return true
    } // End of yHistogramLimit
    
    
    /// convertYAxisToLog converts y-axis histogram data to log scale
    ///
    /// - Parameter myVariate: x variate
    /// - Returns: true if successful
    func convertYAxisToLog(_ myVariate: Int) -> Bool {
        var myHistLimits = HistLimits(variate: myVariate)
        myHistLimits = histLimitsDict[myVariate]!
        var logValue = 0.0 // log equivalent of histogramValues[k]
        if myHistLimits.yMinLog == 0.0 {myHistLimits.yMinLog = 1.0}
        beginLogDecXAxis = Double(log10(myHistLimits.yMinLog))
        if myHistLimits.yMaxLog == 0.0 {
            myHistLimits.yMaxLog = 1.0
        }
        endLogDecXAxis = Double(log10(myHistLimits.yMaxLog))
        let totalLogDecY = endLogDecXAxis - beginLogDecXAxis
        if totalLogDecY <= 0.0 { // fail
            print("UnivariateHistogram.yHistogramLimit: totalLogDecY <= 0.0")
            return false
        } else { // success
            let logValuePerDecade = (myHistLimits.yMaxLog - myHistLimits.yMinLog) / totalLogDecY
            for k in 0 ..< histRange {
                if histogramValues[k] <= 1 {logValue = 0.0}
                else {logValue = logValuePerDecade * log10(Double(histogramValues[k]))}
                histogramValues[k] = Int(logValue)
            }
            if mainVC!.isDataGated == true {
                for k in 0 ..< histRange {
                    if gatedHistogramValues[k] <= 1 {logValue = 0.0}
                    else {logValue = logValuePerDecade * log10(Double(gatedHistogramValues[k]))}
                    gatedHistogramValues[k] = Int(logValue)
                }
            }
//            if openFileCount > 1 { // 2nd file
//                for k in 0 ..< histRange {
//                    if overlayHistogramValues[k] <= 1 {logValue = 0.0}
//                    else {logValue = logValuePerDecade * log10(Double(overlayHistogramValues[k]))}
//                    overlayHistogramValues[k] = Int(logValue)
//                }
//            }
        } // End of success
        myHistLimits.yAxisType = LogTag
        histLimitsDict[myVariate] = myHistLimits
        return true
    } // End of convertYAxisToLog
    
    
    /// mavFilterForHistogram. Moving average filter with nPoint points (nPoint = 3 or 5 only) Adapted from Bevington and Robinson, Data Reduction and Error Analysis for the Physical Sciences, 2nd ed, McGraw-Hill, 1992,p.237. 5 point moving average filter.
    ///
    /// - Parameter histValues: integer array of histogram values
    /// - Returns: smoothed integer array of histogram values
    func mavFilterForHistogram(_ histValues: [Int]) -> [Int] {
        let histLength = Int(histValues.count)
        var y = [Double](repeating: 0.0, count: histLength)
        y[0] = 0.5 * Double(histValues[0] + histValues[1])
        y[1] = y[0]
        y[histLength - 1] = 0.5 * Double(histValues[histLength - 2] + histValues[histLength - 1])
        y[histLength - 2] = y[histLength - 1]
        for i in 2 ..< histLength - 2 {
            y[i] = 0.0625 * Double(histValues[i - 2]) + 0.25 * Double(histValues[i - 1])
            y[i] += 0.375 * Double(histValues[i]) + 0.25 * Double(histValues[i + 1])
            y[i] += 0.0625 * Double(histValues[i + 2])
        }
        var histSmoothed = [Int](repeating: 0, count: histLength)
        for i in 0..<histLength {
            histSmoothed[i] = Int(y[i])
        }
        return histSmoothed
    } // End of mavFilterForHistogram
    
    
    /// suggestHyperlogLowerLimitGivenBottom calculates the lower bound for a univariate hyperlog histogram
    ///
    /// - Parameter bottom: input bottom value
    /// - Returns: suggested bottom value
    func suggestHyperlogLowerLimitGivenBottom(_ bottom: Double) -> Double {
        print("suggestHyperlogLowerLimitGivenBottom")
        var temp = -bottom // temp > 0
        temp = Double(pow(-10.0, suggestLogUpperLimitGivenTop(temp)))
        return -temp
    }
    
    
    /// suggestHyperlogLowerLimitGivenBottom calculates the lower bound for a univariate log histogram
    ///
    /// - Parameter bottom: input bottom value
    /// - Returns: suggested bottom value
    func suggestLogLowerLimitGivenBottom(_ bottom: Double) -> Double {
        print("suggestLogLowerLimitGivenBottom")
        if bottom <= 1.0 {return -1.0} // no suggestion
        else {return Double(floor(log10(suggestLowerLimitGivenBottom(bottom))))}
    }
    
    
    /// suggestLogUpperLimitGivenTop calculates the upper bound for a univariate log histogram
    ///
    /// - Parameter top: input top value
    /// - Returns: suggested top value
    func suggestLogUpperLimitGivenTop(_ top: Double) -> Double {
        print("suggestLogUpperLimitGivenTop")
        return Double(floor(log10(suggestUpperLimitGivenTop(top))))
    }
    
    
    /// suggestLowerLimitGivenBottom calculates the lower limit for a univariate linear histogram
    ///
    /// - Parameter bottom: input bottom value
    /// - Returns: suggested bottom value
    func suggestLowerLimitGivenBottom(_ bottom: Double) -> Double {
        print("suggestLowerLimitGivenBottom")
        var root = 0.0
        var base = 0
        var min1Pos = 0
        var newBottom = bottom
        if floor(bottom) > Double(Int.max) {newBottom = Double(Int.max - 5)}
        else if floor(bottom) <= Double(Int.min) {newBottom = Double(Int.min + 5)}
        else {}
        var min1 = Int(floor(newBottom))
        if min1 < 0 {
            min1Pos = -min1
           root = Double(floor(log10(Double(min1Pos))))
            base = Int(pow(10.0,root))
            min1Pos = min1Pos - min1Pos%base + base // Int1%Int2 is integer remainder after division.
            min1 = -min1Pos
        } else if min1 > 0 {
            root = Double(floor(log10(Double(min1))))
            base = Int(pow(10.0,root))
            min1 = min1 - min1%base
        }
        print("ll bottom: \(bottom) min1: \(min1)")
        return Double(min1)
    }
    
    
    /// suggestUpperLimitGivenTop calculates the upper limit for a univariate linear histogram
    ///
    /// - Parameter top: input top value
    /// - Returns: suggested top value
    func suggestUpperLimitGivenTop(_ top: Double) -> Double {
        print("suggestUpperLimitGivenTop")
        var newTop = top
        if newTop > Double(Int.max) {newTop = Double(Int.max - 5)}
        else if newTop <= Double(Int.min) {newTop = Double(Int.min + 5)}
        else {}
        var max1 = Int(floor(newTop))
        if max1<=0 {max1 = 0}
        else { // max1 > 0
            let root = Double(floor(log10(Double(max1))))
            let base = Int(pow(10.0,root))
            if max1%base != 0 {
                max1 = max1 - max1%base + base
            }
        }
        print("ul top: \(top) max1: \(max1)")
        return Double(max1)
    }
    
    // MARK: - setPreferences *****************************
    
    /// setPreferences set Preferences used to calculate linear histograms
    func setPreferences() { // Called from convenience init
        let defaults = UserDefaults.standard
        countThreshold = defaults.integer(forKey: Preferences.CountThresholdKey)
        histRange1P = defaults.integer(forKey: Preferences.HistRange1PKey)
        histRange2P = defaults.integer(forKey: Preferences.HistRange2PKey)
        logLikeScaleTransform = defaults.integer(forKey: Preferences.LogLikeScaleTransformKey)
        switch logLikeScaleTransform {
        case 0: // Logicle
            T = defaults.double(forKey: Preferences.LogicleTKey)
            W = defaults.double(forKey: Preferences.LogicleWKey)
            M = defaults.double(forKey: Preferences.LogicleMKey)
            A = defaults.double(forKey: Preferences.LogicleAKey)
        case 1: // Asinh
            T = defaults.double(forKey: Preferences.AsinhTKey)
            W = defaults.double(forKey: Preferences.AsinhWKey)
            M = defaults.double(forKey: Preferences.AsinhMKey)
            A = defaults.double(forKey: Preferences.AsinhAKey)
        case 2: // Hyperlog
            T = defaults.double(forKey: Preferences.HyperlogTKey)
            W = defaults.double(forKey: Preferences.HyperlogWKey)
            M = defaults.double(forKey: Preferences.HyperlogMKey)
            A = defaults.double(forKey: Preferences.HyperlogAKey)
        default:
            break
        }        
    } // End of setPreferences
        
} // End of class UnivariateHistogram
