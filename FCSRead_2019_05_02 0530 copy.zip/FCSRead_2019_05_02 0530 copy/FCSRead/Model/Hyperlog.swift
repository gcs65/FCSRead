//
//  Hyperlog.swift calculates the Hyperlog scale.
//  FCSRead
//
// Modified from FastLogicle.m described in http://facs.stanford.edu/software/Logicle//

import Cocoa

public class Hyperlog {
    
    var histLimits: HistLimits?
    weak var mainViewController: MainViewController? // Used in retrieveHistLimitsForVariate to get histLimits from histLimitsDict
    
    var taylor = [Double]() // Coefficients of taylor series expansion
    var lookup = [Double]()
    var bins = 0
    
    var T = 0.0 // Logicle parameters
    var W = 0.0
    var M = 0.0
    var A = 0.0
    
    var a1 = 0.0
    var b1 = 0.0
    var c1 = 0.0
    var d1 = 0.0
    var f1 = 0.0
    var w1 = 0.0
    
    var x0 = 0.0
    var x1 = 0.0
    var x2 = 0.0
    var xTaylor = 0.0
    var inverse_x0 = 0.0
    
    /// init initializes instance of FastLogicle class
    ///
    /// - Parameters:
    ///   - myVar: variate whose axis is to be Logicle transformed
    ///   - myAxisType: UnivariateTag or BivariateTag
    init(myVar: Int, myAxisType: String) {
        let histLimits: HistLimits = histLimitsDict[myVar]!
        T = histLimits.T - 1.0
        W = histLimits.W
        M = histLimits.M
        A = histLimits.A
        let defaults = UserDefaults.standard
        if myAxisType == UnivariateTag { // Global constant in MainViewController
            bins = defaults.integer(forKey: Preferences.HistRange1PKey)
        }
            
        else if myAxisType == BivariateTag { // Global constant in MainViewController
            bins = defaults.integer(forKey: Preferences.HistRange2PKey)
        }
        setup()
    } // End of convenience init(myVar: Int, myAxisType: String)
    
    /// init initializes instance of FastLogicle class using T, W, M, and A values
    ///
    /// - Parameters:
    ///   - inputT: T value
    ///   - inputW: W value
    ///   - inputM: M value
    ///   - inputA: A value
    ///   - inputBins: number of bins for the histogram
    init(inputT: Double, inputW: Double, inputM: Double, inputA: Double, inputBins: Int) {
        T = inputT - 1.0
        W = inputW
        M = inputM
        A = inputA
        bins = inputBins
        setup()
    } // End of convenience init
    
    /// setup. Called by inits to set up calculations
    func setup() {
        
        lookup = [Double](repeating: 0.0, count: (bins + 1))
        // zero must be on a bin boundary
        if bins > 0 {
            var zero = (W + A) / (M + A)
            zero = floor((zero * Double(bins) + 0.5)) / Double(bins)
            A = (M * zero - W) / (1.0 - zero)
        }
        
        // Set actual parameters. Choose data zero location and the width of the linearization region to match the logicle scale.
        w1 = W / (M + A)
        x2 = A / (M + A)
        x1 = x2 + w1
        x0 = x2 + (2.0 * w1)
        // Log portion should match log/logicle scales.
        b1 = (M + A) * LN_10
        // Choose slope so exp and linear terms are equal at x0.
        let e2bx0 = Double(exp(b1 * x0))
        let c_a = e2bx0 / w1
        // Data value zero occurs at x1.
        let f_a = Double(exp(b1 * x1) + c_a * x1)
        // Adjust for top of scale.
        a1 = T / ((exp(b1) + c_a) - f_a)
        c1 = c_a * a1
        f1 = f_a * a1
        // Use the taylor series near x1 to avoid roundoff problems of formal definition.
        xTaylor = x1 + 0.25 * w1
        // compute coefficients of the Taylor series(
        var coef = a1 * exp(b1 * x1)
        // 16 is enough for full precision of typical scales
        taylor = [Double](repeating: 0.0, count: 16)
        for i in 0..<16 {
            coef *= b1 / (Double(i + 1))
            taylor[i] = coef
        }
        taylor[0] += c1 // Hyperlog condition
        var temp1 = 0.0
        inverse_x0 = inverseWithScale(&temp1)
        for i in 0...bins {
            var temp2 = Double(i) / Double(bins)
            lookup[i] = inverseWithScale(&temp2)
        }
        
    } // End of setup()
    
    
    /// taylorSeriesWithScale computes value of Taylor Series at a point on the scale.
    ///
    /// - Parameter scale: input scale value
    /// - Returns: value of Taylor Series at a point on the scale.
    func taylorSeriesWithScale(_ scale: Double) -> Double {
        let x = scale - x1
        var sum = taylor[15] * x
        var i = 14
        while i >= 0 {
            sum = (sum + taylor[i]) * x
            i -= 1
        }
        return sum
        
    } // End of taylorSeriesWithScale
    
    /// scaleWithValue looks up the neearest value - uses intScale(value)
    ///
    /// - Parameter value: value
    /// - Returns: nearest value in lookup array
    func scaleWithValue(_ value: Double) -> Double { // Modified from FastLogicle
        // Look up the nearest value - uses intScale()
        let index = intScaleWithValue(value)
        // Inverse interpolate the table linearly
        let delta = (value - lookup[index]) / (lookup[index + 1] - lookup[index])
        
        return Double((Double(index) + delta) / Double(bins))
        
    } // End of scaleWithValue
    
    
    /// inverseWithScale computes the data value for the given point on the Hyperlog scale. Reflect negative scale regions.
    ///
    /// - Parameter scale: scale value
    /// - Returns: inverse of scale
    func inverseWithScale(_ scale: inout Double) -> Double {
        let negative = scale < x1
        if negative {
            scale = 2.0 * x1 - scale
        }
        var inverse = 0.0
        if scale < xTaylor { // Near x1, i.e., data zero, use the series expansion.
            inverse = taylorSeriesWithScale(scale)
        }
        else { // This formulation has better roundoff behavior.
            inverse = (a1 * exp(b1 * scale) + c1 * scale) - f1
        }
        // Handle scale for negative values
        if negative {
            return -inverse
        }
        else {
            return inverse
        }
    } // End of inverseWithScale
    
    /// axisLabels
    ///
    /// - Returns: [Double] of axis label positions
    func axisLabels() -> [Double] {
        // number of decades in the positive logarithmic region
        let pd = M - 2.0 * W
        // Smallest power of 10 in the region
        let log10x = ceil(log(T) / LN_10 - pd)
        // Data value at that point
        var x = exp(LN_10 * log10x)
        // Number of positive labels
        var np = 0
        if x > T {
            x = T
            np = 1
        }
        else {
            np = Int(floor(log(T) / LN_10 - log10x) + 1)
        }
        // Bottom of scale
        var temp1 = 0.0
        let B = inverseWithScale(&temp1)
        // Number of negative labels
        var nn = 0
        if x > -B {
            nn = 0
        }
        else if x == T {
            nn = 1
        }
        else {
            nn = Int(floor(log(-B) / LN_10 - log10x) + 1)
        }
        
        // Fill in the axis labels
        var label = [Double](repeating: 0.0, count: nn + np + 1)
        label[nn] = 0.0
        if nn > 0 {
            var i = 1
            while i <= nn {
                label[nn - i] = -x
                label[nn + i] = x
                x *= 10.0
                i += 1
            }
        }
        
        for i in (nn + 1)...np {
            label[nn + i] = x
            x *= 10.0
        }
        
        return label
        
    } // End of axisLabels
    
    
    /// intScaleWithValue
    ///
    /// - Parameter value: input value
    /// - Returns: nearest bin value (Int)
    func intScaleWithValue(_ value: Double) -> Int { // Binary search for appropriate bin.
        var lo = 0
        var hi = bins
        var mid = 0
        var key = 0.0
        while lo <= hi {
            mid = (lo + hi) >> 1
            key = lookup[mid]
            if value < key {
                hi = mid - 1
            }
            else if value > key {
                lo = mid + 1
            }
            else if mid < bins {
                return mid
            }
            else {
                // equal to table[bins] which is for interpolation only
                // throw IllegalArgument(value);
                // NSLog(@"FRFastLogicle:intScale:value %f illegal.", value);
                return bins - 1
            }
        } // End of while loop
        
        // Check for out of range
        if hi < 0 || lo > bins {
            // throw IllegalArgument(value);
            // NSLog(@"FRFastLogicle:intScale:value %f out of range.", value);
            return 0
        }
        
        return lo - 1
        
    } // End of intScaleWithValue
    
} // End of Hyperlog class
