//
//  ReadAndParse.swift reads an FCS3.0 or FCS3.1 data file and parses the data. FCS stands for Flow Cytometry Standard. The front end of an FCS file is ASCII text and the back end is binary data.
//  FCSRead
//
//  Created by Mr. Salzman on 3/6/15.
//  Copyright (c) 2015-2019 Gary Salzman. All rights reserved.
//

import Foundation

public extension String {
  
    func toFloat() -> Float? {
        let sc = Scanner(string : self)
        var f : Float = 0.0
        if sc.scanFloat(&f) { return f }
        else { return nil }
    }
  
} // End of extension String

class ReadAndParse {
    
    weak var mainVC: MainViewController?
    var byteOrder = ByteOrder.littleEndian // default
    var fData = [[Double]]() // New version of fData
    var myData : Data? // raw data from file.
    var dataPtr: UnsafeMutablePointer<UInt8>?
    var delimiter : String = ""
    var textSegmentIsValid = false
    var textSegmentDictionary: [String:String] = [:]
    var byteIndex = 0
    var bits = 0
    var rBits = 0
    var mostNegativeValue : [Double] = []
    var mostPositiveValue : [Double] = []
    var xVariateSelected = false
    var yVariateSelected = false
    var xString = ""
    var yString = ""
    var xyString = ""
    
    // Required keyword values
    var requiredKeyWordsValid = false
    var beginAnalysis = 0
    var beginData = 0
    var beginSText = 0
    var byteOrd = ""
    var dataType = ""
    var endAnalysis = 0
    var endData = 0
    var endSText = 0
    var mode = ""
    var nextData = 0
    var totalEvents = 0
    var variates = 0 // $PAR
    var PnB : [Int] = []
    var PnEVal1 : [Double] = []
    var PnEVal2 : [Double] = []
    var PnN : [String] = []
    var PnR : [UInt32] = []
    var pnrBits : [UInt32] = []

    // Optional keyword values
    var optionalKeyWordsValid = false
    var abortedEvents = 0
    var beginTime = ""
    var cells = ""
    var comment = ""
    var cellSubsetMode = 0
    var cellSubsetValueBits = 0
    var CSVnFLAG : [Int] = []
    var cytometer = ""
    var cytometerSerialNumber = 0
    var date = ""
    var endTime = ""
    var experimenter = ""
    var filename = ""
    var numberOfGates = 0
    var gating = ""
    var institution = ""
    var lastModified = ""
    var lastModifier = ""
    var lostEvents = 0
    var fcmOperator = ""
    var originality = ""
    var plateID = ""
    var plateName = ""
    var PnCalValue : [Float] = []
    var PnCalString : [String] = []
    var PnDString : [String] = []
    var PnDVal1 : [Float] = []
    var PnDVal2 : [Float] = []
    var PnF : [String] = []
    var PnG : [Double] = []
    var PnL : [[Int]] = []
    var PnO : [Float] = []
    var PnP : [Int] = []
    var PnS : [String] = []
    @objc var PnNS : [String] = [] // Combo PnN and PnS
    var PnT : [String] = []
    var PnV : [Float] = []
    var proj : String = ""
    var RnI : [[String]] = [[]] // ex:[[], [1], [7, 10], [1, 4]]
    var RnW : [[NSPoint]] = [[]]
    var smno = ""
    var numSpillM = 0
    var spillM = [[Double]]()
    var spillPnN : [String] = []
    var spillVariate : [Int] = []
    var src = ""
    var sys = ""
    var timeStep = 0.0
    var triggerParameter = ""
    var triggerThreshold = 0
    var sampleVolume = 0.0
    var wellID = "" // End of Optional keyword values
    
    var doCompensation = false // Set after ReadAndParse:readFromData
    var logLikeScaleTransform = 0 // Default is Logicle

    struct HeaderSegment {
        // Must do memberwise initialization here
        var fcsID : String = ""
        var beginText : Int = 0
        var endText : Int = 0
        var beginDataHS : Int = 0
        var endDataHS : Int = 0
        var beginAnalysis : Int = 0
        var endAnalysis : Int = 0
    } // End of HeaderSegment struct
    var hdr = HeaderSegment() // instantiate struct
    
    
    /// init instantiates iVars needed for data interpretation
    ///
    /// - Parameters:
    ///   - data: input binary data
    ///   - mainViewController: MainViewController
    init(withData data: Data, mainViewController: MainViewController) { // data is either theData1 or theData2
        myData = data
        mainVC = mainViewController
        let len = myData!.count
        dataPtr = UnsafeMutablePointer.allocate(capacity: len)
        data.copyBytes(to: dataPtr!, count: data.count)
        print("ReadAndParse:init len \(len)")
        setPreferences() // Sets preferences for doCompensation and logLikeScaleTransformation from user defaults.
        if interpretFCSFile() == false {
            print("ReadAndParse.interpretFCSFile failed.")
        }
    } // End of init
    
    
    /// interpretFCSFile. Interprets the data read from the FCS file. Called by init
    ///
    /// - Returns: true if interpretFCSFile is successful
    func interpretFCSFile() -> Bool {
        
        var fcsFileOK = false
        if interpretHeader() { // interprets header
            fcsFileOK = true
            print("interpretHeader OK")
        }

        if dictionaryForTextSegment() { // Load text segment dictionary
            fcsFileOK = true
            print("dictionaryForTextSegment OK")
        }

        requiredValuesForKeys() // Interpret required keyword values

        optionalValuesforKeys() // Interpret optional keyword values

        if !loadDataIntoArray() { // Loads binary data into a spreadsheet type array fData[][]
            print("data could not be read.")
            fcsFileOK = false
            return fcsFileOK
        }

        if !gainCorrectionForEvents() {
            print("gain correction failed.")
            fcsFileOK = false
            return fcsFileOK
        }
        
        if doCompensation == true {
            if !fluorescenceCompensation1() {
                if numSpillM != 0 { // Note: if numSpillM == 0, there is no spill matrix. This test is for an actual failure of fluorescence compensation when a spill matrix is present.
                    print("fluorescenceCompensation failed.")
                    fcsFileOK = false
                    return fcsFileOK
                }
            }
        }
        
        applyCalibration()
        
        return fcsFileOK

    } // End of interpretFCSFile
    
    
    /// interpretHeader. Called by interpretFCSFile
    ///
    /// - Returns: true
    func interpretHeader() -> Bool {
        for i in 0...5 {
            hdr.fcsID += String(format:"%c", (dataPtr?[i])!)
        }
        print("hdr.fcsID = \(hdr.fcsID)")
        hdr.beginText = headerItemAtIndex(10)
        print("hdr.beginText = \(hdr.beginText)")
        hdr.endText = headerItemAtIndex(18)
        print("hdr.endText = \(hdr.endText)")
        hdr.beginDataHS = headerItemAtIndex(26)
        print("hdr.beginDataHS = \(hdr.beginDataHS)")
        hdr.endDataHS = headerItemAtIndex(34)
        print("hdr.endDataHS = \(hdr.endDataHS)")
        hdr.beginAnalysis = headerItemAtIndex(42)
        print("hdr.beginAnalysis = \(hdr.beginAnalysis)")
        hdr.endAnalysis = headerItemAtIndex(50)
        if hdr.endAnalysis != 0 {
            hdr.endAnalysis = 0
        }
        print("hdr.endAnalysis = \(hdr.endAnalysis)")
        return true
      
    } // End of interpretHeader. Called from interpretHeader
    
    
    /// headerItemAtIndex.
    ///
    /// - Parameter index: integer index in hdr
    /// - Returns: integer stored as a component of hdr (HeaderSegment)
    func headerItemAtIndex(_ index: Int) -> Int {
        var headerItem = 0
        var temp = ""
        let spaces : CharacterSet =
            CharacterSet.whitespaces
        for i in index..<index+8 {
            temp += String(format:"%c", (dataPtr?[i])!)
        }
        let scanner =
            Scanner.localizedScanner(with: temp) as! Scanner
        scanner.charactersToBeSkipped = spaces
        scanner.scanInt(&headerItem)
        return headerItem

    } // End of headerItemAtIndex
    
    
    /// dictionaryForTextSegment. Called from interpretFCSFile to creates the dictionary for the text segment.
    ///
    /// - Returns: textSegmentDictionaryStatus
    func dictionaryForTextSegment() -> Bool {
        var textSegmentDictionaryStatus = false
        var index = hdr.beginText
        delimiter = String(format:"%c", (dataPtr?[index])!)
        print("delimiter = \(delimiter)")
        //        print(String(format: "%0X", delimiter))
        var tempStr = "" // String containing all of textSegment
        index += 1 // Step to 1st char after delimiter
        while index <= hdr.endText { // Copy textSegment into tempStr
            tempStr += String(format:"%c", (dataPtr?[index])!)
            index += 1
        }
        if hdr.fcsID == "FCS3.0" {
            if tempStr.range(of:"SPILL") != nil {
                if let range = tempStr.range(of: "SPILL") {
                    tempStr.insert("$", at: range.lowerBound)
                }
            } else {
                print("SPILL not present in dictionaryForTextSegment")
            }
        }
        //        print("dictionaryForTextSegment tempStr before parse: \(tempStr)")
        // Use scanner to find key/value pairs in tempStr and place in dictionary.
        let scanner : Scanner =
            Scanner.localizedScanner(with: tempStr) as! Scanner
        let skippedChar : CharacterSet = CharacterSet(charactersIn: delimiter)
        let dollarSign : CharacterSet = CharacterSet(charactersIn: "$")
        var keyStr: NSString? = nil // string holding key
        var valueStr: NSString? = nil // string holding value
        index = 0   // Scan string and load dictionary
        while index < tempStr.lengthOfBytes(using: String.Encoding.ascii) - 1 {
            if scanner.scanUpToCharacters(from: dollarSign, into: nil) {
                // Skip whitespace characters before $Keyword...
                // This is a problem with FACS Aria II FCS3.0 files.
                // Using intoString:nil merely moves the scanLocation forward.
            }
            if scanner.scanUpToCharacters(from: skippedChar, into: &keyStr) {
                _ = keyStr?.uppercased // All keys to uppercase
                scanner.scanLocation += 1 // Skip over 1st delimiter
                if scanner.scanUpToCharacters(from: skippedChar, into: &valueStr)
                {
                    textSegmentDictionary
                        .updateValue(String(valueStr!),
                                     forKey: String(keyStr!))
                    scanner.scanLocation += 1 // Skip over 2nd delimiter
                }
            }
            index += 1
        }
        textSegmentDictionaryStatus = true
        return textSegmentDictionaryStatus
    } // End of dictionaryForTextSegment
    
    
    /// requiredValuesForKeys. Called from interpretFCSFile. Retrieves required keyword values.
    func requiredValuesForKeys() {
        if let rK = integerValueFromTextDictionary("$BEGINANALYSIS") { // $BEGINANALYSIS is one of the required keys
            beginAnalysis = rK
        }
        if let rK = integerValueFromTextDictionary("$BEGINDATA") {
            beginData = rK
        }
        if let rK = integerValueFromTextDictionary("$BEGINSTEXT") {
            beginSText = rK
        }
        if let rK = stringValueFromTextDictionary("$BYTEORD") {
            byteOrd = rK // "1,2,3,4" or "4,3,2,1"
            if byteOrd == "1,2,3,4" { // see NewByteBackpacker.swift
                byteOrder = ByteOrder.littleEndian
            } else {
                byteOrder = ByteOrder.bigEndian
            }
        }
        if let rK = stringValueFromTextDictionary("$DATATYPE") {
            dataType = rK
        }
        if let rK = integerValueFromTextDictionary("$ENDANALYSIS") {
            endAnalysis = rK
        }
        if let rK = integerValueFromTextDictionary("$ENDDATA") {
            endData = rK
        }
        if let rK = integerValueFromTextDictionary("$ENDSTEXT") {
            endSText = rK
        }
        if let rK = stringValueFromTextDictionary("$MODE") {
            mode = rK
        }
        if let rK = integerValueFromTextDictionary("$PAR") {
            variates = rK
        }
        if let rK = integerValueFromTextDictionary("$TOT") {
            totalEvents = rK
        }

        // $PnB ***************************************************
        if dataType == "F" {
            // All PnB set to 32 bits (Required for FCS3.1).
            PnB = [Int](repeating: 32, count: variates + 1)
        } else if dataType == "D" {
            // All PnB set to 64 bits.
            PnB = [Int](repeating: 64, count: variates + 1)
        } else { // "I" is only other allowed option here.
            PnB = [Int](repeating: 0, count: variates + 1)
            for variate in 1...variates {
                let s = "$P" + "\(variate)" + "B"
                if let pnb = integerValueFromTextDictionary(s) {
                    PnB[variate] = pnb
                }
            }
        }

        // $PnE ***************************************************
        // Zero values required for "F" or "D" data in FCS3.1.
        PnEVal1 = [Double](repeating: 0.0, count: variates + 1)
        PnEVal2 = [Double](repeating: 0.0, count: variates + 1)
        if dataType == "I" // Needs to be tested
        {
            let commaSpace : CharacterSet =
            CharacterSet(charactersIn: ", ")
            for variate in 1...variates {
                let s = "$P" + "\(variate)" + "E"
                if let pne = stringValueFromTextDictionary(s) {
                    // e.g., pne = "4.0, 0.01"
                    let scanner =
                        Scanner.localizedScanner(with: pne)
                            as! Scanner
                    scanner.charactersToBeSkipped = commaSpace
                    scanner.scanDouble(&PnEVal1[variate])
                    scanner.scanDouble(&PnEVal2[variate])
                }
            } // End of loop over variates
        } // End of dataType == "I" for $PnE

        // $PnN ***************************************************
        PnN = [String](repeating: "", count: variates + 1)
        PnNS = [String](repeating: "", count: variates + 1)
        PnN[0] = "None"
        PnNS[0] = "None"
        for variate in 1...variates {
            let s = "$P" + "\(variate)" + "N"
                if let pnn = stringValueFromTextDictionary(s) {
                PnN[variate] = pnn
                PnNS[variate] = PnN[variate]
            }
        }

        // $PnR ***************************************************
        // FCS3.1: if PnR[n] not 2^n, use next higher power of 2
        PnR = [UInt32](repeating: 0, count: variates + 1)
        pnrBits = [UInt32](repeating: 0, count: variates + 1)
        var pnr32 : Int32 = 0
        for variate in 1...variates { // $P2R/262144/
            let s = "$P" + "\(variate)" + "R"
            if let pnr : Int64 = longlongValueFromTextDictionary(s) {
                if pnr >= Int64(UINT32_MAX) {
                  pnr32 = Int32(UINT32_MAX/2)
                  PnR[variate] = UInt32(pnr32)
                } else {
                  PnR[variate] = UInt32(pnr)
                }
                if pnr > 0 {
                    let pnrb : UInt32 =
                        UInt32(ceil(log(Double(pnr))/Double(log(2.0))))
                    pnrBits[variate] = pnrb
                }
                else {
//                    let pnrb : UInt32 = 0
                }
            }
        } // End of loop over variates and end of $PnR

        print("Required keywords")
        print("mode \(mode)")
        print("beginAnalysis: \(beginAnalysis) endAnalysis \(endAnalysis)")
        print("beginData: \(beginData) endData \(endData)")
        print("beginSText \(beginSText) endSText \(endSText)")
        print("byteOrd \(byteOrd) dataType \(dataType)")
        print("variates \(variates) totalEvents \(totalEvents)")
        print("PnB: \(PnB.description)")
        print("PnEVal1: \(PnEVal1.description)")
        print("PnEVal2: \(PnEVal2.description)")
        print("PnN: \(PnN.description)")
        print("PnR: \(PnR)")
        print("pnrBits:\(pnrBits)\n")
    } // End of requiredValuesForKeys()
    
    
    /// optionalValuesforKeys. Called from interpretFCSFile. Retrieves optional keyword values.
    func optionalValuesforKeys() {
        
        // $ABRT ***************************************************
        // Number of aborted events due to electronic coincidence
        if let abEvents = integerValueFromTextDictionary("$ABRT") {
            abortedEvents = abEvents
        }

        // $BTIM ***************************************************
        // Clock time at beginning of data acquisition [.cc] is optional
        // FCS3.1 format: hh.mm.ss[.cc], where cc is in units of 0.01 sec
        // FCS3.0 format: cc is in units of 1/60 sec
        if let btim = stringValueFromTextDictionary("$BTIM") {
            if !btim.isEmpty { beginTime = btim }
        }

        // $CELLS ***************************************************
        // Type of cells or other object measured
        if let cellType = stringValueFromTextDictionary("$CELLS") {
            if !cellType.isEmpty { cells = cellType }
        }

        // $COM ***************************************************
        // Comment
        if let com = stringValueFromTextDictionary("$COM") {
            if !com.isEmpty { comment = com }
        }

        // $CSMODE ************************************************
        // Cell subset mode, i.e., the number of subsets to which the 
        // cell may belong.
        if let csMode = integerValueFromTextDictionary("$CSMODE")
        {
            cellSubsetMode = csMode
            if cellSubsetMode > 1
            {
                if let csvBits =
                    integerValueFromTextDictionary("$CSVBITS")
                {
                    cellSubsetValueBits = csvBits
                    CSVnFLAG = [Int](repeating: 0,
                    count: cellSubsetMode + 1)
                    for i in 0...cellSubsetMode
                    {
                        let s = "$CSV" + "\(i)" + "FLAG"
                        if let csvFlag = integerValueFromTextDictionary(s) {
                            CSVnFLAG[i] = csvFlag
                        }
                    }
                }
            }
        } // This needs to be looked at carefully???????????????

        // $CYT ************************************************
        // Name of cytometer
        if let cyt = stringValueFromTextDictionary("$CYT") {
            if !cyt.isEmpty { cytometer = cyt }
        }

        // $CYTSN **********************************************
        // Cytometer serial number
        if let cytsn = integerValueFromTextDictionary("$CYTSN") {
            cytometerSerialNumber = cytsn
        }

        // $DATE **********************************************
        // Date in format dd-mmm-yyyy
        if let d = stringValueFromTextDictionary("$DATE") {
            if !d.isEmpty { date = d }
        }

        // $ETIM **********************************************
        // Clock time at end of data acquisition in format
        // FCS3.1 format: hh.mm.ss[.cc], where cc is in units of 0.01 sec
        if let eTime = stringValueFromTextDictionary("$ETIM") {
            if !eTime.isEmpty { endTime = eTime }
        }

        // $EXP **********************************************
        // The name of the person initiating the experiment
        if let exp = stringValueFromTextDictionary("$EXP") {
            if !exp.isEmpty { experimenter = exp }
        }

        // $FIL **********************************************
        // The name of the file this dataset was originally saved in.
        if let fil = stringValueFromTextDictionary("$FIL") {
            if !fil.isEmpty { filename = fil }
        }

        // $GATE *********************************************
        // Number of gating parameters
        if let ng = integerValueFromTextDictionary("$GATE") {
            numberOfGates = ng
        }

        // $GATING *******************************************
        // Specifies region combinations used for gating
        // $GATING/R1 AND (R2.OR.R3)/ no R0 - index starts at 1
        if let gat = stringValueFromTextDictionary("$GATING") {
            if !gat.isEmpty { gating = gat }
        }

        // $INST *********************************************
        // Institution at which data was acquired.
        if let ins = stringValueFromTextDictionary("$INST") {
            if !ins.isEmpty { institution = ins }
        }

        // $LAST_MODIFIED ************************************
        // Timestamp of the last modification of the dataset.
        if let lm = stringValueFromTextDictionary("$LAST_MODIFIED") {
            if !lm.isEmpty { lastModified = lm }
        }

        // $LAST_MODIFIER ************************************
        // Name of person doing the last modification of the dataset.
        if let lr = stringValueFromTextDictionary("$LAST_MODIFIER") {
            if !lr.isEmpty { lastModifier = lr }
        }

        // $LOST *********************************************
        // Number of events lost due to computer busy.
        if let los = integerValueFromTextDictionary("$LOST") {
            lostEvents = los
        }

        // $OP ***********************************************
        // Name of flow cytometer operator.
        if let nm = stringValueFromTextDictionary("$OP") {
            if !nm.isEmpty { fcmOperator = nm }
        }

        // $ORIGINALITY **************************************
        // State of modification of the dataset. One of:
        // "Original", "Appended", "NonDataModified", "DataModified".
        if let orig = stringValueFromTextDictionary("$ORIGINALITY") {
            if !orig.isEmpty {
                switch orig {
                    case "Original":
                        originality = "Original"
                    case "Appended":
                        originality = "Appended"
                    case "NonDataModified":
                        originality = "NonDataModified"
                    case "DataModified":
                        originality = "DataModified"
                    default:
                        originality = ""
                }
            }
        }

        // $PLATEID ******************************************
        // Plate identifier.
        if let plID = stringValueFromTextDictionary("$PLATEID") {
            if !plID.isEmpty { plateID = plID }
        }

        // $PLATENAME ****************************************
        // Plate name.
        if let pn = stringValueFromTextDictionary("$PLATENAME") {
            if !pn.isEmpty { plateName = pn }
        }

        // $PnCALIBRATION ************************************
        // Conversion of parameter values to any well-define units,
        // e.g., MESF.
        PnCalValue = [Float](repeating: 0.0, count: variates + 1)
        PnCalString = [String](repeating: "", count: variates + 1)
        let commaSpace : CharacterSet =
            CharacterSet(charactersIn: ", ")
        for variate in 1...variates { // $P1CALIBRATION/1.234,MESF/
            let s = "$P" + "\(variate)" + "CALIBRATION"
            if let pnc = stringValueFromTextDictionary(s) {
                if !pnc.isEmpty {
                    var any : [Any] = Array(repeating: "", count: 2) // AnyObject->Any
                  any = pnc.components(separatedBy: commaSpace)
                  PnCalValue[variate] = (any[0] as! NSString).floatValue
                  PnCalString[variate] = any[1] as! NSString as String
                }
                else { // $PnCALIBRATION not present.
                    PnCalValue[variate] = 1.0
                    PnCalString[variate] = ""
                }
            }
        }

        // $PnD **********************************************
        // Suggested visualization scale for parameter n (only for linear or logarithmic scales)
        // $PnD/string,f1,f2/ $P3D/Logarithmic,4.0,0.1/ or
        // $P3D/Linear,0.0,1024.0/
        // Logarithmic: f1 is number of decades and f2 is 
        // starting linear value.
        PnDString = [String](repeating: "", count: variates + 1)
        PnDVal1 = [Float](repeating: 0.0, count: variates + 1)
        PnDVal2 = [Float](repeating: 0.0, count: variates + 1)
        for variate in 1...variates { // ex: $P1D/Logarithmic,4.0,0.1/
            let s = "$P" + "\(variate)" + "D"
            if let pnd = stringValueFromTextDictionary(s) {
                if !pnd.isEmpty {
                  var any : [Any] = Array(repeating: "", count: 3) // AnyObject->Any
                  any = pnd.components(separatedBy: commaSpace)
                  PnDString[variate] = any[0] as! NSString as String
                  PnDVal1[variate] = (any[1] as! NSString).floatValue
                  PnDVal2[variate] = (any[2] as! NSString).floatValue
                }
            }
        }
        print("PnDString \(PnDString)")
        print("PnDVal1 \(PnDVal1)")
        print("PnDVal2 \(PnDVal2)")

        // $PnF **********************************************
        // Name of optical filter for parameter n.
        PnF = [String](repeating: "", count: variates + 1)
        for variate in 1...variates { // $P3F/520LP/
            let s = "$P" + "\(variate)" + "F"
            if let pnf = stringValueFromTextDictionary(s) {
                if !pnf.isEmpty {
                  PnF[variate] = pnf
                }
            }
        }

        // $PnG **********************************************
        // Amplifier gain used for acquisition of parameter n.
        PnG = [Double](repeating: 1.0, count: variates + 1)
        for variate in 1...variates { // $P3G/10.0/
            let s = "$P" + "\(variate)" + "G"
            if let png = doubleValueFromTextDictionary(s) {
                PnG[variate] = png
                if PnG[variate] == 0.0 {
                    PnG[variate] = 1.0
                }
            }
        }
        print("PnG: \(PnG.description)")

        // $PnL **********************************************
        // Excitation wavelength(s) for parameter n.
        // Ex: $P1L/488/  $P3L/560,625/
        PnL = [[Int]](repeating: [], count: variates + 1)
        for variate in 1...variates { // $P3L/488/ or $P3L/520,625,.../
            let s = "$P" + "\(variate)" + "L"
            var strArray : [String] = []
            var intArray : [Int] = []
            if let pnl = stringValueFromTextDictionary(s) { // "520,625"
                if !pnl.isEmpty { // One or more nonzero values
                    strArray = pnl.components(separatedBy: commaSpace)
                    for index in 0..<strArray.count {
                    // Check strArray[index] for extraneous characters.
                        let temp = strArray[index].toFloat()
                    if temp != nil {
                            intArray.append(Int(temp!))
                        } else {
                            intArray.append(0)
                        }
                    }
                    PnL[variate] = intArray
                }
            }
        }
        print("PnL: \(PnL)")

        // $PnO **********************************************
        // Excitation power for parameter n.
        PnO = [Float](repeating: 0.0, count: variates + 1)
        for variate in 1...variates { // $P3O/10.0/ 10 mW
            let s = "$P" + "\(variate)" + "O"
            if let pno = floatValueFromTextDictionary(s) {
                PnO[variate] = pno
            }
        }

        // $PnP **********************************************
        // Percent of emitted light collected by parameter n.
        PnP = [Int](repeating: 0, count: variates + 1)
        for variate in 1...variates { // $P3P/10/ 10%
            let s = "$P" + "\(variate)" + "P"
            if let pnp = integerValueFromTextDictionary(s) {
                PnP[variate] = pnp
            }
        }

        // $PnS **********************************************
        // Long name used for parameter n.
        PnS = [String](repeating: "", count: variates + 1)
        for variate in 1...variates { // $P3S/FITC/
            let s = "$P" + "\(variate)" + "S"
            if let pns = stringValueFromTextDictionary(s) {
                if !pns.isEmpty { PnS[variate] = pns }
            }
            if !PnS[variate].isEmpty {
                PnNS[variate] += "/" + PnS[variate]
            }
         }

        // $PnT **********************************************
        // Detector type for parameter n.
        PnT = [String](repeating: "", count: variates + 1)
        for variate in 1...variates { // $P3T/PMT9524/
            let s = "$P" + "\(variate)" + "T"
            if let pnt = stringValueFromTextDictionary(s) {
                if !pnt.isEmpty { PnT[variate] = pnt }
            }
        }

        // $PnV **********************************************
        // Detector voltage for parameter n.
        PnV = [Float](repeating: 0.0, count: variates + 1)
        for variate in 1...variates { // $P3V/445.5/
            let s = "$P" + "\(variate)" + "V"
            if let pnv = floatValueFromTextDictionary(s) {
                PnV[variate] = pnv
            }
        }

        // $PROJ *********************************************
        // Name of the experiment project.
        if let pr = stringValueFromTextDictionary("$PROJ") {
            if !pr.isEmpty { proj = pr }
        }

        // $RnI **********************************************
        // Gating region for parameter number n. String, [String](opt)
        // $R4I/6/ $R3I/2,4/  $R2I/3/
        if numberOfGates > 0 {
            RnI = [[String]](repeating: [], count: numberOfGates + 1)
            for gate in 1...numberOfGates { // $R1I/2/ or $R2I/3,4/
                let s = "$R" + "\(gate)" + "I"
                var strArray : [String] = []
                if let rni = stringValueFromTextDictionary(s) { // "3,4"
                    if !rni.isEmpty { // One or more nonzero values
                        strArray = rni.components(separatedBy: commaSpace)
                        RnI[gate] = strArray
                    }
                }
            }
            print("RnI \(RnI)")
        }

        // $RnW **********************************************
        // Window settings for gating region n.
        //        $R1I/1/
        //        $R1W/1200.0, 1800.0/
        //        $R2I/7,10/
        //        $R2W/1000.0,50.0;1500.0,50.0;1500.0,90.0;1000.0,90.0/
        //        $R3I/1,4/
        //        $R3W/1500.0,1500.0;1900.0,1700.0;2000.0,2300.0,1600.0,1500.0/
        //    println("$RnW")
        if numberOfGates > 0  // $GATE/numberOfGates/
        {
    //        var pt = NSPoint(x: 0.0, y: 0.0)
            var ptArray : [NSPoint] = []
            for gate in 1...numberOfGates {
                let s = "$R" + "\(gate)" + "W"
                if let rw = stringValueFromTextDictionary(s) {
                    if !rw.isEmpty {
                        ptArray = ptArrayFromString(rw)!
                        RnW.insert(ptArray, at:gate)
                    }
                } // rw string present
            } // Loop over gate

            for ptArray in RnW {
                print("")
                for pt in ptArray {
                    print("\(pt.x), \(pt.y)")
                }
            }
        } // End of $RnW

        // $SMNO *********************************************
        // Specimen (e.g., tube) label.
        if let str = stringValueFromTextDictionary("$SMNO") {
            if !str.isEmpty { smno = str }
        }

        // $SPILLOVER ****************************************
        // Fluorescence spillover matrix.
        // $SPILLOVER/2,FL1_A,FL2_A,1,0.1345,0.0033,1/
        let tempStr1 = stringValueFromTextDictionary("$SPILLOVER")
        let tempStr2 = stringValueFromTextDictionary("$SPILL")
        let tempStr3 = stringValueFromTextDictionary("$DET_SPILL")
        if tempStr1 != "" {
            loadSpillMatrixWithString(tempStr1!)
        } else if tempStr2 != "" {
            loadSpillMatrixWithString(tempStr2!)
        } else if tempStr3 != "" {
            loadSpillMatrixWithString(tempStr3!)
        } else  {
            numSpillM = 0 // no spillover
        }
        
        // $SRC **********************************************
        // Source of the specimen (patient name, cell types)
        if let str = stringValueFromTextDictionary("$SRC") {
            if !str.isEmpty { src = str }
        }

        // $SYS **********************************************
        // Type of computer and its operating system.
        if let str = stringValueFromTextDictionary("$SYS") {
            if !str.isEmpty { sys = str }
        }

        // $TIMESTEP *****************************************
        // Specifies the time step in seconds. $TIMESTEP/0.01/
        if let ts = doubleValueFromTextDictionary("$TIMESTEP") {
            timeStep = ts
        }

        // $TR ***********************************************
        // Trigger parameter and its threshold. $TR/FSC_H,54/
        if let str = stringValueFromTextDictionary("$TR") {
            if !str.isEmpty { // $TR present.
            var tempStr : NSString?
            var tempInteger : Int
            let comma : CharacterSet =
            CharacterSet(charactersIn: ",")
            if let scanner =
                Scanner.localizedScanner(with: str) as? Scanner
            {
                scanner.charactersToBeSkipped = comma
                if scanner.scanUpToCharacters(from: comma, into: &tempStr) {
                    print("\(String(describing: index)) \(String(describing: tempStr))")
                    if tempStr != nil {
                        triggerParameter = tempStr! as String
                    }
                } // End of scanning triggerParameter
                tempInteger = 0
                if scanner.scanInt(&tempInteger) {
                    triggerThreshold = tempInteger
                } // End of scanning triggerThreshold
            }
            }
        } // End of $TR

        // $VOL **********************************************
        // Volume of sample run during data acquisition in nanoliters.
        // $VOL/50500.0/
        if let vol = doubleValueFromTextDictionary("$VOL") {
            sampleVolume = vol
        }

        // $WELLID *******************************************
        // Well identifier. $WELLID/A07/
        if let str = stringValueFromTextDictionary("$WELLID") {
            wellID = str
        }
          
    } // End of optionalValuesforKeys()

    
    /// loadDataIntoArray. Loads FCS data into fData[][] array
    ///
    /// - Returns: true
    func loadDataIntoArray() -> Bool {
        setupFData() // Allocates space for fData[totalEvents + 1][variates + 1]

        // Below loaded in extremeValuesForVariate(variate : Int), which is called by histograms for each variate. Allocate space here.
        mostNegativeValue = [Double](repeating: 0.0, count: variates + 1)
        mostPositiveValue = [Double](repeating: 0.0, count: variates + 1)
        var dataOK = false
        byteIndex = beginData
        //    println("beginData \(byteIndex)")
        let interpretData = InterpretData(self)
        if dataType == "I" {
            for i in 1...totalEvents {
                fData[i] = interpretData.intEvent()
            }
        } else if dataType == "F" || dataType == "D" {
            for i in 1...totalEvents {
                fData[i] = interpretData.fDEvent()
            }
        } else {}

        print("Channel data")
        for event in 1...5 {
            print("\(fData[event])")
        }
        dataOK = true
        return dataOK
    } // End of loadDataIntoArray
    
    
    /// gainCorrectionForEvents
    ///
    /// - Returns: true if successful
    func gainCorrectionForEvents() -> Bool {
        var success : Bool = false
        var allLinear : Bool = true
        if dataType == "I" { // Are all variates linear?
            for variate in 1...variates {
                if PnEVal1[variate] != 0.0 || PnEVal2[variate] != 0.0 {
                    allLinear = false // log data acquisition
                }
            }
        } // End of testing whether all "I" variates are linear

        if dataType == "F" || dataType == "D" || allLinear == true {
            // Called by interpretFCSFile() for $DataType/F or D/
            for row in 1...totalEvents {
                for col in 1...variates {
                    fData[row][col] /= PnG[col]
                }
            } // End of loop over totalEvents
            success = true
        } else { // dataType = "I" with some log data acquisition
            for event in 1...totalEvents {
                for variate in 1...variates {
                    if PnEVal1[variate] != 0.0 || PnEVal2[variate] != 0.0 {
                        success = antilogConversion(event, variate: variate)
                    }
                } // End of loop over variates
            } // End of loop over events
         }
        return success
    } // End of gainCorrectionForEvents
    
    
    /// antilogConversion. Called by interpretFCSFile after loadDataIntoArray for event variates acquired by log amplifiers.
    ///
    /// - Parameters:
    ///   - event: one row of fData[][]
    ///   - variate: selected variate
    /// - Returns: true if successful
    func antilogConversion(_ event:Int, variate:Int) -> Bool {
        let xc = fData[event][variate]
        let r = Double(PnR[variate])
        if r != 0.0 {
            let temp = ((PnEVal1[variate]*xc/r)*PnEVal2[variate])
            fData[event][variate] = Double(pow(10.0, temp))
            return true
        } else {
            print("PnR[] == 0 for variate \(variate)")
        }
            return false
    } // End of antilogConversion
    
    /// loadSpillMatrixWithString
    ///
    /// - Parameter str: spillover string (see next line)
    func loadSpillMatrixWithString(_ str : String) { // example str: 2,FL1_A,FL2_A,1,0.1345,0.0033,1
        //        print("loadSpillMatrixWithString. str: \(str)")
        var tempStr : NSString?
        let comma : CharacterSet =
            CharacterSet(charactersIn: ",") // comma
        if let scanner = Scanner.localizedScanner(with: str) as? Scanner {
            scanner.charactersToBeSkipped = comma
            if scanner.scanInt(&numSpillM) {
                for _ in 0..<numSpillM { // allocate empty spillM[0..<numSpillM][0..<numSpillM]
                    spillM.append(Array(repeating: 0.0, count: numSpillM))
                }
                spillPnN = [String](repeating: "", count: numSpillM) // names of spill variates
                spillVariate = [Int](repeating: 0, count: numSpillM) // array of spill variates
                for index in 0..<numSpillM {
                    if scanner.scanUpToCharacters(from: comma, into: &tempStr) {
                        if tempStr != nil {
                            spillPnN[index] = tempStr! as String
                            spillVariate[index] = variateNumberForString(spillPnN[index])!
                        }
                    } // End of scanning spill matrix prefix
                }
                let cols = numSpillM
                for row in 0..<numSpillM {
                    for col in 0..<cols {
                        if scanner.scanUpToCharacters(from: comma, into: &tempStr) {
                            spillM[row][col] = (tempStr?.doubleValue)!
                        }
                    }
                }
            }
        } // End of if let scanner
    } // End of loadSpillMatrixWithString:
    
    /// applyCalibration. Multiplies by calibration coefficient (PnCalValue[j]) with units of PnCalString[j]. PnCalString[j] set to "", if $PnCALIBRATION not present. If PnCalValue[j] not present, PnCalValue[j] set to 1.0.
    func applyCalibration() {
        for row in 1...totalEvents {
            for col in 1...variates {
                fData[row][col] *= Double(PnCalValue[col])
            }
        }
    } // End of applyCalibration
    
    
    /// fluorescenceCompensation1. Called by interpretFCSFile after loadDataIntoArray if doCompensation is true.
    // Next line deals with situation in which doCompensation is set to true in Preferences, but the FCS file does not have spillover matrix.
    ///
    /// - Returns: true
    func fluorescenceCompensation1() -> Bool {
        if numSpillM == 0 {
            return false
        }
        var ident = [[Double]]()
        for _ in 0..<numSpillM {
            ident.append(Array(repeating: 0.0, count: numSpillM))
        }
        var spillMInv = [[Double]]()
        for _ in 0..<numSpillM {
            spillMInv.append(Array(repeating: 0.0, count: numSpillM))
        }
        var temp = [[Double]]()
        for _ in 0..<numSpillM {
            temp.append(Array(repeating: 0.0, count: numSpillM))
        }
        var varToComp : [Double] = [Double](repeating: 0.0,
                                            count: numSpillM)
        var compedVar : [Double] = [Double](repeating: 0.0,
                                            count: numSpillM)
        
        temp = spillM // Copy spillM to temp for later use in checking spillMInv
        gaussj0(&temp) // Invert copy of spillM in place. temp is now spillM inverse.
        ident = multiplyForMatrices(temp, bb: spillM) // Check for identity by multiplying spillM and temp
        for event in 1...totalEvents { // Load varsToComp
            for j in 0..<numSpillM {
                let k = spillVariate[j]
                varToComp[j] = fData[event][k]
            } // End of loading varToComp[]
            for i in 0..<numSpillM { // zero the compedVar vector.
                compedVar[i] = 0.0
            }
            for i in 0..<numSpillM {
                for j in 0..<numSpillM {
                    compedVar[i] += varToComp[j] * temp[j][i]
                }
            }
            for i in 0..<numSpillM {
                let k = spillVariate[i]
                fData[event][k] = compedVar[i]
            }
        } // End of loop over totalEvents
        return true
    } // End of fluorescenceCompensation1
    
    
    /// setPreferences. Called in ReadAndParse init.
    func setPreferences() {
        let defaults = UserDefaults.standard
        doCompensation = defaults.bool(forKey: Preferences.DoCompensationKey)
        logLikeScaleTransform = defaults.integer(forKey: Preferences.LogLikeScaleTransformKey)
    }

    // MARK: - Support Functions (ReadAndParse) *******************
    
    
    /// setupFData. Called from loadDataIntoArray
    func setupFData() {
        print("ReadAndParse.setupFData totalEvents: \(totalEvents) variates \(variates)")
        for _ in 0...totalEvents { // Initialize fData
            fData.append(Array(repeating: 0.0, count: variates + 1))
        } // fData[0...totalEvents][0...variates]
    }
    
    
    /// floatValueFromTextDictionary
    ///
    /// - Parameter key: text dictionary key
    /// - Returns: float value if successful
    func floatValueFromTextDictionary(_ key: String) -> Float? {
        if let value = textSegmentDictionary[key] {
            if !value.isEmpty { // key/value pair found
                return (value as NSString).floatValue
            }
        } else {
            return Float(0.0)
        }
        return nil
    } // End of floatValueFromTextDictionary
    
    
    /// intValueFromTextDictionary
    ///
    /// - Parameter key: text dictionary key
    /// - Returns: int value if successful
    func intValueFromTextDictionary(_ key: String) -> Int32? {
        if let value = textSegmentDictionary[key] {
            if !value.isEmpty { // key/value pair found
                return (value as NSString).intValue
            }
        } else {
            return 0
        }
        return nil
    } // End of intValueFromTextDictionary
    
    
    /// integerValueFromTextDictionary
    ///
    /// - Parameter key: text dictionary key
    /// - Returns: integer value if successful
    func integerValueFromTextDictionary(_ key: String) -> Int? {
        if let value = textSegmentDictionary[key] {
            if !value.isEmpty { // key/value pair found
                return (value as NSString).integerValue // Int
            }
        } else {
            return 0
        }
        return nil
    } // End of integerValueFromTextDictionary
    
    
    /// doubleValueFromTextDictionary
    ///
    /// - Parameter key: text dictionary key
    /// - Returns: double value if successful
    func doubleValueFromTextDictionary(_ key: String) -> Double? {
        if let value = textSegmentDictionary[key] {
            if !value.isEmpty { // key/value pair found
              return (value as NSString).doubleValue
            }
        } else {
            return Double(0.0)
        }
        return nil
    } // End of doubleValueFromTextDictionary
    
    
    /// longlongValueFromTextDictionary
    ///
    /// - Parameter key: text dictionary key
    /// - Returns: longlongvalue if successful
    func longlongValueFromTextDictionary(_ key: String) -> Int64? {
        if let value = textSegmentDictionary[key] {
            if !value.isEmpty { // key/value pair found
                return (value as NSString).longLongValue
            }
        } else {
            return 0
        }
        return nil
    } // End of longlongValueFromTextDictionary
    
    
    /// stringValueFromTextDictionary
    ///
    /// - Parameter key: text dictionary key
    /// - Returns: string value if successful
    func stringValueFromTextDictionary(_ key: String) -> String?
    {
        if let value = textSegmentDictionary[key] {
            if !value.isEmpty { // key/value pair found
                return value
            }
        } else {
            return ""
        }
        return nil
    } // End of stringValueFromTextDictionary
    
    
    /// ptArrayFromString
    ///
    /// - Parameter str: String, ex: "1000.0,50.0;1500.0,50.0;1500.0,90.0;1000.0,90.0". Used by $RnW.
    /// - Returns: array of NSPoints
    func ptArrayFromString(_ str : String) -> [NSPoint]? {
        var x0 : Float = 0.0
        var y0 : Float = 0.0
        var pt = NSPoint(x: 0.0, y: 0.0)
        var ptArray : [NSPoint] = []
        let commaSemicolonSpace : CharacterSet = CharacterSet(charactersIn: ",; ")
        if let sc = Scanner.localizedScanner(with: str) as? Scanner {
            sc.charactersToBeSkipped = commaSemicolonSpace
            while !sc.isAtEnd {
                if sc.scanFloat(&x0) {
                    pt.x = CGFloat(x0)
                    if sc.scanFloat(&y0) {
                        pt.y = CGFloat(y0)
                    }
                    ptArray.append(pt)
                }
            } // End of while loop
        }
        return ptArray
    } // End of func ptArrayFromString
    
    
    /// extremeValuesForVariate. Called by histogram generators to find most negative and most positive values in fData[][]
    ///
    /// - Parameter variate: variate
    func extremeValuesForVariate(_ variate : Int) {
        mostNegativeValue[variate] = fData[1][variate]
        mostPositiveValue[variate] = fData[1][variate]
        for i in 2...totalEvents
        {
            if fData[i][variate] <= mostNegativeValue[variate] {
                mostNegativeValue[variate] = fData[i][variate]
            } else if fData[i][variate] > mostPositiveValue[variate] {
                mostPositiveValue[variate] = fData[i][variate]
            }
        }
        print("extremeValuesForVar: \(variate) neg: \(mostNegativeValue[variate]) pos: \(mostPositiveValue[variate])")
    } // End of extremeValuesForVariate
    
    
    /// rValueForNegativeRange. Called from extremeValuesForVariate. Cumulative distribution function (cdf) for negative range of fData[][]. Used for Logicle r in UnivariateHistogram.swift
    ///
    /// - Parameter variate: variate
    /// - Returns: r value. r is position of 5th percentile (0.05) of cdf
    func rValueForNegativeRange(_ variate: Int) -> Double {
        var cdf = [Double]()
        // 1) Create array of negative values of fData[][myVariate]
        var negFData = [Double]()
        for event in 1...totalEvents {
            if fData[event][variate] < 0.0 {
                negFData.append(fData[event][variate])
            }
        } // End of for event in 1...totalEvents
        negFData.sort() // Sort ascending in place.
        let numberOfNegativeValues = Double(negFData.count) // total number of negative values.
        var event = 0
        while event < negFData.count {
            event += 1
            cdf.append(Double(event) / numberOfNegativeValues)
        }
        event = 0
        while cdf[event] <= 0.05 {
            event += 1
        }
        let r = negFData[event] // r is position of 5th percentile (0.05) of cdf
        return r
    } // End of rValueForNegativeRange
    
    
    /// variateNumberForString
    ///
    /// - Parameter str: String containing spillVar (spill variate)
    /// - Returns: spillVar
    func variateNumberForString(_ str : String) -> Int? {
        var spillVar = 0
        for variate in 1...variates {
            if str == PnN[variate] {
                spillVar = variate
                break;
            }
        } // End of loop over variate
        return spillVar
    } // End of variateNumberForString

} // End of class ReadAndParse

