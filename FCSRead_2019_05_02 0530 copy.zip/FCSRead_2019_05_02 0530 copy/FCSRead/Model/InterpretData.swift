//
//  InterpretData.swift Called from ReadAndParse.loadDataIntoArray() to convert the packed raw data (Data) into fData[event][variate]. It uses NewByteBackpacker.swift.
//  FCSRead
//
//  Created by Mr. Salzman on 3/7/17.
//  Copyright © 2017 Gary Salzman. All rights reserved.
//

import Foundation

class InterpretData {
    
    var rd: ReadAndParse?
    var dataIn = Data()
    var data = [Byte]()
    
    
    /// init initializes InterpretData and passes in an instance of ReadAndParse
    ///
    /// - Parameter readAndParse: ReadAndParse instance
    init(_ readAndParse: ReadAndParse) {
        rd = readAndParse
    } // End of init
    
    
    /// intEvent parses the data for one event (a cell) and returns [Double] whose length is the number of variates + 1 (zeroth unused)
    ///
    /// - Returns: an array of doubles consisting of one event
    func intEvent() -> [Double] {
        var start = 0
        var end = 0
        var val32: UInt32 = 0
        var val16: UInt16 = 0
        var val8: UInt8 = 0
        var event = Array(repeating: 0.0, count: rd!.variates + 1)
        
        for variate in 1...rd!.variates {
            let byteCount = rd!.PnB[variate] / 8 // byteCount is 4, 2, or 1
            start = rd!.byteIndex
            end = start + byteCount
            let rng: Range = start..<end
            let dataIn = rd!.myData!.subdata(in: rng)
            var data = [UInt8]()
            data = (rd!.byteOrder == ByteOrder.littleEndian) ? dataIn.toByteArray() : dataIn.toByteArray().reversed() // Set in ReadAndParse.requiredValuesForKeys. Struct is in NewByteBackpacker.swift.
            if byteCount == 4 {
                val32 = ByteBackpacker.unpack(data, toType: UInt32.self, byteOrder: rd!.byteOrder)
                event[variate] = Double(val32)
            } else if byteCount == 2 {
                val16 = ByteBackpacker.unpack(data, toType: UInt16.self, byteOrder: rd!.byteOrder)
                event[variate] = Double(val16)
            } else if byteCount == 1 {
                val8 = ByteBackpacker.unpack(data, toType: UInt8.self, byteOrder: rd!.byteOrder)
                event[variate] = Double(val8)
            } else {}
            rd!.byteIndex += byteCount
        } // End of loop over variate
        return event
    } // End of intEvent
    
    
    /// fDEvent unpacks "F" or "D" Data into fData[][]. dataType "F" or "D". step is 4 bytes for "F" and 8 bytes for "D".
    ///
    /// - Returns: an array of doubles consisting of one event
    func fDEvent() -> [Double] { 
        var start = 0
        var end = 0
        var event = Array(repeating: 0.0, count: rd!.variates + 1)
        
        for variate in 1...rd!.variates {
            let byteCount = rd!.PnB[variate] / 8 // byteCount is 4 or 8
            start = rd!.byteIndex
            end = start + byteCount
            let rng: Range = start..<end
            dataIn = rd!.myData!.subdata(in: rng)
            data = dataIn.toByteArray() // .bigEndian reversal in ByteOrder.
            if byteCount == 4 {
                let f : Float = ByteBackpacker.unpack(data, toType: Float.self, byteOrder: rd!.byteOrder)
                event[variate] = Double(f)
            } else if byteCount == 8 {
                let d : Double = ByteBackpacker.unpack(data, toType: Double.self, byteOrder: rd!.byteOrder)
                event[variate] = d
            } else {
                print("InterpretData.fDEvent dataType neither F nor D")
                exit(-1)
            }
            rd!.byteIndex += byteCount
        } // End of loop over variate
        return event
    } // End of fdTypeData

} // End of class InterpretData
