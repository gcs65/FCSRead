//
//  FastLogicle.swift calculates Logicle axis transform (linear at the bottom and logarithmic at the top)
//  FCSRead
// Modified from FastLogicle.m described in http://facs.stanford.edu/software/Logicle
// Modified by GCS 2014_01_13 to deal with illegalArgument throws.
//
//  Used for Logicle and Asinh logLikeScaleTransforms.

import Cocoa

let LN_10 = log(10.0) // 2.302585093
let EPSILON = 2.2e-16 // Arbitrary constant used by FastLogic (<2.220446e-16)

public class FastLogicle {
    var histLimits: HistLimits?
    weak var mainViewController: MainViewController? // Used in retrieveHistLimitsForVariate to get histLimits from histLimitsDict
    
    var taylor = [Double]() // Coefficients of taylor series expansion
    var lookup = [Double]()
    var bins = 0
    
    var T = 0.0 // Logicle parameters
    var W = 0.0
    var M = 0.0
    var A = 0.0
    
    var a1 = 0.0
    var b1 = 0.0
    var c1 = 0.0
    var d1 = 0.0
    var f1 = 0.0
    var w1 = 0.0
    
    var x0 = 0.0
    var x1 = 0.0
    var x2 = 0.0
    var xTaylor = 0.0
    
    
    /// init initializes instance of FastLogicle class
    ///
    /// - Parameters:
    ///   - myVar: variate whose axis is to be Logicle transformed
    ///   - myAxisType: UnivariateTag or BivariateTag
    init(myVar: Int, myAxisType: String) {
        let histLimits = histLimitsDict[myVar]!
        T = histLimits.T
        W = histLimits.W
        M = histLimits.M
        A = histLimits.A
        let defaults = UserDefaults.standard
        if myAxisType == UnivariateTag { // Global constant set in MainViewController
            bins = defaults.integer(forKey: Preferences.HistRange1PKey)
        } else if myAxisType == BivariateTag { // Global constant set in MainViewController
            bins = defaults.integer(forKey: Preferences.HistRange2PKey)
        }
        setup()
    } // End of init(myVar: Int, myAxisType: String)
    
    
    /// init initializes instance of FastLogicle class using T, W, M, and A values
    ///
    /// - Parameters:
    ///   - inputT: T value
    ///   - inputW: W value
    ///   - inputM: M value
    ///   - inputA: A value
    ///   - inputBins: number of bins for the histogram
    init(inputT: Double, inputW: Double, inputM: Double, inputA: Double, inputBins: Int) {
        T = inputT
        W = inputW
        M = inputM
        A = inputA
        bins = inputBins
        setup()
    } // End of 2nd init
    
    
    /// setup. Called by inits to set up calculations
    func setup() { // Called by inits
        lookup = [Double](repeating: 0.0, count: (bins + 1))
        if bins > 0 { // zero must be on a bin boundary
            var zero = (W + A) / (M + A)
            zero = floor((zero * Double(bins) + 0.5)) / Double(bins)
            A = (M * zero - W) / (1.0 - zero)
        }
        
        w1 = W / (M + A) // actual parameters - formulas from biexponential paper
        x2 = A / (M + A)
        x1 = x2 + w1
        x0 = x2 + (2.0 * w1)
        b1 = (M + A) * LN_10
        d1 = solveWithB(b1, w1: w1)
        let c_a = Double(exp(x0 * (b1 + d1)))
        let mf_a = exp(b1 * x1) - (c_a / exp(d1 * x1))
        a1 = T / ((exp(b1) - mf_a) - c_a / exp(d1))
        c1 = c_a * a1
        f1 = -mf_a * a1
        xTaylor = x1 + 0.25 * w1 // use Taylor series near x1, i.e., data zero to avoid round off problems of formal definition
        
        var posCoef = a1 * exp(b1 * x1) // compute coefficients of the Taylor series
        var negCoef = -c1 / exp(d1 * x1)
        // 16 is enough for full precision of typical scales
        taylor = [Double](repeating: 0.0, count: 16)
        for i in 0..<16 {
            posCoef *= b1 / (Double(i + 1))
            negCoef *= -d1 / (Double(i + 1))
            taylor[i] = posCoef + negCoef
        }
        taylor[1] = 0.0 // exact result of Logicle condition
        for i in 0...bins {
            var temp = Double(i) / Double(bins)
            lookup[i] = logicleInverseWithScale(&temp)
        }
    } // End of setup()
    
    
    /// logicleInverseWithScale is called from setup. Reflect negative scale regions.
    ///
    /// - Parameter scale: ratio of bin number to total bins [0,1]
    /// - Returns: the inverse
    func logicleInverseWithScale(_ scale: inout Double) -> Double {
        var scale = scale
        let negative: Bool = scale < x1
        if negative {
            scale = 2.0 * x1 - scale
        }
        var inverse = 0.0 // compute the biexponential
        if scale < xTaylor {
            // near x1, i.e., data zero use the series expansion
            inverse = seriesBiexponentialWithScale(scale)
        }
        else { // this formulation has better roundoff behavior
            inverse = (a1 * exp(b1 * scale) + f1) - c1 / exp(d1 * scale)
        }
        // Handle scale for negative values.
        if (negative) {
            return -inverse
        }
        else {
            return inverse
        }
    } // End of logicleInverseWithScale
    
    
    /// seriesBiexponentialWithScale
    ///
    /// - Parameter scale: ratio of bin number to total bins [0,1]
    /// - Returns: seriesBiexponential
    func seriesBiexponentialWithScale(_ scale: Double) -> Double {
        // Taylor series is around x1
        let x = scale - x1
        // Note that taylor[1] should be identically zero according to the Logicle condition so skip it here.
        var sum = taylor[15] * x
        var i = 14
        while i >= 2 {
            sum = (sum + taylor[i]) * x
            i -= 1
        }
        return (sum * x + taylor[0]) * x
    } // End of seriesBiexponentialWithScale
    
    
    /// scaleWithValue looks up the neearest value - uses intScale(value)
    ///
    /// - Parameter value: value
    /// - Returns: nearest value in lookup array
    func scaleWithValue(_ value: Double) -> Double {
        let index = intScaleWithValue(value) // inverse interpolate the table linearly
        let delta = (value - lookup[index]) / (lookup[index + 1] - lookup[index])
        return (Double(index) + delta) / Double(bins)
    } // End of scaleWithValue
    
    
    /// inverseWithScale. Sets histLimits.xMinLin for Logicle and Asinh. Data value for a given scale position. Scale range = [0,1). Find the bin
    ///
    /// - Parameter scale: scale value
    /// - Returns: nearest value in lookup array
    func inverseWithScale(_ scale: Double) -> Double {
        let x = scale * Double(bins)
        var index = Int(floor(x))
        if index < 0 {
            index = 0
        }
        if index >= bins {
            index = bins - 1
        }
        // Interpolate the table linearly.
        let delta = x - Double(index)
        return (1.0 - delta) * lookup[index] + delta * lookup[index + 1]
    } // End of inverseWithScale

    
    /// solveWithB. Called from setup(), which is called by init
    ///
    /// - Parameters:
    ///   - b1: first input parameter
    ///   - w1: second input parameter
    /// - Returns: root computed by solveWithB
    func solveWithB(_ b1: Double, w1: Double) -> Double {
        if (w1 == 0) { // w1 == 0 means it's really arcsinh
            return b1;
        }
        let tolerance = 2.0 * b1 * EPSILON // precision is the same as that of b1
        // Based on RTSAFE from Numerical Recipes 1st Edition: bracket the root
        var d_lo = 0.0
        var d_hi = b1
        var d = 0.5 * (d_lo + d_hi) // bisection first step
        var last_delta = d_hi - d_lo
        var delta = 0.0
        // evaluate the f(w,b) = 2 * (ln(d) - ln(b)) + w * (b + d) and its derivative.
        let f_b = -2.0 * log(b1) + w1 * b1
        var f = 2.0 * log(d) + w1 * d + f_b
        var last_f = Double.nan
        for _ in 1..<20 {
            let df = (2.0 / d) + w1 // Compute the derivative if Newton's method would step outside the bracket or if it isn't converging quickly enough.
            let temp1 = ((d - d_hi) * df - f) * ((d - d_lo) * df - f)
            if temp1 >= 0 || (abs(1.9 * f) > abs(last_delta * df)) {
                delta = 0.5 * (d_hi - d_lo) // take a bisection step
                d = d_lo + delta
                if (d == d_lo) {
                    return d; // nothing changed, we're done
                }
            } else { // otherwise take a Newton's method step
                delta = f / df
                let t = d
                d -= delta
                if (d == t) {
                    return d // nothing changed, normal return.
                }
            } // End of Newton's method step
            if abs(delta) < tolerance { // If we've reached the desired precision we're done.
                return d // Normal return.
            }
            last_delta = delta
            f = 2.0 * log(d) + w1 * d + f_b // recompute the function
            if f == 0 || f == last_f {
                return d; // found the root or are not going to get any closer
            } // Successful return from solveWithB
            last_f = f
            if f < 0 { // update the bracketing interval
                d_lo = d
            } else {
                d_hi = d
            }
        } // End of for _ in 1..<20 [fails if we get here]
        print("FastLogicle:solveWithB exceeded max iterations.")
        return 0.0        
    } // End of solveWithB
    
    
    /// axisLabels
    ///
    /// - Returns: [Double] of axis label positions
    func axisLabels() -> [Double] {
        // number of decades in the positive logarithmic region
        let pd = M - 2.0 * W
        // Smallest power of 10 in the region
        let log10x = ceil(log(T) / LN_10 - pd)
        // Data value at that point
        var x = exp(LN_10 * log10x)
        // Number of positive labels
        var np = 0
        if x > T {
            x = T
            np = 1
        }
        else {
            np = Int(floor(log(T) / LN_10 - log10x)) + 1
        }
        // Bottom of scale
        let B = inverseWithScale(0.0)
        // Number of negative labels
        var nn = 0
        if x > -B {
            nn = 0
        }
        else if x == T {
           nn = 1
        }
        else {
            nn = Int(floor(log(-B) / LN_10 - log10x)) + 1
        }
        
        // Fill in the axis labels
        var label = [Double](repeating: 0.0, count: nn + np + 1)
        label[nn] = 0.0
        if nn > 0 {
            for i in 1...nn {
                label[nn - i] = -x
                label[nn + i] = x
                x *= 10.0
            }
        }
        
        for i in nn + 1 ... np {
            label[nn + i] = x
            x *= 10.0
        }
        
        return label
        
    } // End of axisLabels
    
    
    /// intScaleWithValue. Binary search for appropriate bin.
    ///
    /// - Parameter value: input value (Double)
    /// - Returns: appropriate Int value
    func intScaleWithValue(_ value: Double) -> Int {
        var lo = 0
        var hi = bins
        var mid = 0
        var key = 0.0
        while lo <= hi {
            mid = (lo + hi) >> 1
            key = lookup[mid]
            if value < key {
                hi = mid - 1
            }
            else if value > key {
                lo = mid + 1
            }
            else if mid < bins {
                return mid
            }
            else {
                // equal to table[bins] which is for interpolation only
                // throw IllegalArgument(value);
                // NSLog(@"FRFastLogicle:intScale:value %f illegal.", value);
                return bins - 1
            }
        } // End of while loop
        
        // Check for out of range
        if hi < 0 || lo > bins {
            // throw IllegalArgument(value);
            // NSLog(@"FRFastLogicle:intScale:value %f out of range.", value);
            return 0
        }
        
        return lo - 1
        
    } // End of intScaleWithValue

} // End of FastLogicle class
