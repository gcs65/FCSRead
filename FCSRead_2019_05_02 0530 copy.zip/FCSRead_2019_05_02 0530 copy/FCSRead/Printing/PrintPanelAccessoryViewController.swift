//
//  PrintPanelAccessoryViewController.swift
//  FCSRead
//
//  Created by Mr. Salzman on 9/25/16.
//  Copyright © 2016 Aventuras Publishers LLC. All rights reserved.
//

import Cocoa

class PrintPanelAccessoryViewController: NSViewController, NSPrintPanelAccessorizing {
    
    
    weak var printInfo = NSPrintInfo.shared
    let defaults = UserDefaults.standard
    var pageNumbering = true
    var showHeaderAndFooter = true

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do view setup here.
    }
    
//    required init(coder aDecoder: NSCoder) {
//        super.init(coder: aDecoder)!
//    }
    
    var windowNibName: String? {
        return "PrintPanelAccessoryViewController"
    }
    
    override var representedObject: Any? {
        didSet {
            printInfo = representedObject as? NSPrintInfo
            pageNumbering = ((defaults.object(forKey: Preferences.NumberPagesWhenPrintingKey)) != nil)
            showHeaderAndFooter = ((defaults.object(forKey: Preferences.ShowHeaderAndFooterKey)) != nil)
        }
    }
    
//    var pageNumbering = true
    
//    var pageNumbering: Bool {
//        get {
//            return ((printInfo?.dictionaryWithValues(forKeys: [NSPrintInfo.AttributeKey.headerAndFooter.rawValue])) != nil)
//        }
//        set {
//            // self.pageNumbering = newValue
//        }
//    }
    
//    @IBAction func changePageNumbering(_ sender: AnyObject) {
//        pageNumbering = (sender as! Bool) ? true : false
//    }

    // in NSPrintPanelAccessorizing Protocol Reference
//    func keyPathsForValuesAffectingPreview() -> Set<String> {
//        var mySet = Set<String>()
//        mySet.insert("pageNumbering")
//        return mySet
//    }

    // This enables TextEdit-specific settings to be displayed in the Summary pane of the print panel. Required method in NSPrintPanelAccessorizingProtocol.
    func localizedSummaryItems() -> [[NSPrintPanel.AccessorySummaryKey : String]] { // returns array of dictionaries.
        var items = [[NSPrintPanel.AccessorySummaryKey.itemName : String()]]
        items.append([NSPrintPanel.AccessorySummaryKey.itemName:"PrintPanelAccessory"])
        items.append([NSPrintPanel.AccessorySummaryKey.itemDescription : "Header and Footer"])
//        items.append(NSPrintPanel.AccessorySummaryKey.itemName: "Header and Footer", "PrintPanelAccessory", "Print panel summary item title for whether header and footer (page number, date, document title) should be printed",
//                          "On", "PrintPanelAccessory", "Print panel summary value for feature that is enabled"), "Off", "PrintPanelAccessory", "Print panel summary value for feature that is disabled"

        return items

    } // End of localizedSummaryItems
//    var cart = [[String : String]]()
//    cart.append(["key1": "one"])
//    cart.append(["key2": "two"])
//    print(cart)
    
} // End of PrintPanelAccessoryViewController
