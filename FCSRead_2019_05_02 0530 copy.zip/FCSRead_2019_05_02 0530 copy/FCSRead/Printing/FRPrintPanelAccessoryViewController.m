//
//  FRPrintPanelAccessoryViewController.m
//  FCSRd
//
//  Created by Mr. Salzman on 12/14/13.
//  Copyright (c) 2013 Gary Salzman. All rights reserved.
//

#import "FRPrintPanelAccessoryViewController.h"

@interface FRPrintPanelAccessoryViewController ()

@end

@implementation FRPrintPanelAccessoryViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:@"PrintPanelAccessoryViewController" bundle:nibBundleOrNil];
    if (self) {
        // Initialization code here.
        NSLog(@"FRPrintPanelAccessoryViewController.init");
    }
    return self;
}


/* The first time the printInfo is supplied, initialize the value of autoRotate setting  and scaleToFit setting from defaults
 */
- (void)setRepresentedObject:(id)printInfo {
    NSLog(@"FRPrintPanelAccessoryViewController.setRepresentedObject");
    [super setRepresentedObject:printInfo];
    [self setPageNumbering:[[[NSUserDefaults standardUserDefaults]
            objectForKey:NumberPagesWhenPrinting] boolValue]];
}

- (void)setPageNumbering:(BOOL)flag { // called by changePageNumbering
    NSPrintInfo *printInfo = [self representedObject];
    [printInfo dictionary][NSPrintHeaderAndFooter] = @(flag);
    NSLog(@"FRPrintPanelAccessoryViewController.setPageNumbering");
}

- (BOOL)pageNumbering {
    NSPrintInfo *printInfo = [self representedObject];
    return [[printInfo dictionary][NSPrintHeaderAndFooter] boolValue];
}


- (IBAction)changePageNumbering:(id)sender
{
    [self setPageNumbering:[sender state] ? YES : NO];
}

// in NSPrintPanelAccessorizing Protocol Reference
- (NSSet *)keyPathsForValuesAffectingPreview {
    NSLog(@"keyPathsForValuesAffectingPreview");
    return [NSSet setWithObjects:@"pageNumbering", nil];
}


/* This enables TextEdit-specific settings to be displayed in the Summary pane of the print panel. Required method in NSPrintPanelAccessorizingProtocol.
 */
- (NSArray *)localizedSummaryItems {
    NSLog(@"FRPrintPanelAccessoryViewController.localizedSummaryItems"); // Not called.
    NSMutableArray *items = [NSMutableArray array];
    // NSLocalizedStringFromTable(key, tbl, comment)
    [items addObject:@{NSPrintPanelAccessorySummaryItemNameKey: NSLocalizedStringFromTable(@"Header and Footer", @"PrintPanelAccessory", @"Print panel summary item title for whether header and footer (page number, date, document title) should be printed"),
          NSPrintPanelAccessorySummaryItemDescriptionKey: [self pageNumbering] ? NSLocalizedStringFromTable(@"On", @"PrintPanelAccessory", @"Print panel summary value for feature that is enabled") : NSLocalizedStringFromTable(@"Off", @"PrintPanelAccessory", @"Print panel summary value for feature that is disabled")}];
    
   
    return items;
}

@end
