//
//  StatisticsPanel.swift
//  FCSRead
//
//  Created by Mr. Salzman on 3/30/19.
//  Copyright © 2019 Aventuras Publishers LLC. All rights reserved.
//

import Cocoa

class StatisticsPanel: NSWindowController {

//    weak var graphicSubview: GraphicSubview?
    @IBOutlet weak var gateCountValueTextField: NSTextField!
    @IBOutlet weak var q0ValueTextField: NSTextField!
    @IBOutlet weak var q1ValueTextField: NSTextField!
    @IBOutlet weak var q2ValueTextField: NSTextField!
    @IBOutlet weak var q3ValueTextField: NSTextField!
    @IBOutlet weak var gateCountPercentTF: NSTextField!
    @IBOutlet weak var q0PercentTF: NSTextField!
    @IBOutlet weak var q1PercentTF: NSTextField!
    @IBOutlet weak var q2PercentTF: NSTextField!
    @IBOutlet weak var q3PercentTF: NSTextField!
    
    override func windowDidLoad() {
        super.windowDidLoad()
        gateCountValueTextField.integerValue = 0 // RectGate, EllipseGate, PolygonGate
        gateCountPercentTF.doubleValue = 0.0
        q0ValueTextField.integerValue = 0 // Lower left quadrant
        q1ValueTextField.integerValue = 0 // Lower right quadrant
        q2ValueTextField.integerValue = 0// Upper left quadrant
        q3ValueTextField.integerValue = 0// Upper right quadrant
        q0PercentTF.doubleValue = 0.0
        q1PercentTF.doubleValue = 0.0
        q2PercentTF.doubleValue = 0.0
        q3PercentTF.doubleValue = 0.0
    }
    
    override init(window: NSWindow?) {
        super.init(window: window)
    }
    
    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
    }
    
    override var windowNibName: NSNib.Name? {
        return "StatisticsPanel" // StatisticsPanel.xib
    } // End of windowNibName
    
    override func awakeFromNib() { // Methods below must be called AFTER nib file is loaded so that iVars are instantiated by the nib file and are not nil.
    } // End of awakeFromNib
    
    @IBAction func close(_ sender: Any) {
        close()
    }
} // End of class StatisticsPanel
