//
//  GRSVExtSupport.swift handles mouseDown, mouseMoved and mouseUp events.
//  FCSRead
//
//  Created by Mr. Salzman on 3/24/16.
//  Copyright © 2019 Gary Salzman. All rights reserved.
//

import Cocoa

extension GraphicSubview { // GRSVExtSupport
    
    override func acceptsFirstMouse(for theEvent: NSEvent?) -> Bool {
        
        return true
        
    } // End of acceptsFirstMouse
    
    
    /// mouseDown. Left mouse down. RectGate, QuadGate, or PolygonGate created (gateActionMode == 0) and/or edited (gateActionMode == 1) here.
    ///
    /// - Parameter event: left mouseDown event
    override func mouseDown(with event: NSEvent) {
        super.mouseDown(with: event)
        
        if mouseInsideHistogramBox == false { // Left mouse down outside histogramBox is ignored.
            return
        }
        
        if currentGateTypeSetting == CreateNoGateTag {
            return
        }
        
        if gateActionMode == 0 { // Creating gate. Select gate type and start tracking.
            if currentGateTypeSetting == CreateQuadrantGateTag {
                currentGateClass = QuadGate.self
                createQuadGateEvent(event) // In GRSVExtQuadMouseEvents
            }
            else if currentGateTypeSetting == CreatePolygonGateTag {
                currentGateClass = PolygonGate.self
                createPolygonGate(event) // GRSVExtPolyMouseEvent
            }
            else if currentGateTypeSetting == CreateRectangleGateTag || currentGateTypeSetting == CreateEllipseGateTag {
                currentGateClass = RectGate.self
                createRectGateEvent(event) // In GRSVExtRectMouseEvents
            }
            else {
                // currentGateClass has not been selected so do nothing.
                return
            }
                        
        } // End of creating gate (gateActionMode == 0)
            
        else if gateActionMode == 1 { // Editing gate. Select gate type and start tracking.
            if currentGateClass == RectGate.self {
                if rectGate!.rotationAngle == 0 { // rectangle gate or nonrotated ellipse gate
                    selectAndTrackRectMouseWithEvent(event)
                }
                else { // Rotated ellipse
                    selectAndTrackEllipseMouseWithEvent(event)
                }
            } // End of currentGateClass = RectGate.self
                
            else if currentGateClass == PolygonGate.self {
                selectAndTrackPolyMouseWithEvent(event)
            }
                
            else {
                selectAndTrackQuadMouseWithEvent(event) // In GRSVExtQuadMouseEvents
            }
            
        } // End of editing gate (gateActionMode = 1)
            
        else {}
        
        if quadGate != nil && quadGate?.quadRectsExist == true {
            // Special case for quadrant rectangle. Combine adjacent quadRects and relabel if quadRects exist. quadGate created, GraphicView:gateTheData, which calls QuadGate:createQuadGateRectangles
            
            // Shift key down sets modifyingExistingSelection to true
            
            if event.modifierFlags.contains(NSEvent.ModifierFlags.shift) {
                print("Shift key down on left mouse down over quadRect")
            }
                setNeedsDisplay(innerBoxDrawingBounds())
                return
        } // End of combine adjacent quadRects and relabel if quadRects exist.
        
    } // End of (left) mouseDown
    
    
    /// mouseMoved. If mouseInsideHistogramBox, drawRect displays the coordinates. mouseGraphicLocation ranges from [xOffset, yOffset] to [innerBoxWidth+xOffset, innerBoxHeight+yOffset]
    ///
    /// - Parameter event: mouseMoved event
    override func mouseMoved(with event: NSEvent) {
        super.mouseMoved(with: event)
        
        if showCursorLocationSetting == 1 { // Show/Hide cursor effects - constrain to histogramBox. mouseGraphicLocation is same as mouseWindowLocation. It has the x- and y- offsets built in.
            let mouseWindowLocation = convert(event.locationInWindow, from: nil)
            mouseGraphicLocation = mouseWindowLocation
            constrainPointToHistogramBox(&mouseGraphicLocation)
            mouseRealLocation = realPointGivenGraphicPoint(mouseGraphicLocation)
            display()
        } // End of showCursorSetting == 1
        
    } // End of mouseMoved
    
    
    /// mouseUp. Left mouse up. Lower priority than mouseDown.
    ///
    /// - Parameter theEvent: mouseUp event
    override func mouseUp(with theEvent: NSEvent) {
        super.mouseUp(with: theEvent)
    } // End of mouseUp
    
    func constrainPointToHistogramBox(_ point: inout NSPoint) {
        if point.x < histogramGraphic!.xOffset {
            point.x = histogramGraphic!.xOffset
        }
        if point.x > histogramGraphic!.xOffset + histogramGraphic!.innerBoxWidth {
            point.x = histogramGraphic!.xOffset + histogramGraphic!.innerBoxWidth
        }
        
        if point.y < histogramGraphic!.yOffset {
            point.y = histogramGraphic!.yOffset
        }
        if point.y > histogramGraphic!.yOffset + histogramGraphic!.innerBoxHeight {
            point.y = histogramGraphic!.yOffset + histogramGraphic!.innerBoxHeight
        }
    } // End of constrainPointToHistogramBox
    
} // End of GRSVExtSupport
