//
//  ACPExtYAxis.swift is an extension of the AxesChangePanel class to support y axis manipulations. func descriptions are similar to those in ACPExtXAxis.swift.
//  FCSRead
//
//  Created by Mr. Salzman on 4/8/16.
//  Copyright © 2019 Gary Salzman. All rights reserved.
//

import Cocoa

extension AxesChangePanel { // ACPExtYAxis.swift Y-AXIS ***********
    
    func setStateForYVariates() { // Called from setCurrentParameters(). Sets yAxis radio button state depending on myYAxisType.
        switch myYAxisType {
        case LinearTag:
            enableLinearY()
        case LogTag:
            enableLogY()
        case LogicleTag, HyperlogTag, AsinhTag:
            if graphicSubview?.histogramType == BivariateTag {
                enableAllY()
            }else { // UnivariateTag
                disableAllY()
                enableLinearY()
                enableLogY()
            }
        default:
            disableAllY()
        }
    } // End of setStateForYVariates
    
    func enableLinearY() {
        if myYAutoScaleEnabled == false {myYLinEnabled = true}
        myYLogEnabled = false
        myYTEnabled = false
        myYWEnabled = false
        myYMEnabled = false
        myYAEnabled = false
    } // End of enableLinearY
    
    func enableLogY() {
        myYLinEnabled = false
        if myYAutoScaleEnabled == false {myYLogEnabled = true}
        myYTEnabled = false
        myYWEnabled = false
        myYMEnabled = false
        myYAEnabled = false
    } // End of enableLogY
    
    func enableLogLikeY() {
        myYLinEnabled = false
        myYLogEnabled = false
        myYTEnabled = true
        myYWEnabled = true
        myYMEnabled = true
        myYAEnabled = true
    } // End of enableLogLikeY
    
    func enableAllY() {
        myYLinEnabled = true
        myYLogEnabled = true
        myYTEnabled = true
        myYWEnabled = true
        myYMEnabled = true
        myYAEnabled = true
    } // End of enableAllY
    
    func disableAllY() {
        myYLinEnabled = false
        myYLogEnabled = false
        myYTEnabled = false
        myYWEnabled = false
        myYMEnabled = false
        myYAEnabled = false
    } // End of disableAllY
    
    @IBAction func yAxisButtonPressed(sender: NSButton) {
        for aButton in yAxisButtonList() {
            if aButton == sender {
                aButton.state = NSControl.StateValue.on
                yAxisTypeFromYRadioState(button: aButton)
                setStateForYVariates()
                ok(aButton) // Update histogram
            } else {
                aButton.state = NSControl.StateValue.off
            }
        }
    } // End of @IBAction func yAxisButtonPressed
    
    func yAxisTypeFromYRadioState(button: NSButton) { // Called from yAxisButtonPressed. Sets yAxisType.
        for button in yAxisButtonList() {
            if button.state == NSControl.StateValue.on {
                switch button {
                case yLinearRadio:
                    myYAxisType = LinearTag
                case yLogRadio:
                    myYAxisType = LogTag
                case yLogicleRadio:
                    myYAxisType = LogicleTag
                case yHyperlogRadio:
                    myYAxisType = HyperlogTag
                case yAsinhRadio:
                    myYAxisType = AsinhTag
                default:
                    myYAxisType = ""
                }
            }
            if graphicSubview!.histogramType == UnivariateTag {
                histLimitsX!.yAxisType = yAxisType
            } else { // BivariateTag
                histLimitsY!.xAxisType = yAxisType
            }
        }
    } // End of yAxisTypeFromYRadioState
    
    func yAxisRadioState() { // Called from setCurrentParameters(). Sets y-axis radio button states depending on myYAxisType.
        if graphicSubview?.histogramType == UnivariateTag {
            myYLogicleScaleEnabled = false
            myYHyperlogScaleEnabled = false
            myYAsinhScaleEnabled = false
        } else { // BivariateTag
            myYLogicleScaleEnabled = true
            myYHyperlogScaleEnabled = true
            myYAsinhScaleEnabled = true
        }
        switch myYAxisType {
        case LinearTag:
            yLinearRadio.state = NSControl.StateValue.on
        case LogTag:
            yLogRadio.state = NSControl.StateValue.on
        case LogicleTag:
            yLogicleRadio.state = NSControl.StateValue.on
        case HyperlogTag:
            yHyperlogRadio.state = NSControl.StateValue.on
        case AsinhTag:
            yAsinhRadio.state = NSControl.StateValue.on
        default:
            print("myYAxisType: \(myYAxisType)")
            exit(-1)
        }
    } // End of xAxisRadioState
    
    func restrictYLogicleParameters() { // Called from yAxisTypeMatrixAction
        // T & M > 0 and W >= 0 guaranteed by numberFormatters
        if myYW > 0.5 * myYM {
            myYW = 0.5 * myYM // range is linear at yW = 0.5 * yM
        }
        if -myYA > myYW || -myYA + myYW > myYM - myYW {
            myYA = -myYW
        }
    } // End of restrictYLogicleParameters
    
    func restrictYLogLimits() { // Restrict xMinLog and yMaxLog to major or minor tic positions. Major tic positions at 10^-1, 10^0, etc. Minor tic positions in between: 0.2, 0.3...200, 300, 400... For example, yMinLog value of 0.25 converted to 0.2. Force yMinLog to minor tic decades (25->20, etc.)
        var base = 0.0
        var temp = 0.0
        
        if yMinLog == 0.0 {
            yMinLog = 1.0
        }
        base = floor(log10(yMinLog)) // = -1 for yMinLog = (0,1)???
        temp = yMinLog * pow(10.0, -base) // temp = (1,10)
        yMinLog = floor(temp) * pow(10.0, base)
        // Force yMaxLog to next higher minor tic decade.
        if yMaxLog == 0.0 {
            yMaxLog = 1.0
        }
        base = floor(log10(yMaxLog))
        temp = yMaxLog * pow(10.0, -base)
        yMaxLog = ceil(temp) * pow(10.0, base)
        print("restrictYLogLimits yMinLog: \(yMinLog) yMaxLog: \(yMaxLog)")
    } // End of restrictYLogLimits

} // End of extension AxesChangePanel for ACPExtYAxis
