//
//  GRSVExtRightMouse.swift. Create right click popup contextual menu for gating setup and manipulation.
//  FCSRead
//  Created by Mr. Salzman on 1/3/16.
//  Copyright © 2019 Gary Salzman. All rights reserved.
//
// Functions in GRSVExtensionRightMouse.swift
// override func rightMouseDown(theEvent: NSEvent)
// func popUpMenu(myEvent: NSEvent)
// func showCursorLocationSetup(sender: AnyObject)
// func createRectangleGateSetup(sender: AnyObject)
// func createEllipseGateSetup(sender: AnyObject)
// func createPolygonGateSetup(sender: AnyObject) (empty)
// func createQuadrantGatePointSetup(sender: AnyObject) (empty)
// func createAndShowQuadrantRectsSetup(sender: AnyObject) (empty)
// func mergeSelectedQuadrantGateSetup(sender: AnyObject) (empty)
// func moveOrResizeGateSetup(sender: AnyObject) (empty)
// func gateTheDataSetup(sender: AnyObject) (empty)
// func ungateTheDataSetup(sender: AnyObject) (empty)
// func deleteGateSetup(sender: AnyObject)
// func deleteAllGatesSetup(sender: AnyObject) (empty)
// func changeAxesSetup(sender: AnyObject) (empty)
// func deleteGate() (empty)
// override func validateMenuItem(menuItem: NSMenuItem) -> Bool

import Cocoa

extension GraphicSubview { // GRSVExtensionRightMouse
    
    
    /// rightMouseDown creates popup contextual menu. The funcs below are all involved in setting up and executing the popup menu.
    ///
    /// - Parameter theEvent: rigth mouseDown event
    override func rightMouseDown(with theEvent: NSEvent) {
        super.rightMouseDown(with: theEvent)
        if mouseInsideHistogramBox {
            popUpMenu(theEvent) // below
        }
        else {
            return
        }
        
    } // End of rightMouseDown: right click contextual menu.
    
    
    /// popUpMenu creates popup menu.
    ///
    /// - Parameter myEvent: rightMouse event
    func popUpMenu(_ myEvent: NSEvent) {
        
        var rightClickMenu: NSMenu?
        var newItem: NSMenuItem?
        let radioButtonImage = NSImage(named: "NSMenuRadio")
        
        rightClickMenu = NSMenu.init(title: "Create-Edit Menu")
        
        // Show/Hide cursor location
        if showCursorLocationSetting == 0 { // Cursor is currently hidden, setup to show it.
           newItem = rightClickMenu?.addItem(withTitle: "Show Cursor Location", action: #selector(GraphicSubview.showCursorLocationSetup(_:)), keyEquivalent: "")
            newItem!.tag = ShowCursorLocationTag
            newItem!.onStateImage = radioButtonImage
        }
        else { // Cursor is currently showing, setup to hide it.
           rightClickMenu?.addItem(withTitle: "Hide Cursor Location", action: #selector(GraphicSubview.showCursorLocationSetup(_:)), keyEquivalent: "")
        }
        
        rightClickMenu?.addItem(NSMenuItem.separator()) // Separator
        
        // Create rectangular gate
        newItem = rightClickMenu?.addItem(withTitle: "Create Rectangle Gate", action: #selector(GraphicSubview.createRectangleGateSetup(_:)), keyEquivalent: "")
        newItem!.tag = CreateRectangleGateTag
        newItem!.onStateImage = radioButtonImage
        
        // EllipseGate, PolygonGate, and QuadrantGate only for bivariate histograms
        
        if histogramType == BivariateTag {
            
            rightClickMenu?.addItem(NSMenuItem.separator()) // Separator
            
            // Create EllipseGate menu item.
            newItem = rightClickMenu?.addItem(withTitle: "Create Ellipse Gate", action: #selector(GraphicSubview.createEllipseGateSetup(_:)), keyEquivalent: "")
            newItem!.tag = CreateEllipseGateTag
            newItem!.onStateImage = radioButtonImage
            
            // Rotate EllipseGate menu item.
            newItem = rightClickMenu?.addItem(withTitle: "    Rotate EllipseGate", action: #selector(rotateEllipseGateSetup(_:)), keyEquivalent: "") // func in RectGate.swift
            newItem!.tag = RotateEllipseGateTag
            newItem!.onStateImage = radioButtonImage
            
            rightClickMenu?.addItem(NSMenuItem.separator()) // Separator
            
            // Create PolygonGate menu item.
            newItem = rightClickMenu?.addItem(withTitle: "Create Polygon Gate", action: #selector(GraphicSubview.createPolygonGateSetup(_:)), keyEquivalent: "")
            newItem!.tag = CreatePolygonGateTag
            newItem!.onStateImage = radioButtonImage
            
            rightClickMenu?.addItem(NSMenuItem.separator()) // Separator
            
            // Create QuadrantGate menu item.
            newItem = rightClickMenu?.addItem(withTitle: "Create Quadrant Gate Point", action: #selector(GraphicSubview.createQuadrantGatePointSetup(_:)), keyEquivalent: "")
            newItem!.tag = CreateQuadrantGateTag
            newItem!.onStateImage = radioButtonImage
            
        } // End of if histogramType == "Bivariate"
        
        rightClickMenu?.addItem(NSMenuItem.separator()) // Separator
        
        // All histogram types continues
        
        // Move or Resize Gate menu item.
        newItem = rightClickMenu?.addItem(withTitle: "Move or Resize Gate", action: #selector(GraphicSubview.moveOrResizeGateSetup(_:)), keyEquivalent: "")
        newItem!.onStateImage = radioButtonImage
        
        rightClickMenu?.addItem(NSMenuItem.separator()) // Separator
        
        // Gate the Data with overlay menu item.
        newItem = rightClickMenu?.addItem(withTitle: "Gate the Data with overlay", action: #selector(GraphicSubview.gateTheDataSetup(_:)), keyEquivalent: "")
        newItem!.onStateImage = radioButtonImage
        
        // Gate the Quadrant Data with overlay menu item.
        newItem = rightClickMenu?.addItem(withTitle: "Gate the QuadrantData with overlay", action: #selector(GraphicSubview.gateTheQuadrantDataSetup(_:)), keyEquivalent: "")
        newItem!.onStateImage = radioButtonImage
        
        // Gate the Data sequentially menu item.
        newItem = rightClickMenu?.addItem(withTitle: "Gate the Data sequentially", action: #selector(GraphicSubview.gateTheDataSequentialSetup(_:)), keyEquivalent: "")
        newItem!.onStateImage = radioButtonImage
        // Ungate the Data menu item.
        newItem = rightClickMenu?.addItem(withTitle: "Ungate the Data", action: #selector(GraphicSubview.ungateTheDataSetup(_:)), keyEquivalent: "")
        newItem!.onStateImage = radioButtonImage
        // Statistics menu item.
        newItem = rightClickMenu?.addItem(withTitle: "Statistics", action: #selector(GraphicSubview.statisticsSetup(_:)), keyEquivalent: "")
        newItem!.onStateImage = radioButtonImage
        
        rightClickMenu?.addItem(NSMenuItem.separator()) // Separator
        
        // Delete Gate menu item.
        newItem = rightClickMenu?.addItem(withTitle: "Delete Gate", action: #selector(GraphicSubview.deleteGateSetup(_:)), keyEquivalent: "")
        newItem!.onStateImage = radioButtonImage
        
        // Delete All Gates menu item.
        newItem = rightClickMenu?.addItem(withTitle: "Delete All Gates", action: #selector(GraphicSubview.deleteAllGatesSetup(_:)), keyEquivalent: "")
        newItem!.onStateImage = radioButtonImage
        
        rightClickMenu?.addItem(NSMenuItem.separator()) // Separator
        
        // Change Axes menu item.
        newItem = rightClickMenu?.addItem(withTitle: "Change Axes", action: #selector(GraphicSubview.changeAxesSetup(_:)), keyEquivalent: "")
        newItem!.tag = ChangeAxesTag
        newItem!.onStateImage = radioButtonImage
        
        rightClickMenu?.addItem(NSMenuItem.separator()) // Separator
        // Overlay 2nd File menu item.
        newItem = rightClickMenu?.addItem(withTitle: "Overlay 2nd File", action: #selector(GraphicSubview.overlay2ndFileSetup(_:)), keyEquivalent: "")
        newItem!.tag = Overlay2ndFile
        newItem!.onStateImage = radioButtonImage
        
        for item: AnyObject in (rightClickMenu?.items)! {
            if let menuItem = item as? NSMenuItem {
                menuItem.target = self
            }
        }
        
        NSMenu.popUpContextMenu(rightClickMenu!, with: myEvent, for: self)
        
    } // End of popUpMenu (invoked by right click)
    
    @objc func showCursorLocationSetup(_ sender: AnyObject) {
        if showCursorLocationSetting == 0 { // Show cursor if now hidden
            showCursorLocationSetting = 1
        }
        else { // Hide cursor if now showing
            showCursorLocationSetting = 0
        }
        
    } // End of showCursorLocationSetup
    
    @objc func createRectangleGateSetup(_ sender: AnyObject) {
        deleteGateSetup(sender) // Delete any existing gate on this histogram.
        Swift.print("GRSVExtRightMouse.createRectangleGateSetup")
        currentGateTypeSetting = sender.tag
        
        // Next action will be mouseDown() (left mouse), which creates a rectGate and sets rectGate.gateType and rectGate.bounds.
    }
    
    @objc func createEllipseGateSetup(_ sender: AnyObject) {
        Swift.print("GRSVExtRightMouse.createEllipseGateSetup")
        deleteGateSetup(sender) // Delete any existing gate.
        currentGateTypeSetting = sender.tag
    }
    
    @objc func rotateEllipseGateSetup(_ sender: AnyObject) {
        Swift.print("GRSVExtRightMouse.rotateEllipseGateSetup")
        currentGateTypeSetting = sender.tag
        gateActionMode = 1
        rectGate!.showEllipseGateRotationWindow()
    }
        
    @objc func createPolygonGateSetup(_ sender: AnyObject) {
        Swift.print("GRSVExtRightMouse.createPolygonGateSetup")
        deleteGateSetup(sender) // Delete any existing gate.
        currentGateTypeSetting = sender.tag // PolygonGateTag
    }
    
    @objc func createQuadrantGatePointSetup(_ sender: AnyObject) { // This is followed by left mouse down in GRSVExtSupport.swift to set the quadPoint using createQuadGateEvent in GRSVExtQuadMouseEvents.swift.
        Swift.print("GRSVExtRightMouse.createQuadrantGatePointSetup")
        currentGateTypeSetting = sender.tag
        print("Point sender.tag: \(String(describing: sender.tag))")
    }
    
    @objc func moveOrResizeGateSetup(_ sender: AnyObject) { // Named editGateSetup in FRGraphicSubview.
        gateActionMode = 1 // Edit mode
    }
    
    @objc func gateTheDataSetup(_ sender: AnyObject) {
        Swift.print("GRSVExtRightMouse.gateTheDataSetup (overlay gating)")
        if let delegate = delegate { // Delegate is MainViewController
            if delegate.gateDictCount() == 0 { // No gates, so just return
                return
            }
            delegate.updateGateDictEntries()
            mainViewController!.isDataGated = delegate.gateTheData()
        }
    }
    
    @objc func gateTheQuadrantDataSetup(_ sender: AnyObject) {
        Swift.print("GRSVExtRightMouse.gateQuadrantTheDataSetup (overlay gating)")
        if let delegate = delegate { // Delegate is MainViewController
            if delegate.gateDictCount() == 0 { // No gates, so just return
                return
            }
            delegate.updateGateDictEntries()
            mainViewController!.isDataGated = delegate.gateTheQuadrantData()
        }
    }
    
    @objc func gateTheDataSequentialSetup(_ sender: AnyObject) {
        Swift.print("GRSVExtRightMouse.gateTheDataSequentialSetup")
        if let delegate = delegate { // Delegate is MainViewController
            if delegate.gateDictCount() == 0 { // No gates, so just return
                return
            }
            delegate.updateGateDictEntries()
            mainViewController!.isDataGated = delegate.gateTheDataSequentially()
        }
    }
    
    @objc func ungateTheDataSetup(_ sender: AnyObject) {
        Swift.print("GRSVExtRightMouse.ungateTheDataSetup")
        if let delegate = delegate { // Delegate is MainViewController
            mainViewController!.isDataGated = delegate.ungateTheData()
        }
    }
    
    @objc func statisticsSetup(_ sender: AnyObject) {
        Swift.print("GRSVExtRightMouse.statisticsSetup")
        if let delegate = delegate { // Delegate is MainViewController
            delegate.statistics()
        }
    }
    
    @objc func deleteGateSetup(_ sender: AnyObject) {
        Swift.print("GRSVExtRightMouse.deleteGateSetup.delete existing gate.")
        gateActionMode = 0
        deleteGate()
    }
    
    @objc func deleteAllGatesSetup(_ sender: AnyObject) {
        Swift.print("GRSVExtRightMouse.deleteAllGatesSetup")
        gateActionMode = 0
        if let delegate = delegate {
            delegate.deleteAllGateDictEntries() // MainViewController
        }
    }
    
    func deleteGate() { // Called by deleteGateSetup(). Delete the gate in the current histogram.
        if currentGateClass == RectGate.self {
            rectGate = nil
        }
        else if currentGateClass == PolygonGate.self {
            polygonGate = nil
        }
        else if currentGateClass == QuadGate.self {
            quadGate = nil
        }
        else {}
        
        if let delegate = delegate { // Delegate is MainViewController
            delegate.deleteGateDictEntryForKey(keyString())
        }
        
    } // End of deleteGate
    
    @objc func changeAxesSetup(_ sender: AnyObject) { // "Change Axes"
        currentAxisTypeSetting = sender.tag
        showAxesChangePanel()
    }
    
    @objc func overlay2ndFileSetup(_ sender: AnyObject) { // Overlay 2nd file
        if let delegate = delegate { // Delegate is MainViewController
            let _ = delegate.overlay2ndFile()
        }
    }
    
    func showAxesChangePanel() {
        axesChangePanel = AxesChangePanel(xVar: xVariate, yVar: yVariate, graphicSubview: self, window: window!)
        axesChangePanel!.showWindow(nil)
        
    } // End of showAxesChangePanel
    
//    func validate(_ menuItem: NSMenuItem) -> Bool { // Apparently not called.
//        // For rightMouseDown contextual menu radio buttons
//        let tag = menuItem.tag
//        
//        if tag == CreateRectangleGateTag || tag == CreateEllipseGateTag || tag == CreateQuadrantGateTag || tag == CreatePolygonGateTag {
//            menuItem.state = (tag == currentGateTypeSetting) ? NSControl.StateValue.on : NSControl.StateValue.off
//        }
//            
//        else if tag == ShowCursorLocationTag {
//            menuItem.state = NSControl.StateValue.on
//        }
//            
//        else if tag == ChangeAxesTag {
//            menuItem.state = (tag == currentAxisTypeSetting) ? NSControl.StateValue.on : NSControl.StateValue.off
//        }
//        else {}
//        
//        if tag == CreateEllipseGateTag {
//            menuItem.state = (tag == RotateEllipseGateTag) ? NSControl.StateValue.on : NSControl.StateValue.off
//        }
//        
//        return true
//        
//    } // End of validateMenuItem:
    
} // End of GraphicSubviewExtRightMouse
