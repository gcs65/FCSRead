//
//  GraphicView.swift. This is the view container for all of the graphic subviews, each of which contains a histogram graphic to draw each histogram.
//  FCSRead
//
//  Created by Mr. Salzman on 12/19/17.
//  Copyright © 2019 Gary Salzman. All rights reserved.
//

import Cocoa

class GraphicView: NSView {

    /* These values are set in AppDelegate.registrationDictionary and accessed below using Shared User Defaults.
     Preferences.OuterBoxHeightKey:510.0 as CGFloat,
     Preferences.OuterBoxWidthKey:560.0 as CGFloat,
     Preferences.InnerBoxWidthKey:400.0 as CGFloat,
     Preferences.InnerBoxHeightKey:400.0 as CGFloat,
     Preferences.XOffsetKey:120.0 as CGFloat,
     Preferences.YOffsetKey:70.0 as CGFloat,
     Preferences.FontNameKey:"Helvetica" as String,
     Preferences.FontSizeKey:12.0 as CGFloat
     */
    
    let defaults = UserDefaults.standard // class func (See AppDelegate.swift for user defaults)
    var outerBoxWidth: CGFloat {
        get { return CGFloat(defaults.float(forKey: Preferences.OuterBoxWidthKey)) }}
    var outerBoxHeight: CGFloat {
        get { return CGFloat(defaults.float(forKey: Preferences.OuterBoxHeightKey)) }}
    var innerBoxWidth: CGFloat {
        get { return CGFloat(defaults.float(forKey: Preferences.InnerBoxWidthKey)) }}
    var innerBoxHeight: CGFloat {
        get { return CGFloat(defaults.float(forKey: Preferences.InnerBoxHeightKey)) }}
    var xOffset: CGFloat {
        get { return CGFloat(defaults.float(forKey: Preferences.XOffsetKey)) }}
    var yOffset: CGFloat {
        get { return CGFloat(defaults.float(forKey: Preferences.YOffsetKey)) }}
    var fontName: String {
        get { return String(describing: defaults.string(forKey: Preferences.FontNameKey)) }}
    var fontSize: CGFloat {
        get { return CGFloat(defaults.float(forKey: Preferences.FontSizeKey)) }}

    var mySubviews = [GraphicSubview]() // Note: the built-in func subviews is somehow disabled here. The compiler thinks that it's an NSTextField in the func updateGateDictionaryEntries. **** GraphicSubview was NSView
    
    static var currentPt = NSZeroPoint // Lower left corner of histogram outer box.
    static var maxCurrentPt = NSZeroPoint // Upper right corner of outer box for highest existing histogram.
    weak var mainWindowController: MainWindowController?
    weak var mainViewController: MainViewController?
    var printingRect = NSZeroRect // Rect containing all histograms to be printed.
    var setUpPrintInfoDefaults = false
    var subViewsCreated = 0 // Used to prepare for next row above. See positionGraphicBox below.
    
    /// addMySubview appends the view to mySubviews
    ///
    /// - Parameter view: a GraphicSubview object
    func addMySubview(_ view: GraphicSubview) { // GraphicSubview was NSView ******
        mySubviews.append(view)
    }
    
    /// createSubviews. Called by MainViewController.displaySelectedHistogramsWithoutInitialization. mainViewController passed into GraphicView here. Then createSubviews passes mainViewController to each GraphicSubview.
    ///
    /// - Parameter mainVC: instance of MainViewController
    func createSubviews(_ mainVC: MainViewController) { // GraphicView. Called by MainViewController.displaySelectedHistogramsWithoutInitialization. mainViewController passed into GraphicView here. Then createSubviews passes mainViewController to each GraphicSubview.
        mainViewController = mainVC
        GraphicView.currentPt = NSZeroPoint // Start at lower-left corner.
        
        for index in 0..<mainViewController!.univariateHistogramCount { // Univariate histogram subviews
            let xVar = mainViewController!.selectedArray[index]
            let rect = positionGraphicBox()
            updateMaxCurrentPt(latestRect: rect)
            let graphicSubview1 = GraphicSubview(frame: rect, xVar: xVar, mainVC: mainViewController!) // Univariate generated in init by delegate
            addSubview(graphicSubview1)
            addMySubview(graphicSubview1)
            subViewsCreated += 1
        }
//        print("createSubviews.MVC.savedSubviews.count: \(mainViewController!.savedSubviews!.count)")
        
        for index in 0..<mainViewController!.bivariateHistogramCount { // Bivariate histogram subviews
            let xVar = mainViewController!.selectedArrayX2P[index]
            let yVar = mainViewController!.selectedArrayY2P[index]
            let rect = positionGraphicBox()
            updateMaxCurrentPt(latestRect: rect)
            let graphicSubview2 = GraphicSubview(frame: rect, xVar: xVar, yVar: yVar, mainVC: mainViewController!) // Bivariate generated in init by delegate
            addSubview(graphicSubview2)
            addMySubview(graphicSubview2)
            subViewsCreated += 1
        }
        mainWindowController!.window!.display()
     } // End of createSubviews
    
    
    /// positionGraphicBox creates an NSRect for each graphic subview. Called from createSubviews above.
    ///
    /// - Returns: rect for a graphic subview
    func positionGraphicBox() -> NSRect {
        var myFrame = NSMakeRect(GraphicView.currentPt.x, GraphicView.currentPt.y, outerBoxWidth, outerBoxHeight)
        myFrame = myFrame.integral // rect to be returned for drawing.
        if subViewsCreated < (mainViewController?.totalHistogramCount)! { // Setup for next graphic box.
            GraphicView.currentPt.x += outerBoxWidth
            if GraphicView.currentPt.x == 4 * outerBoxWidth { // 4 histograms per row. Prepare for next row above.
                GraphicView.currentPt.x = 0.0 // next row above
                GraphicView.currentPt.y += outerBoxHeight
            }
        }
        return myFrame
    } // End of positionGraphicBox
    
    
    /// updateMaxCurrentPt creates the upper rigth corner of the latest graphic subview rect.
    ///
    /// - Parameter latestRect: latest rect to be created.
    func updateMaxCurrentPt(latestRect: NSRect) { // Called from createSubviews
        var newPt = NSZeroPoint
        newPt.x = latestRect.origin.x + latestRect.width
        newPt.y = latestRect.origin.y + latestRect.height
        if GraphicView.maxCurrentPt.x < newPt.x {
            GraphicView.maxCurrentPt.x = newPt.x
        }
        if GraphicView.maxCurrentPt.y < newPt.y {
            GraphicView.maxCurrentPt.y = newPt.y
        }
    } // End of updateMaxCurrentPt
    
    /// generateOverlayUnivariateHistograms generates 2nd file univariate histograms. Called from 
    func generateOverlayUnivariateHistograms() { // In GraphicView
        mainViewController!.secondFile = true
        let myCount1 = mainViewController!.univariateHistogramCount
        for index in 0..<myCount1 {
            let xVar = mainViewController!.selectedArray[index]
            print("GraphicView.generateOverlayUnivariateHistograms: index \(index) xVar \(xVar)")
            let myGraphicSubview = mySubviews[index]
            if myGraphicSubview.uniHist!.prepareHistogram(xVar, secondFile: true) == false {
                print("GraphicView.generateOverlayUnivariateHistograms.uniHist!.prepareHistogram failed.")
            }
            myGraphicSubview.setNeedsDisplay(myGraphicSubview.innerBoxDrawingBounds())
        }
    }
    
    /// generateGatedHistograms generates gated univariate and bivariate histograms. Called from MainViewController.gateTheData()
    func generateGatedHistograms() { // In GraphicView
        mainViewController!.secondFile = false
        let myCount1 = mainViewController!.univariateHistogramCount // Univariate gated subviews *********
        for index in 0..<myCount1 { // gated univariate histograms
            let xVar = mainViewController!.selectedArray[index]
            print("GraphicView.generateGatedUnivariateHistogram: index \(index) xVar \(xVar)")
            let myGraphicSubview = mySubviews[index]
            mainViewController!.isDataGated = true
            if myGraphicSubview.uniHist!.prepareHistogram(xVar, secondFile: false) == false {
                Swift.print("uniHist!.prepareHistogram(xVar) failed.")
            }
            myGraphicSubview.setNeedsDisplay(myGraphicSubview.innerBoxDrawingBounds())
            Swift.print("univariateHistogramCount \(mainViewController!.univariateHistogramCount) gatedHistogramCount \(myGraphicSubview.uniHist!.gatedHistogramCount)")
        }
        
        let myCount2: Int = mainViewController!.bivariateHistogramCount // Bivariate gated subviews **********
        for index in 0..<myCount2 {
            let xVar = mainViewController!.selectedArrayX2P[index]
            let yVar = mainViewController!.selectedArrayY2P[index]
            Swift.print("GraphicView.generateGatedBivariateHistogram: index \(index) xVar \(xVar) yVar \(yVar)")
            let myGraphicSubview = mySubviews[index + myCount1] // *** temp
            mainViewController!.isDataGated = true
            myGraphicSubview.bivHist!.prepareBivariateHistogramForXVariate(xVar, yVar: yVar) // In BivariateHistogram.swift. Sets up histogram limits and calls bivariateHistogram to generate the bivariate histogram and the gated bivariate histogram.
            myGraphicSubview.setNeedsDisplay(myGraphicSubview.innerBoxDrawingBounds())
            Swift.print("bivariateHistogramCount \(myGraphicSubview.bivHist!.bivariateHistogramCount) gatedBivariateHistogramCount \(myGraphicSubview.bivHist!.gatedBivariateHistogramCount)")
        }
        
    } // End of generateGatedHistograms
    
    
    /// removeGatedHistograms from the histogram displays.
    func removeGatedHistograms() { // Called from MainViewController.ungateTheData()
        // Univariate gated subviews *********
        let myCount1 = mainViewController!.univariateHistogramCount
        for index in 0..<myCount1 { // gated univariate histograms
            let xVar = mainViewController!.selectedArray[index]
            Swift.print("GraphicView.removeGatedUnivariateHistogram: index \(index) xVar \(xVar)")
            let myGraphicSubview = mySubviews[index]
            mainViewController!.isDataGated = false
            if myGraphicSubview.uniHist!.prepareHistogram(xVar, secondFile: false) == false {
                Swift.print("GSV.uniHist!.prepareHistogram(xVar) failed.")
            }
            myGraphicSubview.setNeedsDisplay(myGraphicSubview.innerBoxDrawingBounds())
            Swift.print("histogramCount \(myGraphicSubview.uniHist!.histogramCount) gatedHistogramCount \(myGraphicSubview.uniHist!.gatedHistogramCount)")
        }
        
        // Bivariate gated subviews **********
        let myCount2: Int = mainViewController!.bivariateHistogramCount
        for index in 0..<myCount2 {
            let xVar = mainViewController!.selectedArrayX2P[index]
            let yVar = mainViewController!.selectedArrayY2P[index]
            Swift.print("GraphicView.removeGatedBivariateHistogram: index \(index) xVar \(xVar) yVar \(yVar)")
            let myGraphicSubview = mySubviews[index + myCount1]
            mainViewController!.isDataGated = false
            myGraphicSubview.bivHist!.prepareBivariateHistogramForXVariate(xVar, yVar: yVar)
            myGraphicSubview.setNeedsDisplay(myGraphicSubview.innerBoxDrawingBounds())
            Swift.print("bivariateHistogramCount \(myGraphicSubview.bivHist!.bivariateHistogramCount) gatedBivariateHistogramCount \(myGraphicSubview.bivHist!.gatedBivariateHistogramCount)")
        }
        
    } // End of removeGatedData
    
    
    /// deleteAllGates removes all the gates from the displayed histograms. Called by rightClick:"DeleteAllGates in a GraphicSubview.
    func deleteAllGates() {
        for view in mySubviews {
            let myGraphicSubview = view
            mainViewController!.deleteGateDictEntryForKey(myGraphicSubview.keyString())
            myGraphicSubview.rectGate = nil
            myGraphicSubview.polygonGate = nil
            myGraphicSubview.quadGate = nil
        }
        refreshSubviews()
        
    } // End of deleteAllGates
    
    
    /// refreshSubviews redisplays each graphic subview. Called from deleteAllGates
    func refreshSubviews() {
        for view in mySubviews {
            var myGraphicSubview = GraphicSubview()
            myGraphicSubview = view
            myGraphicSubview.setNeedsDisplay(myGraphicSubview.innerBoxDrawingBounds())
        }
        
    } // End of refreshSubviews
    
    
    /// updateGateDictionaryEntries updates each gate dictionary entry. Called by rightClick:"GateTheData in a GraphicSubview.
    func updateGateDictionaryEntries() {
        for view in mySubviews {
            let myGraphicSubview = view
            myGraphicSubview.editGateDictionaryEntry()
        }
    } // End of updateGateDictionaryEntries
    
    
    /// draw clears background to white.
    ///
    /// - Parameter dirtyRect: rect to be cleared to white.
    override func draw(_ dirtyRect: NSRect) {
        super.draw(dirtyRect)
        NSColor.white.set()
        dirtyRect.fill()

//        print("GraphicView.draw openFileCount: \(openFileCount)")
    } // End of draw
    
    override var acceptsFirstResponder: Bool { // Required for print func below.
        get { return false }}
    
} // End of class GraphicView
