//
//  GRSVExtScaleTransforms.swift
//  FCSRead
//
//  Created by Mr. Salzman on 1/23/16.
//  Copyright © 2016 Gary Salzman. All rights reserved.
//
// Functions in GRSVExtensionScaleTransforms.swift
// func graphicPointGivenRealPoint(inPt: NSPoint) -> NSPoint (empty)
// func realPointGivenGraphicPoint(inPt: NSPoint) -> NSPoint

import Cocoa

extension GraphicSubview { // GRSVExtensionScaleTransforms
        
    /// realPointGivenGraphicPoint alculates real point (fData units) from a graphic point (display units). Input is NSPoint inPt; output is NSPoint outPt. Called from mouseMoved, from QuadGate:realQuadPtArrayFromQuadPtArray, and from FRPolygonGate:realPolyPtArrayFromPolyPtArray. inPt.x range is [xOffset, xOffset+innerBoxWidth] inPt.y range is [yOffset, yOffset+innerBoxHeight]
    ///
    /// - Parameter inPt: NSPoint in graphic units
    /// - Returns: NSPoint in fData units
    func realPointGivenGraphicPoint(_ inPt: NSPoint) -> NSPoint {
        
        var linearRangeX = 0.0
        var linearRangeY = 0.0
        var logRangeX = 0.0
        var logRangeY = 0.0
        var myExp = 0.0
        var myInPt = NSZeroPoint
        var outPt = NSZeroPoint
        
        // myInPt removes the offsets from inPt so that the real (fData) points are calculated correctly.
        myInPt.x = inPt.x - histogramGraphic!.xOffset
        myInPt.y = inPt.y - histogramGraphic!.yOffset
        
        if histogramType == UnivariateTag {
            switch histogramGraphic!.histLimitsX!.xAxisType {
            case LinearTag:
                linearRangeX = histogramGraphic!.histLimitsX!.xMaxLin - histogramGraphic!.histLimitsX!.xMinLin
                if linearRangeX <= 0.0 {
                    return NSZeroPoint
                }
                else {
                    outPt.x = CGFloat(histogramGraphic!.histLimitsX!.xMinLin)
                    outPt.x += myInPt.x * (CGFloat(linearRangeX) / histogramGraphic!.innerBoxWidth)
                }
                
            case LogTag:
                logRangeX = log10(histogramGraphic!.histLimitsX!.xMaxLog) - log10(histogramGraphic!.histLimitsX!.xMinLog)
                if logRangeX <= 0.0 {
                    return NSZeroPoint
                }
                else {
                    myExp = Double(myInPt.x) * logRangeX / Double(histogramGraphic!.innerBoxWidth)
                    myExp += log10(histogramGraphic!.histLimitsX!.xMinLog)
                    outPt.x = CGFloat(pow(10.0, myExp))
                }
                
            case LogicleTag, AsinhTag:
                let fastLogicle = FastLogicle(myVar: xVariate, myAxisType: UnivariateTag)
                outPt.x = CGFloat(fastLogicle.inverseWithScale(Double(myInPt.x / histogramGraphic!.innerBoxWidth)))
            case HyperlogTag:
                let hyperlog = Hyperlog(myVar: xVariate, myAxisType: UnivariateTag)
                var temp1 = Double(myInPt.x / histogramGraphic!.innerBoxWidth)
                outPt.x = CGFloat(hyperlog.inverseWithScale(&temp1))
            default:
                break
                
            } // End of histogramGraphic!.histLimitsX!.xAxisType (univariate)
            
            switch histogramGraphic!.histLimitsX!.yAxisType { // Univariate y-axis
            case LinearTag:
                linearRangeY = histogramGraphic!.histLimitsX!.yMaxLin - histogramGraphic!.histLimitsX!.yMinLin
                if linearRangeY <= 0.0 {
                    return NSZeroPoint
                }
                else {
                    outPt.y = CGFloat(histogramGraphic!.histLimitsX!.yMinLin)
                    outPt.y += myInPt.y * CGFloat(linearRangeY) / histogramGraphic!.innerBoxHeight
                }
                
            case LogTag:
                logRangeY = log10(histogramGraphic!.histLimitsX!.yMaxLog) - log10(histogramGraphic!.histLimitsX!.yMinLog)
                if logRangeY <= 0.0 {
                    return NSZeroPoint
                }
                else {
                    myExp = Double(myInPt.y) * logRangeY / Double(histogramGraphic!.innerBoxHeight)
                    outPt.y = CGFloat(pow(10.0, myExp))
                }
                
            default:
                break
                
            } // End of switch histogramGraphic!.histLimitsX!.yAxisType
            
        } // End of histogramType == "Univariate"
            
        else if histogramType == BivariateTag {
            switch histogramGraphic!.histLimitsX!.xAxisType { // Bivariate x-axis
            case LinearTag: // Linear x-axis
                linearRangeX = histogramGraphic!.histLimitsX!.xMaxLin - histogramGraphic!.histLimitsX!.xMinLin
                if linearRangeX < 0.0 {
                    return NSZeroPoint
                }
                else { // LinearRangeX >= 0.0
                    outPt.x = CGFloat(histogramGraphic!.histLimitsX!.xMinLin)
                    outPt.x += myInPt.x * CGFloat(linearRangeX) / histogramGraphic!.innerBoxWidth
                }
                
            case LogTag: // Log x-axis
                logRangeX = log10(histogramGraphic!.histLimitsX!.xMaxLog) - log10(histogramGraphic!.histLimitsX!.xMinLog)
                if logRangeX < 0.0 {
                    return NSZeroPoint
                }
                else { // logRangeX >= 0.0
                    myExp = Double(myInPt.x) * logRangeX / Double(histogramGraphic!.innerBoxWidth)
                    myExp += log10(Double(histogramGraphic!.histLimitsX!.xMinLog))
                    outPt.x = CGFloat(pow(10.0, myExp))
                }
                
            case LogicleTag, AsinhTag: // Logicle or Asinh x-axis
                let fastLogicle = FastLogicle(myVar: xVariate, myAxisType: BivariateTag)
                outPt.x = CGFloat(fastLogicle.inverseWithScale(Double(myInPt.x / histogramGraphic!.innerBoxWidth)))
                
            case HyperlogTag: // Hyperlog x-axis
                let hyperlog = Hyperlog(myVar: xVariate, myAxisType: BivariateTag)
                var temp1 = Double(myInPt.x / histogramGraphic!.innerBoxWidth)
                outPt.x = CGFloat(hyperlog.inverseWithScale(&temp1))
                
            default:
                break
                
            } // End of switch histogramGraphic!.histLimitsX!.xAxisType (bivariate x-axis)
            
            switch histogramGraphic!.histLimitsY!.xAxisType { // bivariate y-axis
            case LinearTag: // Linear y-axis
                linearRangeY = histogramGraphic!.histLimitsY!.xMaxLin - histogramGraphic!.histLimitsY!.xMinLin
                if linearRangeY < 0.0 {
                    return NSZeroPoint
                }
                else { // LinearRangeY >= 0.0
                    outPt.y = CGFloat(histogramGraphic!.histLimitsY!.xMinLin)
                    outPt.y += myInPt.y * CGFloat(linearRangeY) / histogramGraphic!.innerBoxHeight
                }
                
            case LogTag: // Log y-axis
                logRangeY = log10(histogramGraphic!.histLimitsY!.xMaxLog) - log10(histogramGraphic!.histLimitsY!.xMinLog)
                if logRangeY < 0.0 {
                    return NSZeroPoint
                }
                else { // logRangeY >= 0.0
                    myExp = Double(myInPt.y) * logRangeY / Double(histogramGraphic!.innerBoxHeight)
                    myExp += log10(histogramGraphic!.histLimitsY!.xMinLog)
                    outPt.y = CGFloat(pow(10.0, myExp))
                }
                
            case LogicleTag, AsinhTag: // Logicle or Asinh y-axis
                let fastLogicle = FastLogicle(myVar: xVariate, myAxisType: BivariateTag)
                outPt.y = CGFloat(fastLogicle.inverseWithScale(Double(myInPt.y / histogramGraphic!.innerBoxHeight)))
                
            case HyperlogTag: // Hyperlog y-axis
                let hyperlog = Hyperlog(myVar: yVariate, myAxisType: BivariateTag)
                var temp1 = Double(myInPt.y / histogramGraphic!.innerBoxHeight)
                outPt.y = CGFloat(hyperlog.inverseWithScale(&temp1))
                
            default:
                break
                
            } // End of switch histogramGraphic!.histLimitsY!.xAxisType (bivariate y-axis)
            
        } // End of else if histogramType == "Bivariate"
        
        return outPt
        
    } // End of realPointGivenGraphicPoint
    
} // End of extension GraphicSubview (GRSVExtensionScaleTransforms)
