//
//  Document.swift
//  FCSRead
//
//  Created by Mr. Salzman on 12/5/17.
//  Copyright © 2019 Gary Salzman. All rights reserved.
//
// The document is used only to get theData into the program from a file and to print the GraphicView. MainWindowController passes document to MainViewController, which is the controller in the Model-View-Controller paradigm. MainViewController uses its copy of document to retrieve theData and call ReadAndParse to interpret theData.

import Cocoa

class Document: NSDocument {
    
    var fileReadDone = false
    var theData: Data?
    weak var mainViewController : MainViewController?
    var printingRect = NSZeroRect // Rect containing all histograms to be printed.
    var printInfoDefaults = false

    override init() { super.init() }
    
    var acceptsFirstResponder: Bool { get { return true } }

    override class var autosavesInPlace: Bool { return true }
    
    override func makeWindowControllers() {
        // Returns the Storyboard that contains your Document window.
        if fileReadDone == true {
            let storyboard = NSStoryboard(name: "Main", bundle: nil)
            let windowController = (storyboard.instantiateController(withIdentifier: "Main Window Controller") as! NSWindowController)
            addWindowController(windowController)
        }
    }

    override func data(ofType typeName: String) throws -> Data { // Not used.
        // Insert code here to write your document to data of the specified type. If outError != nil, ensure that you create and set an appropriate error when returning nil.
        // You can also choose to override fileWrapperOfType:error:, writeToURL:ofType:error:, or writeToURL:ofType:forSaveOperation:originalContentsURL:error: instead.
        throw NSError(domain: NSOSStatusErrorDomain, code: unimpErr, userInfo: nil)
    }

    /// read function reads the data from the file as if it were a String.
    /// - parameter from data: data
    /// - parameter ofType typename: String containing the data
    /// - returns: nothing
    /// - throws: error
    override func read(from data: Data, ofType typeName: String) throws {
        theData = data
        fileReadDone = true
    }
    
    /// printDocument formats and prints the document on the screen.
    /// - parameter sender: Any?
    /// - returns: nothing
    @IBAction override func printDocument(_ sender: Any?) { // FCSRead.Document
        mainViewController = windowControllers[0].window!.contentViewController as? MainViewController
        if mainViewController != nil {
            printingRect = (mainViewController?.graphicView.frame)!
            Swift.print("doc.printDocument.printingRect \(String(describing: printingRect))")
            let printInfo = NSPrintInfo.shared
            if printInfoDefaults == false {
                printInfo.isHorizontallyCentered = true
                printInfo.isVerticallyCentered = true
                printInfo.leftMargin = 72.0
                printInfo.rightMargin = 72.0
                printInfo.topMargin = 72.0
                printInfo.bottomMargin = 72.0
                printInfo.orientation = NSPrintInfo.PaperOrientation.portrait
            }
            let printPanelAccessoryViewController = FRPrintPanelAccessoryViewController()
            printPanelAccessoryViewController.representedObject = printInfo
            let viewWidth = CGFloat(printingRect.size.width)
            let viewHeight = CGFloat(printingRect.size.height)
            Swift.print("viewWidth: \(viewWidth) viewHeight: \(viewHeight)")
            if viewHeight <= viewWidth {
                printInfo.orientation = NSPrintInfo.PaperOrientation.landscape
            } else {
                printInfo.orientation = NSPrintInfo.PaperOrientation.portrait
            }
            let myPageWidth = CGFloat(printInfo.imageablePageBounds.size.width
                - printInfo.leftMargin - printInfo.rightMargin)
            let myPageHeight = CGFloat(printInfo.imageablePageBounds.size.height
                - printInfo.topMargin - printInfo.bottomMargin)
            Swift.print("myPageWidth: \(myPageWidth) myPageHeight: \(myPageHeight)")
            printInfo.horizontalPagination = .fit
            printInfo.verticalPagination = .fit
            Swift.print("doc.printInfo \(printInfo)")
            printInfo.scalingFactor = 1.0
            let op = NSPrintOperation(view: (mainViewController?.graphicView)!, printInfo: printInfo)
            let printPanel = op.printPanel
            printPanel.addAccessoryController(printPanelAccessoryViewController)
            printPanel.options.formUnion(NSPrintPanel.Options.showsCopies)
            printPanel.options.formUnion(NSPrintPanel.Options.showsPaperSize)
            printPanel.options.formUnion(NSPrintPanel.Options.showsPageRange)
            printPanel.options.formUnion(NSPrintPanel.Options.showsScaling)
            printPanel.options.formUnion(NSPrintPanel.Options.showsOrientation)
            printPanel.options.formUnion(NSPrintPanel.Options.showsPreview)
            op.showsPrintPanel = true
            op.showsProgressPanel = true
            Swift.print("doc.printDocument.op: \(op)")
            op.canSpawnSeparateThread = true
            op.run()
        } // End of if mainViewController != nil
    } // End of printDocument
    
} // End of Document

