//
//  MainWindowController.swift
//  FCSRead
//
//  Created by Mr. Salzman on 12/17/17.
//  Copyright © 2019 Gary Salzman. All rights reserved.
//
/// MainWindowController is a container for MainViewController.

import Cocoa

class MainWindowController: NSWindowController {
    
    var mainViewController : MainViewController?
    
    /// windowDidLoad instantiates the mainViewController, which is the primary controller for the app.
    override func windowDidLoad() {
        super.windowDidLoad()
        mainViewController = window!.contentViewController as? MainViewController
    }
    
    /// document sets MainViewController.document to document, which is in Document.swift.
    override var document: AnyObject? {
        didSet {
            if let document = document as? Document {
                mainViewController?.document = document // Uses windowDidLoad and var document to create a link to document in mainViewController. See weak var document in MainViewController.
             }
        }
    } // End of didSet for document

}
