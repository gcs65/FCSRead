//
//  PolygonGate.swift
//  FCSRead
//
//  Created by Mr. Salzman on 1/23/16.
//  Copyright © 2019 Gary Salzman. All rights reserved.
//

import Cocoa

class PolygonGate: NSObject {
    
    weak var myView: GraphicSubview?
    var gateType = PolygonGateTag
    var gateSubtype = ""
    var gatePath = NSBezierPath()
    var polygonGateExists = false
    var polyPt = PolyPoint()
    var polyPtIndex = 0 // Index of just created polyPt
    var polyPtArray = [PolyPoint]()
    var currentHandle = 0 // Current polyPt handle (1st = 0)
    var currentPt = NSZeroPoint
    var lastPoint = NSZeroPoint // Last point in the polygon
    
    var bounds = NSZeroRect
    var drawingStroke = false
//    var strokeColor = NSColor.red
    var strokeWidth: CGFloat = 0.0
    
    override init() {
        super.init()
    }
    
    
    /// convenience init instantiates a polygonGate object
    ///
    /// - Parameters:
    ///   - frameRect: frameRect for the polygon
    ///   - view: GraphicSubview
    convenience init(frameRect: NSRect, view: GraphicSubview) {
        self.init()
        bounds = frameRect
        myView = view
        drawingStroke = true
        strokeWidth =  1.0
    }
    
    // MARK: *** Drawing ***
    
    /// bezierPathForDrawing creates the bezierPath for the polygon
    ///
    /// - Returns: NSBezierPath for the polygon
    func bezierPathForDrawing() -> NSBezierPath {
        gatePath = NSBezierPath()
        gatePath.lineWidth = strokeWidth
        polyPt = PolyPoint(myPoint: NSZeroPoint, myHandle: currentHandle, key: "", isLastPoint: false)
        if polyPtArray.isEmpty {
            return gatePath // Empty gatePath
        }
        else { // polyPtArray not empty
            let ptCount = polyPtArray.count
            for i in 0..<ptCount {
                polyPt = polyPtArray[i]
                if i == 0 {
                    gatePath.move(to: polyPt.pPt)
                }
                else {
                    gatePath.line(to: polyPt.pPt)
                    if i == ptCount - 1 && polyPt.isLastPoint == true {
                        gatePath.close()
                    }
                } // End of else
            } // End of for i loop
        } // End of else for polyPtArray not empty
        
        return gatePath
        
    } // End of bezierPathForDrawing
    
    
    /// drawContentsInView draws the polygon
    ///
    /// - Parameter view: GraphicSubview
    func drawContentsInView(_ view: GraphicSubview) {
        gatePath = bezierPathForDrawing()
        if !gatePath.isEmpty {
            if drawingStroke == true {
                NSColor.red.setStroke()
                gatePath.stroke()
            }
            
            NSColor.black.setStroke()
            for myPolyPt: PolyPoint in polyPtArray {
                drawHandleInView(view, point: myPolyPt.pPt)
            }
            
        } // End of nonempty gatePath
        
    } // End of drawContentsInView
    
    
    /// enclosingRect returns the rect enclosing the polygon Gate
    ///
    /// - Returns: rect enclosing the polygon Gate
    func enclosingRect() -> NSRect {
        if !gatePath.isEmpty {
            return gatePath.bounds
        }
        else {
            return NSZeroRect
        }
        
    } // End of enclosingRect
    
    
    /// drawingBounds is slightly larger than enclosingRect
    ///
    /// - Returns: NSRect drawingBounds
    func drawingBounds() -> NSRect {
        var outset: CGFloat = GateHandleHalfWidth
        if drawingStroke {
            let strokeOutset = 0.5 * strokeWidth
            if strokeOutset > outset {
                outset = strokeOutset
            }
        } // End of if drawingStroke
        
        let inset = -outset
        var myDrawingBounds: NSRect = NSInsetRect(enclosingRect(), inset, inset)
        myDrawingBounds.size.width += 1.0
        myDrawingBounds.size.height += 1.0
        
        return myDrawingBounds
        
    } // End of drawingBounds
    
    // MARK: *** Resizing/Moving Handles ***
    
    
    /// resizeByMovingHandle enables dragging to resize polygon. Called from GraphicSubview.selectAndTrackPolyMouseWithEvent. Restrict the location of the point to be within histogramBox (innerBox)
    ///
    /// - Parameters:
    ///   - handle: handle being dragged
    ///   - point: mouse point
    func resizeByMovingHandle(_ handle: Int, point: inout NSPoint) {
        restrictLocationOfPoint(&point)
        
//        print("PolygonGate.resizeByMovingHandle:\(handle) point:\(NSStringFromPoint(point))")
        
        // Find which polyPt to move and move it.
        let arrayCount = polyPtArray.count
        for i in 0 ..< arrayCount {
            polyPt = polyPtArray[i]
            if handle == polyPt.pHandle {
                polyPt.pPt = point
                polyPtIndex = i
                currentHandle = handle
            }
            polyPtArray[i] = polyPt // update the array
            
        } // End of loop over arrayCount
        
        myView!.setNeedsDisplay(myView!.innerBoxDrawingBounds())
                
    } // End of resizeByMovingHandle
    
    
    /// handleUnderPoint determines which handle is under the mouse point
    ///
    /// - Parameter point: mouse point
    /// - Returns: handle value or GateNoHandle
    func handleUnderPoint(_ point: NSPoint) -> Int {
        
        var handle = GateNoHandle // Result if no handle is under the point.
        for myPolyPt: PolyPoint in polyPtArray {
            if isHandleAtPoint(myPolyPt.pPt, point: point) {
                handle = myPolyPt.pHandle
            }
            
        } // End of loop over myPolyPt
        
        return handle // This is the handle under the point (or GateNoHandle).
        
    } // End of handleUnderPoint
    
    
    /// isHandleAtPoint. Check a handle-sized rectangle that's centered on the handle point.
    ///
    /// - Parameters:
    ///   - handlePoint: center of handle point
    ///   - point: mouse point
    /// - Returns: boolean true if the mouse point is within the handle rectangle
    func isHandleAtPoint(_ handlePoint: NSPoint, point: NSPoint) -> Bool {
        
       let handleBounds = NSMakeRect(handlePoint.x - GateHandleHalfWidth, handlePoint.y - GateHandleHalfWidth, GateHandleWidth, GateHandleWidth)
        
        return NSPointInRect(point, handleBounds)
        
    } // End of isHandleAtPoint
    
    
    /// translatePolygonByX enables translation of the entire polygon gate
    ///
    /// - Parameters:
    ///   - deltaX: translation amount in x
    ///   - deltaY: translation amount in y
    func translatePolygonByX(_ deltaX: inout CGFloat, deltaY: inout CGFloat) {
        // Polygon gate edges after translation
        let leftEdge: CGFloat = enclosingRect().origin.x + deltaX
        let rightEdge: CGFloat = leftEdge + enclosingRect().size.width
        let bottomEdge: CGFloat = enclosingRect().origin.y + deltaY
        let topEdge: CGFloat = bottomEdge + enclosingRect().size.height
        
        // Keep polygonGate inside histogramBox (innerBox)
        if leftEdge < (myView!.histogramGraphic!.xOffset) || rightEdge > (myView!.histogramGraphic!.xOffset) + (myView!.histogramGraphic!.innerBoxWidth) {
            deltaX = 0.0
        }
        if bottomEdge < (myView!.histogramGraphic!.yOffset) || topEdge > (myView!.histogramGraphic!.yOffset) + (myView!.histogramGraphic!.innerBoxHeight) {
            deltaY = 0.0
        }
        
        let arrayCount = polyPtArray.count
        for i in 0..<arrayCount {
            let polyPt: PolyPoint = polyPtArray[i]
            polyPt.pPt = NSMakePoint(polyPt.pPt.x + deltaX, polyPt.pPt.y + deltaY)
            polyPtArray[i] = polyPt
        }
        
        myView!.setNeedsDisplay(myView!.innerBoxDrawingBounds())
        
    } // End of translatePolygonByX
    
    
    /// restrictLocationOfPoint. Keep point inside histogramBox
    ///
    /// - Parameter point: point to be kept inside histogramBox
    func restrictLocationOfPoint(_ point: inout NSPoint) {
        
        if point.x < (myView!.histogramGraphic!.xOffset) {
            point.x = (myView!.histogramGraphic!.xOffset)
        }
        
        if point.x > (myView!.histogramGraphic!.xOffset) + (myView!.histogramGraphic!.innerBoxWidth) {
            point.x = (myView!.histogramGraphic!.xOffset) + (myView!.histogramGraphic!.innerBoxWidth)
        }
        
        if point.y < (myView!.histogramGraphic!.yOffset) {
            point.y = (myView!.histogramGraphic!.yOffset)
        }
        
        if point.y > (myView!.histogramGraphic!.yOffset) + (myView!.histogramGraphic!.innerBoxHeight) {
            point.y = (myView!.histogramGraphic!.yOffset) + (myView!.histogramGraphic!.innerBoxHeight)
        }
        
    } // End of restrictLocationOfPoint
    
    
    // MARK: *** Handles ***
    
    
    /// drawHandleInView. Draw the handle for a polygon vertex
    ///
    /// - Parameters:
    ///   - view: GraphicSubview
    ///   - point: handle point
    func drawHandleInView(_ view: GraphicSubview, point: NSPoint) {
        // Figure out a rectangle that's centered on the point but lined up with device pixels.
        var handleBounds = NSZeroRect
        handleBounds.origin.x = point.x - GateHandleHalfWidth
        handleBounds.origin.y = point.y - GateHandleHalfWidth
        handleBounds.size.width = GateHandleWidth
        handleBounds.size.height = GateHandleWidth
        handleBounds = view.centerScanRect(handleBounds)
        
        // Draw the shadow of the handle.
        let handleShadowBounds = NSOffsetRect(handleBounds, 1.0, 1.0)
        NSColor.controlDarkShadowColor.setFill()
        handleShadowBounds.fill()
        
        // Draw the handle itself
        NSColor.black.setFill()
        handleBounds.fill()
        
    } // End of drawHandleInView
    
    
    /// isContentsUnderPoint. Determines whether the mouse point is within the polygon gate path
    ///
    /// - Parameter point: mouse point
    /// - Returns: boolean true if the mouse point is within the polygon gate.
    func isContentsUnderPoint(_ point: NSPoint) -> Bool { // May never be called. ****
        // Just check against the graphic's bounds.
        
        return NSPointInRect(point, gatePath.bounds)

    } // End of isContentsUnderPoint
    
    
    /// creationCursor. crosshairs cursor
    ///
    /// - Returns: the cursor
    class func creationCursor() -> NSCursor { // Copied from RectGate
        // By default we use the crosshairs cursor.
        var crosshairsCursor: NSCursor?
        
        let crosshairsImage = NSImage(named: "Cross")
        let crosshairsImageSize: NSSize = crosshairsImage!.size
        crosshairsCursor = NSCursor(image: crosshairsImage!, hotSpot: NSMakePoint(0.5 * crosshairsImageSize.width, 0.5 * crosshairsImageSize.height))
        
        return crosshairsCursor!
        
    } // End of creationCursor
    
    
    /// description
    override var description: String { // PolygonGate.swift
        get {
            var result = PolygonGateTag + " polyPtArray"
            for pt in polyPtArray {
                result += "\n \(pt)"
            }
            
            return result
        }
    } // End of description
    
} // End of class PolygonGate
