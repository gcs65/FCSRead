//
//  RectGateExtSupport.swift is an extension supporting the RectGate class.
//  FCSRead
//
//  Created by Mr. Salzman on 1/18/16.
//  Copyright © 2019 Gary Salzman. All rights reserved.
//

import Cocoa

// PI and PI_180 (PI/180.0) are global constants defined in Document.

// MARK: - Support Methods for RectGate ***********************

extension RectGate { // RectGate support methods
    
    
    /// constrainPointToHistogramBox constrains the point to be inside the histogram inner box. Called by RectGate.resizeByMovingRotatedEllipseHandle
    ///
    /// - Parameter point: mouse point
    /// - Returns: constrained new point
    func constrainPointToHistogramBox(_ point: NSPoint) -> NSPoint {
        var newPt = NSZeroPoint
        
        if point.x < leftEdgeInnerBox {
            newPt.x = leftEdgeInnerBox
        }
        else if point.x > rightEdgeInnerBox {
            newPt.x = rightEdgeInnerBox
        }
        else if point.y < bottomEdgeInnerBox {
            newPt.y = bottomEdgeInnerBox
        }
        else if point.y > topEdgeInnerBox {
            newPt.y = topEdgeInnerBox
        }
        else {}
        
        return newPt
        
    } // End of constrainPointToHistogramBox
    
    
    /// validateRotationAngleOfEllipse checks to see that the rotation angle keeps the rotated ellipse inside the inner box of the histogram. Called by RectGate.bezierPathForDrawing
    ///
    /// - Returns: boolean indicating success or failure
    func validateRotationAngleOfEllipse() -> Bool {
        // left, right, bottom and top are extremes of rotation rectangle here.
        var rotationOK = false
        
        graphicCoordinatesFromRotatedCoordinates()
        // What extreme handles of gate rectangle will be after translation.
        if rotationAngle >= 0.0 { // Counterclockwise
            left = CGFloat(x[1])
            right = CGFloat(x[8])
            bottom = CGFloat(y[6])
            top = CGFloat(y[3])
        }
        else { // rotationAngle < 0.0 // Clockwise
            left = CGFloat(x[6])
            right = CGFloat(x[3])
            bottom = CGFloat(y[8])
            top = CGFloat(y[1])
        }
        
        // Keep rotated rectGate inside histogramBox
        if left <= leftEdgeInnerBox || right >= rightEdgeInnerBox || bottom <= bottomEdgeInnerBox || top >= topEdgeInnerBox {
            rotationOK = false
        } else {
            rotationOK = true
        }
        
        return rotationOK
        
    } // End of validateRotationAngleOfEllipse
    
    
    /// graphicCoordinatesFromRotatedCoordinates calculates the graphic coordinates from their rotated counterparts. Called by validateRotationAngleOfEllipse. Must have rotationAngle and gateCenter point.
    func graphicCoordinatesFromRotatedCoordinates() {
        let theta: Float = Float(PI_180) * Float(rotationAngle)
        let sinTheta = sinf(theta) // Float -> Float
        let cosTheta = cosf(theta)
        
        for i in 1...8 {
            x[i] = x2p[i] * cosTheta - y2p[i] * sinTheta + Float(gateCenter.x)
            y[i] = x2p[i] * sinTheta + y2p[i] * cosTheta + Float(gateCenter.y)
        }
        
    } // End of graphicCoordinatesFromRotatedCoordinates
    
    
    /// constrainRotatedEllipseToHistogramBoxGivenDeltaPoint keeps the rotated ellipse inside the inner box of the histogram. Called from resizeByMovingRotatedEllipseHandle and from translateRotatedEllipseGivenDeltaPoint.
    ///
    /// - Parameter oldDelta: original value of NSPoint indicating rotation amount.
    /// - Returns: an updated Point
    func constrainRotatedEllipseToHistogramBoxGivenDeltaPoint(_ oldDelta: NSPoint) -> NSPoint {
        var delta = oldDelta
        
        graphicCoordinatesFromRotatedCoordinates()
        // What extreme handles of gate rectangle will be after translation.
        if rotationAngle >= 0.0 {
            left = CGFloat(x[1]) + delta.x
            right = CGFloat(x[8]) + delta.x
            bottom = CGFloat(y[6]) + delta.y
            top = CGFloat(y[3]) + delta.y
        }
        
        else { // rotationAngle < 0.0
            left = CGFloat(x[6]) + delta.x
            right = CGFloat(x[3]) + delta.x
            bottom = CGFloat(y[8]) + delta.y
            top = CGFloat(y[1]) + delta.y
        }
        
        // Keep rotated rectGate inside histogramBox
        if left < leftEdgeInnerBox || right > rightEdgeInnerBox {
            delta.x = 0.0
        }
        if bottom < bottomEdgeInnerBox || top > topEdgeInnerBox {
            delta.y = 0.0
        }
        
        return NSMakePoint(delta.x, delta.y)
    
    } // End of constrainRotatedEllipseToHistogramBoxGivenDeltaPoint
    
    
    /// gateCenterForBounds. Called by GraphicSubview.createGateOfClassWithEvent. Only for rectangle gate or nonrotated ellipse gate.
    ///
    /// - Parameter bounds: rectangular bounds.
    func gateCenterForBounds(_ bounds: NSRect) {
        // Called by GraphicSubview.createGateOfClassWithEvent. Only for rectangle gate or nonrotated ellipse gate.
        gateCenter = NSMakePoint(bounds.origin.x + 0.5 * bounds.size.width, bounds.origin.y + 0.5 * bounds.size.height)
        
    } // End of gateCenterForBounds
    
    
    /// rotatedEllipseGateCenter calculates gateCenter for rotated ellipse.
    func rotatedEllipseGateCenter() {
        gateCenter.x = CGFloat(x[4]) + CGFloat(0.5 * (x2p[5] - x2p[4]) * cosf(Float(PI_180) * Float(rotationAngle)))
        gateCenter.y = CGFloat(y[4]) + CGFloat(0.5 * (y2p[2] - y2p[7]) * sinf(Float(PI_180) * Float(rotationAngle)))
        
    } // End of rotatedEllipseGateCenter
    
    
    /// graphicBoundsFromRotatedEllipseBounds. Called from multiple places within RectGate
    ///
    /// - Returns: graphic bounds
    func graphicBoundsFromRotatedEllipseBounds() -> NSRect {
        // Called from multiple places within RectGate
        let originPt: NSPoint = graphicPointFromRotatedPoint(NSMakePoint(CGFloat(x2p[6]), CGFloat(y2p[6])))
        let bounds: NSRect = NSMakeRect(originPt.x, originPt.y, rotatedEllipseBounds.size.width, rotatedEllipseBounds.size.height)
        
        return bounds
        
    } // End of graphicBoundsFromRotatedEllipseBounds
    
    
    /// graphicPointFromRotatedPoint calculates a graphic point given a rotated point.
    ///
    /// - Parameter rotPt: rotated point
    /// - Returns: graphic point
    func graphicPointFromRotatedPoint(_ rotPt: NSPoint) -> NSPoint {
        // Must have rotation angle and gateCenter point.
        var grPt = NSZeroPoint
        let theta: Float = Float(PI_180) * Float(rotationAngle)
        let sinTheta: Float = sinf(theta)
        let cosTheta: Float = cosf(theta)
        
        grPt.x = rotPt.x * CGFloat(cosTheta) - rotPt.y * CGFloat(sinTheta) + gateCenter.x
        grPt.y = rotPt.x * CGFloat(sinTheta) + rotPt.y * CGFloat(cosTheta) + gateCenter.y
        
        return grPt
        
    } // End of graphicPointFromRotatedPoint
    
    
    /// rotatedCoordinatesFromRotatedEllipseBounds calculates rotated coordinate vertices given rotated ellipse bounds. Must have rotation angle and gateCenter point.
    func rotatedCoordinatesFromRotatedEllipseBounds() {
        x2p[1] = Float(rotatedEllipseBounds.origin.x)
        x2p[4] = x2p[1]
        x2p[6] = x2p[1]
        
        x2p[3] = x2p[1] + Float(rotatedEllipseBounds.size.width)
        x2p[5] = x2p[3]
        x2p[8] = x2p[3]
        
        x2p[2] = x2p[1] + 0.5 * Float(rotatedEllipseBounds.size.width)
        x2p[7] = x2p[2]
        
        y2p[6] = Float(rotatedEllipseBounds.origin.y)
        y2p[7] = y2p[6]
        y2p[8] = y2p[6]
        
        y2p[1] = y2p[6] + Float(rotatedEllipseBounds.size.height)
        y2p[2] = y2p[1]
        y2p[3] = y2p[1]
        
        y2p[4] = y2p[6] + 0.5 * Float(rotatedEllipseBounds.size.height)
        y2p[5] = y2p[4]
        
    } // End of rotatedCoordinatesFromRotatedEllipseBounds
    
    
    /// rotatedCoordinatesFromGraphicCoordinates calculates the rotated vertex coordinates from the graphic coordinates of the rotated ellipse.
    func rotatedCoordinatesFromGraphicCoordinates() {
        let theta: Float = Float(PI_180) * Float(rotationAngle)
        let sinTheta = sinf(theta) // Float -> Float
        let cosTheta = cosf(theta)
        
        for i in 1...8 {
            x2p[i] = (x[i] - Float(gateCenter.x)) * cosTheta + (y[i] - Float(gateCenter.y)) * sinTheta
            y2p[i] = -(x[i] - Float(gateCenter.x)) * sinTheta + (y[i] - Float(gateCenter.y)) * cosTheta
        }
        
    } // End of rotatedCoordinatesFromGraphicCoordinates
    
    /// rotatedPointFromGraphicPoint calculates a point in the rotated coordinate system from a point in the graphic system.
    ///
    /// - Parameter point: graphic point
    /// - Returns: point in rotated coordinate system
    func rotatedPointFromGraphicPoint(_ point: NSPoint) -> NSPoint {
        let theta: Float = Float(PI_180) * Float(rotationAngle)
        var rotatedPoint = NSZeroPoint
        
        rotatedPoint.x = (point.x - gateCenter.x) * CGFloat(cosf(theta)) + (point.y - gateCenter.y) * CGFloat(sinf(theta))
        rotatedPoint.y = -(point.x - gateCenter.x) * CGFloat(sinf(theta)) + (point.y - gateCenter.y) * CGFloat(cosf(theta))
        
        return rotatedPoint
        
    } // End of rotatedPointFromGraphicPoint
    
    
    /// coordinatesOfRotatedEllipseGateHandlesFromGraphicBounds. Called from RectGate:bezierPathForDrawing and drawHandlesInView.
    ///
    /// - Parameter bounds: graphic bounds
    func coordinatesOfRotatedEllipseGateHandlesFromGraphicBounds(_ bounds: NSRect) {
        // width & height of rectangle enclosing gate:
        let width = bounds.size.width
        let height = bounds.size.height
        rotatedEllipseBounds = NSMakeRect(-0.5 * width, -0.5 * height, width, height)
        
        // double prime coordinates of handles on the gate rectangle enclosing the ellipse gate. These are in graphic units centered on the gateCenter.
        x2p[1] = -0.5 * Float(width)
        x2p[4] = x2p[1]
        x2p[6] = x2p[1]
        
        x2p[2] = 0.0
        x2p[7] = 0.0
        
        x2p[3] = 0.5 * Float(width)
        x2p[5] = x2p[3]
        x2p[8] = x2p[3]
        
        y2p[1] = 0.5 * Float(height)
        y2p[2] = y2p[1]
        y2p[3] = y2p[1]
        
        y2p[4] = 0.0
        y2p[5] = 0.0
        
        y2p[6] = -0.5 * Float(height)
        y2p[7] = y2p[6]
        y2p[8] = y2p[6]
        
    } // End of coordinatesOfRotatedEllipseGateHandlesFromGraphicBounds
    
    
    /// creationSizingHandle. Return the number of the handle for the lower-right corner. If the user drags it so that it's no longer in the lower-right, resizeByMovingHandle:toPoint: will deal with it.
    ///
    /// - Returns: the number of the handle for the lower-right corner
    class func creationSizingHandle() -> Int {
        
        return GateLowerRightHandle
        
    } // End of creationSizingHandle
    
    
    /// creationCursor
    ///
    /// - Returns: returns the crosshairs cursor
    class func creationCursor() -> NSCursor {
        // By default we use the crosshairs cursor.
        var crosshairsCursor: NSCursor?
        
        let crosshairsImage = NSImage(named: "Cross")
        let crosshairsImageSize: NSSize = crosshairsImage!.size
        crosshairsCursor = NSCursor(image: crosshairsImage!, hotSpot: NSMakePoint(0.5 * crosshairsImageSize.width, 0.5 * crosshairsImageSize.height))
        
        return crosshairsCursor!
        
    } // End of creationCursor
    
    
    /// flipLeftRight. Flip the handle designations left to right because the user has flipped the rectangle left to right.
    func flipLeftRight() {

        flippings[GateUpperLeftHandle] = GateUpperRightHandle
        flippings[GateUpperMiddleHandle] = GateUpperMiddleHandle
        flippings[GateUpperRightHandle] = GateUpperLeftHandle
        flippings[GateMiddleLeftHandle] = GateMiddleRightHandle
        flippings[GateMiddleRightHandle] = GateMiddleLeftHandle
        flippings[GateLowerLeftHandle] = GateLowerRightHandle
        flippings[GateLowerMiddleHandle] = GateLowerMiddleHandle
        flippings[GateLowerRightHandle] = GateLowerLeftHandle
        
    } // End of flipLeftRight
    
    
    /// flipTopBottom. Flip the handle designations top to bottom because the user has inverted the rectangle.
    func flipTopBottom() {
        flippings[GateUpperLeftHandle] = GateLowerLeftHandle
        flippings[GateUpperMiddleHandle] = GateLowerMiddleHandle
        flippings[GateUpperRightHandle] = GateLowerRightHandle
        flippings[GateMiddleLeftHandle] = GateMiddleLeftHandle
        flippings[GateMiddleRightHandle] = GateMiddleRightHandle
        flippings[GateLowerLeftHandle] = GateUpperLeftHandle
        flippings[GateLowerMiddleHandle] = GateUpperMiddleHandle
        flippings[GateLowerRightHandle] = GateUpperRightHandle
        
    } // End of flipTopBottom
        
    /// description
    override var description: String {
        let rectString: String = NSStringFromRect(bounds)
        let ptString: String = NSStringFromPoint(gateCenter)
        
        let result = "\ngateType \(gateType)  rectString \(rectString)  ptString \(ptString)  rotationAngle \(rotationAngle)"

        return result
        
    } // End of description for RectGate
    
} // End of extension RectGate
