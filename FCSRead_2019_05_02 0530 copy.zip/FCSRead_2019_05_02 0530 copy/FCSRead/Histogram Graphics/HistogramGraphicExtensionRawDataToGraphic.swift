//
//  HistogramGraphicExtensionRawDataToGraphic.swift (in HistogramGraphics group) is an extension of HistogramGraphic to convert fData values to univariateGraphic values.
//  FCSRead
//
//  Created by Mr. Salzman on 2/15/16.
//  Copyright © 2019 Gary Salzman. All rights reserved.
//

import Foundation

extension HistogramGraphic {

    /// fDataToUnivariateGraphic converts a univariate x-value from fData values to univariate graphic value
    ///
    /// - Parameter xValue: x-axis fData value
    /// - Returns: CGFloat univariate graphic value
    func fDataToUnivariateGraphic(_ xValue: Double) -> CGFloat { // This func is not called.
        
        if histLimitsX?.xAxisType == LinearTag {
            let range = CGFloat(histLimitsX!.xMaxLin - histLimitsX!.xMinLin)
            if range > 0.0 {
                graphicValue = xOffset + CGFloat(xValue - histLimitsX!.xMinLin) * innerBoxWidth / range
            }
            else {
                graphicValue = 0.0 // fail
            }
        } // End of linear x-axis type
        
        else if histLimitsX!.xAxisType == LogTag {
            let totalLogDecX = endLogDecXAxis - beginLogDecXAxis
            if totalLogDecX > 0.0 {
                graphicValue = xOffset + (CGFloat(log10(xValue)) - beginLogDecXAxis) * innerBoxWidth / totalLogDecX
            }
            
        } // End of log x-axis type
        
        else if histLimitsX!.xAxisType == LogicleTag || histLimitsX!.xAxisType == AsinhTag {

        } // End of Logicle or Asinh x-axis type
        
        return graphicValue
        
    } // End of fDataToUnivariateGraphic
    
} // End of HistogramGraphicExtensionRawDataToGraphic
